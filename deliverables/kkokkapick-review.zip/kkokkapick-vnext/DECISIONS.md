# Decision Log

기준일: 2026-10-11 (Asia/Seoul). 상태를 `Confirmed User Instruction`, `Working Default`, `Proposed`, `Pending User Decision`으로 구분한다.

| ID | 상태 | 결정/근거 | 영향과 후속 |
|---|---|---|---|
| DEC-001 | Confirmed User Instruction | 신규 제품, 기존 코드/데이터 기본 이관 금지; 기존 chachazip-prog/kkokkapick는 참고만 | 읽기 전용 별도 clone, 신규 source copy 금지 |
| DEC-002 | Working Default | 선정한 빈 chachazip-prog/- 체크아웃 /workspace/-를 신규 기반 사용 | 별도 GitHub 생성/rename/push 사실 없음. 원격명 결정 U-001 |
| DEC-003 | Confirmed User Instruction | 기획→디자인→검수→구현→QA→승인, Gate B 사용자 승인 | 본격 화면 구현 대기, 기술 PoC만 별도 허용 |
| DEC-004 | Confirmed User Instruction | 공식 출시 HOLD, 별도 사용자 승인/사업·법적·운영 준비 | RELEASE_HOLD_CHECKLIST 충족 전 출시 금지 |
| DEC-005 | Proposed | Flutter/Next.js/경량 API/PostgreSQL/저비용 관리형 서비스 | ADR-001 비교 초안, 기술 확정 아님 |
| DEC-006 | Working Default | 초기 월령 구간만 선택 처리, 회원/비회원 메모리·세션 기본, 아이 이름/정확한 생일/사진 미수집 | 세션 종료 시 삭제; 기기 영속화·계정 동기화는 OFF인 별도 opt-in 제안; 수집 확대 사용자 승인 |
| DEC-007 | Confirmed User Instruction | 월 마케팅 50,000원, 집행 별도 승인 | 도구 구독 포함해 내부 배분, 실제 지출 0 |
| DEC-008 | Working Default | 공식 공개 문서 읽기에 필요한 도메인만 네트워크 draft 추가 | 저장≠runtime 적용/발행. 사용자 환경 설정 검토/저장/발행 필요 |
| DEC-009 | Working Default | rollback은 카탈로그/검색/offer mapping 참조 세대만 되돌림 | 최신 찜 삭제·알림 OFF·탈퇴·동의철회·권리차단은 항상 우선하며 사용자 상태 부활 금지 |
| DEC-010 | Working Default / isolated PoC | 2026-10-12 계속 진행 지시에 따라 격리 카탈로그 안전성 실험을 Python표준라이브러리/SQLite 합성 데이터로 검증 | 원문 Gate B 이전 기술위험PoC 허용 조항 적용. SQLite는 운영DB선정/실제공급처 검증이 아니며 threshold/TTL은 실험 제안값 |

## 사용자 의사결정 카드

- **U-001 신규 원격**: 현재 빈 `chachazip-prog/-` 계속 사용을 기본값으로 한다. 별도 `kkokkapick-vnext` 같은 원격 생성/이름 변경이 필요하면 지정해야 하며 외부 생성/푸시는 아직 하지 않았다. 문서 작업을 막지 않는다.
- **U-002 핵심 UX 방향**: 연보라·크림의 따뜻한 탐색 방향은 검토안이다. Phase 3의 실제 비교 시안/흐름을 검수한 뒤 승인하며 현재 텍스트 방향만으로 Gate B 승인하지 않는다.
- **U-003 사업/제휴 상태**: 사업자등록, 공식 제휴 권한/계약, 이미지·데이터 저장권 범위를 환경 설정/계약 문서로 확인해야 한다. 자격증명은 채팅에 요청하지 않는다. 미확인 상태는 출시 차단이다.
- **U-004 비용 상한**: 마케팅 상한은 확정되어 있다. 인프라 월 예산과 지출 경보/유료 전환 기준은 사용자가 정해야 한다. 현재 유료 자원 생성 없음.
- **U-005 계정/개인정보**: 로그인 공급자와 아이 정보 수집 범위 확정은 기획/보안 검수 뒤 한다. 후보를 실제 OAuth 작동으로 표현하지 않는다.
- **U-006 공식 조사 접근**: 차단된 19개 공개 문서 도메인 draft를 환경 설정에서 검토·저장하고 환경 발행해야 한다. 읽기 요청은 runtime 적용 후 재검증한다. 비용·광고·로그인 API 작업을 승인하는 항목은 아니다.

관련 근거는 정책·UX·ADR·보안·비용 초안을 확인한다. 현재 사용자 승인 완료 표시는 원문의 명시 지시와 기존 저장소 참고 지시만 해당한다.
