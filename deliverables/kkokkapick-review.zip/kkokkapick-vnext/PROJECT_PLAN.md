# 꼬까픽 vNext — WBS와 Gate별 실행 계획

기준일: 2026-10-11 (Asia/Seoul). 상태: Initial Review Draft. 달력상 완료일·진행률은 추정하지 않는다. 각 단계는 산출물+실행 증거+독립 검수+필요한 사용자 승인으로 종료한다.

| WBS | 작업/담당 | 진입 조건 | 제출/검증 | 현재 상태 |
|---|---|---|---|---|
| 0.1 | 원문/요구사항·RTM / Lead | 마스터 수신 | 원문 줄 연결·누락 검사 | In Progress |
| 0.2 | 기존 실패 분석 / Reference Reviewer | 사용자 제공 기존 저장소 | commit/파일 기반 회고, 인과 제한 | In Progress |
| 0.3 | 조직·규칙·위험·새 저장소 경계 / Lead | 빈 신규 체크아웃 확인 | Charter/AGENTS/조직/위험/실행 기록 | In Progress |
| 1.1 | 시장/경쟁 조사 / Planner·Designer | 공식 문서 읽기 접근 | 출처·확인일·증거, 조사와 가설 구분 | Blocked |
| 1.2 | PRD/정책/기능/회원/광고 / Planner | 마스터 해석 | 예외·권한·정합성 독립 검수 | In Progress |
| 1.3 | 공급처/수익/비용/마케팅 / Data·Growth·FinOps | 약관/공식 가격 접근 | 권한 범위·모델·민감도·50,000원 상한 | In Progress |
| 2.1 | IA·주요 흐름·화면/상태 / Designer | Gate A | 화면목록·이동·오류·모바일/Admin 설계 | Not Started |
| 2.2 | 편집 가능한 Figma 호환·프로토타입 / Designer | 2.1 검수 | 실제 SVG/Figma 구성/상호작용 증거 | Not Started |
| 3.1 | 브랜드/방향 비교·Hi-Fi / Designer | Phase 2 검수 | 디자인 토큰·주요 화면·인터랙션·접근성 | Not Started |
| 3.2 | 디자인 QA와 사용자 Gate B / QA·Lead·사용자 | 3.1 증거 | 사용자 시나리오·실제 사용자 승인 | Not Started |
| 4.1 | ADR·ERD·API·추천·동기화 / Backend·Data | Gate B 또는 격리 기술 PoC | 모델·계약·신선도·급감/롤백 설계 | Not Started |
| 4.2 | 보안·RBAC·비용 검수 / Security·FinOps | 4.1/공급처 권한 | Threat/RBAC/원가/권한·Gate C | Not Started |
| 5.1 | API·DB·Adapter·검색·찜/알림 / Backend·Data | Gate C | 빌드·정적·단위/통합·실데이터 적합성 | Not Started |
| 5.2 | 앱·디자인 시스템·회원·구매 / Mobile | Gate B/C | 실제 앱 빌드·화면 비교·접근성 | Not Started |
| 5.3 | 별도 Admin·권한·운영 / Frontend·Backend | Gate B/C | 비개발자 역할별 실제 운영 시나리오 | Not Started |
| 6.1 | 앱/Admin/실상품 통합 데모 / 全担当 | 핵심 기능 실제 구현 | 사용자가 접근할 수 있는 데모/계정/영상 | Not Started |
| 7.1 | 독립 QA·회귀·기기·성능 / QA | Gate D | 실행 결과·결함 반환·P0/P1 0·Gate E | Not Started |
| 8.1 | Android/iOS/Admin RC / Mobile·DevOps | Gate E | 서명/스토어·배포/롤백·운영·법적 체크 | Not Started |
| 8.2 | 사용자 출시 승인 / Lead·사용자 | Gate F 요건 모두 증거 | 별도 명시 승인, 출시 HOLD 해제 | Blocked |

## Gate 종료 책임

- A: 원문/PRD/정책/범위/RTM 정합성. Lead 독립 검수와 QA 누락 검토가 있어야 한다. 초기 문서 존재만으로 통과하지 않는다.
- B: 주요 흐름·화면설계·디자인 시스템·편집 가능/검수 가능 산출물·시나리오 검증·**사용자 승인**.
- C: 아키텍처·공급처 적합성·데이터·비용·보안 검토. 외부 API/권한이 미확인이면 해당 연동은 차단한다.
- D: 기능·정적 분석·단위/통합·시각 정합성·RTM 구현/실행 증거.
- E: 독립 QA P0/P1 0, 주요 여정/실데이터/기기/보안/성능 실행 통과.
- F: RC·롤백·Admin 운영·사업/계약/법적/스토어·사용자 출시 승인.

## 안전한 병행과 비용

7개 동시 슬롯 안에서 역할별 에이전트를 순차 가동하고 산출물 경로를 분리한다. 기획 초안/공식 조사/회고/기술 위험 검토는 병행하며, 미승인 UI 본격 구현이나 미확인 공급처 API 구현으로 단계를 건너뛰지 않는다. 외부 비용/광고/사용자 데이터 변경은 승인이 필요하다. 읽기 조사 접근 차단은 [차단 목록](NEXT_ACTIONS.md)에 기록하고 문서 독립 작업은 계속한다.

전체 산출물 목록은 [README](README.md), 최신 상태는 [PROJECT_STATE](PROJECT_STATE.md), 결정은 [DECISIONS](DECISIONS.md), 결함은 [QA_STATUS](QA_STATUS.md)를 따른다.
