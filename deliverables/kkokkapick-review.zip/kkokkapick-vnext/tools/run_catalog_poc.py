#!/usr/bin/env python3
"""Run the isolated synthetic catalogue-risk suite and retain truthful evidence."""
import hashlib
import io
import json
import sqlite3
from datetime import datetime
from pathlib import Path
import sys
import unittest
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
POC = ROOT / 'experiments/catalog_integrity'

def now():
    return datetime.now(ZoneInfo('Asia/Seoul')).isoformat()

def main():
    started = now()
    stream = io.StringIO()
    loader = unittest.TestLoader()
    try:
        suite = loader.discover(str(POC / 'tests'), pattern='test_*.py')
    except (ImportError, OSError) as exc:
        print(f'Test discovery failed: {exc}', file=sys.stderr)
        return 1
    discovered = suite.countTestCases()
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    log = stream.getvalue()
    accepted = (result.wasSuccessful() and result.testsRun > 0
                and result.testsRun == discovered and not loader.errors
                and not result.skipped and not result.expectedFailures
                and not result.unexpectedSuccesses)
    artifacts = ROOT / 'docs/qa/catalog_poc'
    artifacts.mkdir(parents=True, exist_ok=True)
    (artifacts / 'TEST_OUTPUT.txt').write_text(log)
    sources = {}
    for path in sorted(POC.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts and path.suffix in {'.py', '.md', '.json'}:
            sources[str(path.relative_to(ROOT))] = hashlib.sha256(path.read_bytes()).hexdigest()
    report = {
        'report_basis_date': '2026-10-12',
        'execution_started_at': started, 'execution_finished_at': now(),
        'command': 'python3 tools/run_catalog_poc.py',
        'python_version': sys.version.split()[0], 'sqlite_version': sqlite3.sqlite_version,
        'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'scope': 'isolated Python/SQLite synthetic catalogue-risk proof of concept',
        'outcome': 'passed' if accepted else 'failed', 'exit_code': 0 if accepted else 1,
        'discovered': discovered, 'executed': result.testsRun,
        'failures': len(result.failures), 'errors': len(result.errors),
        'skipped': len(result.skipped), 'expected_failures': len(result.expectedFailures),
        'unexpected_successes': len(result.unexpectedSuccesses),
        'loader_errors': loader.errors,
        'failure_ids': [case.id() for case, _ in result.failures],
        'error_ids': [case.id() for case, _ in result.errors],
        'source_sha256': sources,
        'output_sha256': hashlib.sha256(log.encode()).hexdigest(),
        'not_verified': ['PostgreSQL behavior', 'live provider API or rights',
                         'mobile/Admin/API implementation', 'production thresholds',
                         'product QA or Gates A-F', 'user approval or launch'],
        'release_status': 'HOLD',
    }
    (artifacts / 'EXECUTION_RESULT.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(log, end='')
    print(json.dumps({k: report[k] for k in ('outcome', 'executed', 'failures', 'errors', 'skipped', 'exit_code')}))
    return report['exit_code']

if __name__ == '__main__':
    raise SystemExit(main())
