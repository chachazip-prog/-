#!/usr/bin/env python3
"""Validate documentation traceability; this is not a product QA runner."""
import argparse
import ast
import csv
import hashlib
import json
import re
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'docs/source/MASTER_PROMPT.md'
MATRIX = ROOT / 'docs/governance/RTM.csv'
STATES = {'Not Started', 'In Progress', 'Blocked', 'Implemented', 'Tested', 'QA Passed', 'Approved', 'Released'}

def statements():
    return {n: line.strip() for n, line in enumerate(SOURCE.read_text().splitlines(), 1)
            if line.strip() and line.strip() != '---' and not line.strip().startswith('#')}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    errors = []
    expected = statements()
    with MATRIX.open(newline='') as f:
        rows = list(csv.DictReader(f))
    by_line = {}
    ids = set()
    for row in rows:
        try:
            n = int(row['source_line'])
        except (KeyError, ValueError):
            errors.append('Invalid source_line')
            continue
        if n in by_line:
            errors.append(f'Duplicate source line {n}')
        by_line[n] = row
        rid = row['requirement_id']
        if rid in ids or rid != f'REQ-L{n:04d}':
            errors.append(f'Invalid/duplicate identifier {rid}')
        ids.add(rid)
        if row['original'] != expected.get(n):
            errors.append(f'Original mismatch {rid}')
        if row['status'] not in STATES:
            errors.append(f'Unknown state {rid}')
        for column in ['policy_document', 'review_evidence']:
            target = row[column]
            if not target or not (ROOT / target).is_file():
                errors.append(f'Missing {column}: {rid}: {target}')
        for column in ['design_document', 'api_data_document', 'implementation', 'test_evidence', 'technical_poc_evidence']:
            target = row.get(column, '')
            if target and not (ROOT / target).is_file():
                errors.append(f'Missing {column}: {rid}: {target}')
        # Initial artifacts must not upgrade pending product work to tested/approved.
        if row['status'] in {'Tested', 'QA Passed', 'Approved', 'Released'} and not row['test_evidence']:
            errors.append(f'Unsupported mature state {rid}')
    if set(by_line) != set(expected):
        errors.append(f'Source coverage mismatch missing={sorted(set(expected)-set(by_line))} extra={sorted(set(by_line)-set(expected))}')
    trace = ROOT / 'docs/governance/POC_REQUIREMENT_TRACE.csv'
    if trace.is_file():
        tests_path = ROOT / 'experiments/catalog_integrity/tests/test_catalog_guard.py'
        if tests_path.is_file():
            methods = {node.name for node in ast.walk(ast.parse(tests_path.read_text()))
                       if isinstance(node, ast.FunctionDef) and node.name.startswith('test_')}
            with trace.open(newline='') as f:
                for row in csv.DictReader(f):
                    for rid in row['parent_source_ids'].split(';'):
                        if rid not in ids:
                            errors.append(f'Unknown PoC parent requirement: {rid}')
                    for method in row['representative_test_methods'].split(';'):
                        if method not in methods:
                            errors.append(f'Unknown PoC test method: {method}')
                    for field in ['implementation', 'execution_evidence']:
                        if not (ROOT / row[field]).is_file():
                            errors.append(f'Missing PoC trace {field}: {row[field]}')
        else:
            errors.append('Missing independent PoC test source')
    document_count = 0
    for document in sorted(ROOT.rglob('*.md')):
        if '.git' in document.parts:
            continue
        document_count += 1
        content = document.read_text()
        for rid in re.findall(r'REQ-L\d+', content):
            if rid not in ids:
                errors.append(f'Unknown source ID: {document.relative_to(ROOT)} -> {rid}')
        for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)', content):
            target = target.strip().split('#', 1)[0]
            if not target or re.match(r'^[A-Za-z][A-Za-z0-9+.-]*:', target):
                continue
            target = target.strip('<>')
            if not (document.parent / target).exists():
                errors.append(f'Broken local link: {document.relative_to(ROOT)} -> {target}')
    for name in ['PROJECT_STATE.md', 'QA_STATUS.md', 'NEXT_ACTIONS.md']:
        path = ROOT / name
        if not path.exists() or 'HOLD' not in path.read_text():
            errors.append(f'Missing explicit launch HOLD in {name}')
    required = ['AGENTS.md', 'README.md', 'PROJECT_PLAN.md', 'DECISIONS.md',
                'docs/phase0/PROJECT_CHARTER.md', 'docs/phase0/AGENT_ORGANIZATION.md',
                'docs/phase0/LEGACY_RETROSPECTIVE.md', 'docs/product/PRD.md',
                'docs/product/FUNCTIONAL_SPECIFICATION.md', 'docs/product/POLICY_SPECIFICATION.md',
                'docs/reports/KICKOFF_REPORT.md', 'docs/qa/INITIAL_REVIEW.md']
    for name in required:
        if not (ROOT / name).is_file():
            errors.append(f'Missing required initial artifact {name}')
    report = {
        'executed_at': datetime.now(ZoneInfo('Asia/Seoul')).isoformat(),
        'scope': 'source coverage, RTM paths/states, local links/source IDs, technical PoC trace references, launch HOLD',
        'not_validated': ['semantic requirement completeness', 'application behavior', 'provider rights', 'design quality', 'user approval'],
        'source_sha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        'source_statement_count': len(expected), 'rtm_rows': len(rows),
        'documents_scanned': document_count,
        'outcome': 'passed' if not errors else 'failed', 'errors': errors,
    }
    if args.report:
        destination = args.report if args.report.is_absolute() else ROOT / args.report
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return bool(errors)

if __name__ == '__main__':
    raise SystemExit(main())
