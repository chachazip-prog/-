#!/usr/bin/env python3
"""Reproduce KKOKKAPICK hypothetical monthly revenue tables (standard library only)."""
from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone, timedelta
from decimal import Decimal, ROUND_HALF_UP, getcontext
import hashlib
import io
import json
from pathlib import Path
import sys

getcontext().prec = 40
ROOT = Path(__file__).resolve().parents[1]
D = Decimal
RATE_KEYS = (
    "purchase_cvr", "commission_rate", "attribution_rate", "refund_cancel_rate",
    "final_approval_rate", "pending_share", "ad_eligible_consent_rate",
    "ad_fill_rate", "ad_valid_rate",
)


def amount(value: Decimal) -> str:
    return str(value.quantize(D("0.01"), rounding=ROUND_HALF_UP))


def count(value: Decimal) -> str:
    return str(value.quantize(D("0.0001"), rounding=ROUND_HALF_UP))


def calculate(data: dict, name: str, mau: int, overrides: dict | None = None,
              product_count: int | None = None) -> dict:
    params = dict(data["scenarios"][name])
    params.update(overrides or {})
    p = {key: D(str(value)) for key, value in params.items()}
    for key in RATE_KEYS:
        if not D(0) <= p[key] <= D(1):
            raise ValueError(f"{key} must be between zero and one")
    if any(value < 0 for value in p.values()):
        raise ValueError("Negative model inputs are not permitted")
    products = product_count or data["catalog_product_count"]
    clicks = D(mau) * p["clicks_per_mau"]
    purchases = clicks * p["purchase_cvr"]
    attributed = purchases * p["attribution_rate"]
    gross_affiliate = attributed * p["aov_krw"] * p["commission_rate"]
    refunded = gross_affiliate * p["refund_cancel_rate"]
    rejected = (gross_affiliate - refunded) * (D(1) - p["final_approval_rate"])
    eventual_affiliate = gross_affiliate - refunded - rejected
    pending_affiliate = eventual_affiliate * p["pending_share"]
    recognizable_affiliate = eventual_affiliate - pending_affiliate
    opportunities = D(mau) * p["monthly_sessions_per_mau"] * p["ad_slots_per_session"]
    eligible_requests = opportunities * p["ad_eligible_consent_rate"]
    filled = eligible_requests * p["ad_fill_rate"]
    valid_impressions = filled * p["ad_valid_rate"]
    ad_revenue = valid_impressions / D(1000) * p["ecpm_krw"]
    infra_base = D(data["infrastructure"]["base_cost_by_mau_krw"][str(mau)])
    catalog_addon = D(data["infrastructure"]["catalog_addon_by_product_count_krw"][str(products)])
    infra_cost = (infra_base + catalog_addon) * p["infra_multiplier"]
    marketing_cost = D(data["marketing"]["modeled_cost_provision_krw"])
    other_cost = D(data["other_operating_cost_by_mau_krw"][str(mau)])
    total_cost = infra_cost + marketing_cost + other_cost
    recognizable_total = recognizable_affiliate + ad_revenue
    eventual_total = eventual_affiliate + ad_revenue
    per_cvr_revenue = (
        clicks * p["attribution_rate"] * p["aov_krw"] * p["commission_rate"]
        * (D(1) - p["refund_cancel_rate"]) * p["final_approval_rate"]
        * (D(1) - p["pending_share"])
    )
    breakeven = max(D(0), total_cost - ad_revenue) / per_cvr_revenue if per_cvr_revenue else None
    row = {"scenario": name, "mau": mau, "catalog_product_count": products,
           **{key: str(value) for key, value in p.items()},
           "monthly_valid_clicks": count(clicks),
           "expected_purchases_before_attribution": count(purchases),
           "expected_attributed_orders": count(attributed),
           "gross_affiliate_commission_krw": amount(gross_affiliate),
           "refund_cancel_adjustment_krw": amount(refunded),
           "approval_rejection_adjustment_krw": amount(rejected),
           "estimated_eventual_affiliate_krw": amount(eventual_affiliate),
           "modeled_pending_affiliate_krw": amount(pending_affiliate),
           "modeled_recognizable_affiliate_krw": amount(recognizable_affiliate),
           "potential_ad_opportunities": count(opportunities),
           "eligible_ad_requests": count(eligible_requests),
           "filled_ad_impressions": count(filled),
           "valid_billable_ad_impressions": count(valid_impressions),
           "estimated_ad_revenue_krw": amount(ad_revenue),
           "estimated_total_recognizable_revenue_krw": amount(recognizable_total),
           "estimated_eventual_total_revenue_krw": amount(eventual_total),
           "infrastructure_base_krw": amount(infra_base),
           "catalog_addon_krw": amount(catalog_addon),
           "modeled_infrastructure_cost_krw": amount(infra_cost),
           "marketing_cost_provision_krw": amount(marketing_cost),
           "other_operating_cost_provision_krw": amount(other_cost),
           "total_modeled_cost_krw": amount(total_cost),
           "monthly_modeled_profit_before_exclusions_krw": amount(recognizable_total - total_cost),
           "eventual_modeled_profit_before_exclusions_krw": amount(eventual_total - total_cost),
           "breakeven_click_purchase_cvr": str(breakeven.quantize(D("0.000001"))) if breakeven is not None else "unavailable",
           "modeled_recognizable_revenue_per_mau_krw": amount(recognizable_total / D(mau)),
           "measurement_status": "hypothetical_not_observed",
           "actual_marketing_spend_krw": data["actual_marketing_spend_krw"]}
    return row


def csv_bytes(rows: list[dict]) -> bytes:
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    return stream.getvalue().encode("utf-8")


def build_tables(data: dict) -> tuple[list[dict], list[dict]]:
    scenarios = [calculate(data, name, mau) for name in data["scenarios"] for mau in data["mau_values"]]
    sensitivity = []
    for mau in data["mau_values"]:
        baseline = calculate(data, "base", mau)
        cases = [("baseline", "none", "base", {}, None)]
        for factor, values in data["sensitivity"]["factor_values"].items():
            for value in values:
                cases.append(("one_factor", factor, value, {factor: value}, None))
        for product_count in data["sensitivity"]["catalog_product_counts"]:
            cases.append(("catalog_workload", "catalog_product_count", str(product_count), {}, product_count))
        for name, overrides in data["sensitivity"]["combined_cases"].items():
            cases.append(("combined", name, "multiple", overrides, None))
        for case_type, factor, value, overrides, products in cases:
            modeled = calculate(data, "base", mau, overrides, products)
            sensitivity.append({"case_type": case_type, "changed_factor": factor, "changed_value": value,
                                "delta_profit_from_base_krw": amount(
                                    D(modeled["monthly_modeled_profit_before_exclusions_krw"])
                                    - D(baseline["monthly_modeled_profit_before_exclusions_krw"])),
                                **modeled})
    return scenarios, sensitivity


def validate(data: dict, scenarios: list[dict], sensitivity: list[dict]) -> list[dict]:
    checks = []

    def record(name: str, passed: bool, detail: str) -> None:
        checks.append({"name": name, "passed": passed, "detail": detail})

    allocation = sum(data["marketing"]["allocation_krw"].values())
    actual = sum(data["marketing"]["actual_spend_krw"].values())
    record("marketing_cap_and_inclusions", allocation == 50000 == data["marketing"]["monthly_cap_krw"],
           f"paid ads + creative + tools + reserve = {allocation} KRW; all included")
    record("actual_spend_zero_and_no_execution_approval", actual == data["actual_marketing_spend_krw"] == 0
           and data["marketing"]["execution_approved"] is False, "Actual spend = 0; approval is pending")
    source_path = ROOT / data["infrastructure"]["source_path"]
    finops = json.loads(source_path.read_text(encoding="utf-8")) if source_path.exists() else {}
    record("finops_synthetic_input_alignment", finops.get("provider_rates_verified") is False
           and finops.get("contingency_included_in_totals") is True
           and finops.get("baseline_product_count") == data["catalog_product_count"]
           and finops.get("infra_base_total_including_contingency_by_mau") == data["infrastructure"]["base_cost_by_mau_krw"]
           and finops.get("product_surcharge_including_contingency") == data["infrastructure"]["catalog_addon_by_product_count_krw"],
           "Matches independent FinOps synthetic inputs exactly; 20% contingency already included and not added again")
    record("required_mau_coverage", sorted({r["mau"] for r in scenarios}) == [1000, 5000, 10000, 50000, 100000]
           and len(scenarios) == 15, "Five MAU levels times three planning cases = 15")
    record("sensitivity_factor_coverage", {"purchase_cvr", "commission_rate", "ecpm_krw", "infra_multiplier"}
           <= set(data["sensitivity"]["factor_values"]), "CVR, commission, eCPM and infrastructure are varied independently")
    base = next(r for r in scenarios if r["scenario"] == "base" and r["mau"] == 1000)
    expected = {
        "monthly_valid_clicks": "3000.0000", "expected_purchases_before_attribution": "45.0000",
        "expected_attributed_orders": "36.0000", "gross_affiliate_commission_krw": "48600.00",
        "refund_cancel_adjustment_krw": "4860.00", "approval_rejection_adjustment_krw": "2187.00",
        "estimated_eventual_affiliate_krw": "41553.00", "modeled_pending_affiliate_krw": "10388.25",
        "modeled_recognizable_affiliate_krw": "31164.75", "valid_billable_ad_impressions": "4446.0000",
        "estimated_ad_revenue_krw": "5335.20", "total_modeled_cost_krw": "96000.00",
        "monthly_modeled_profit_before_exclusions_krw": "-59500.05"
    }
    record("hand_calculated_base_1000", all(base[key] == value for key, value in expected.items()),
           "Fixed hand-calculated example: 3000 clicks; 45 purchases; 36 attributed; net affiliate 41553; "
           "pending 10388.25; recognizable 31164.75; ads 5335.20; costs 96000; balance -59500.05")
    identities_pass = True
    tolerance = D("0.02")
    for row in scenarios + sensitivity:
        v = lambda key: D(str(row[key]))
        identities = [
            abs(v("estimated_eventual_affiliate_krw") - v("modeled_pending_affiliate_krw") - v("modeled_recognizable_affiliate_krw")) <= tolerance,
            abs(v("gross_affiliate_commission_krw") - v("refund_cancel_adjustment_krw") - v("approval_rejection_adjustment_krw") - v("estimated_eventual_affiliate_krw")) <= tolerance,
            abs(v("estimated_total_recognizable_revenue_krw") - v("modeled_recognizable_affiliate_krw") - v("estimated_ad_revenue_krw")) <= tolerance,
            abs(v("total_modeled_cost_krw") - v("modeled_infrastructure_cost_krw") - v("marketing_cost_provision_krw") - v("other_operating_cost_provision_krw")) <= tolerance,
            abs(v("monthly_modeled_profit_before_exclusions_krw") - v("estimated_total_recognizable_revenue_krw") + v("total_modeled_cost_krw")) <= tolerance,
            v("valid_billable_ad_impressions") <= v("filled_ad_impressions") <= v("eligible_ad_requests") <= v("potential_ad_opportunities"),
            v("expected_attributed_orders") <= v("expected_purchases_before_attribution") <= v("monthly_valid_clicks"),
        ]
        identities_pass = identities_pass and all(identities)
    record("all_row_accounting_and_funnel_identities", identities_pass,
           f"Checked {len(scenarios) + len(sensitivity)} rows; 0.02 KRW display-rounding tolerance")
    no_permission = [r for r in sensitivity if r["changed_factor"] == "no_monetization_permission"]
    record("no_permission_means_zero_modeled_revenue", len(no_permission) == 5 and
           all(D(r["estimated_total_recognizable_revenue_krw"]) == 0 for r in no_permission),
           "No attribution and no eligible ad permission yields zero modeled monetization at all MAU levels")
    directional = True
    positive = {"purchase_cvr", "commission_rate", "ecpm_krw", "final_approval_rate", "attribution_rate", "ad_eligible_consent_rate", "ad_fill_rate"}
    negative = {"infra_multiplier", "refund_cancel_rate", "pending_share"}
    for row in sensitivity:
        if row["case_type"] != "one_factor":
            continue
        factor = row["changed_factor"]
        change = D(row["changed_value"]) - D(data["scenarios"]["base"][factor])
        delta = D(row["delta_profit_from_base_krw"])
        directional = directional and ((delta * change >= 0) if factor in positive else (delta * change <= 0) if factor in negative else True)
    record("one_factor_profit_directions", directional,
           "Revenue factors increase balance; refund, pending share and infrastructure cost decrease balance, holding other inputs fixed")
    record("no_actual_revenue_or_verified_fee_claim", data["official_provider_rates_verified"] is False
           and data["actual_affiliate_revenue_krw"] is None and data["actual_ad_revenue_krw"] is None
           and all(r["measurement_status"] == "hypothetical_not_observed" for r in scenarios + sensitivity),
           "Official rates unverified; actual affiliate/ad revenue unmeasured; every CSV row is hypothetical")
    return checks


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--assumptions", type=Path, default=ROOT / "docs/growth/MODEL_ASSUMPTIONS.json")
    parser.add_argument("--output-dir", type=Path, default=ROOT / "docs/growth")
    parser.add_argument("--check", action="store_true", help="Verify committed CSV outputs without modifying files")
    args = parser.parse_args()
    raw = args.assumptions.read_bytes()
    data = json.loads(raw)
    scenarios, sensitivity = build_tables(data)
    checks = validate(data, scenarios, sensitivity)
    outputs = {"REVENUE_SCENARIOS.csv": csv_bytes(scenarios), "SENSITIVITY.csv": csv_bytes(sensitivity)}
    if args.check:
        for name, contents in outputs.items():
            path = args.output_dir / name
            checks.append({"name": f"reproducible_{name}", "passed": path.exists() and path.read_bytes() == contents,
                           "detail": "Exact byte comparison against regenerated deterministic CSV"})
    passed = all(c["passed"] for c in checks)
    summary = {"arithmetic_validation_passed": passed, "scenario_rows": len(scenarios),
               "sensitivity_rows": len(sensitivity), "check_count": len(checks),
               "actual_marketing_spend_krw": data["actual_marketing_spend_krw"],
               "product_qa_passed": False, "check_mode": args.check}
    if not args.check:
        args.output_dir.mkdir(parents=True, exist_ok=True)
        for name, contents in outputs.items():
            (args.output_dir / name).write_bytes(contents)
        report = {
            **summary,
            "executed_at": datetime.now(timezone(timedelta(hours=9))).isoformat(),
            "command": "python3 tools/revenue_model.py",
            "python_version": sys.version.split()[0],
            "assumptions_sha256": hashlib.sha256(raw).hexdigest(),
            "tool_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "finops_source_sha256": hashlib.sha256((ROOT / data["infrastructure"]["source_path"]).read_bytes()).hexdigest(),
            "output_sha256": {name: hashlib.sha256(contents).hexdigest() for name, contents in outputs.items()},
            "scope": "Author-run arithmetic and reproducibility checks only; not independent review, product QA, official rates, approved spending or revenue measurement",
            "checks": checks,
        }
        (args.output_dir / "MODEL_VALIDATION.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False))
    for check in checks:
        if not check["passed"]:
            print(f"FAIL: {check['name']}", file=sys.stderr)
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
