# Risks

위험 관리 정본은 [RISK_REGISTER.md](RISK_REGISTER.md)다. 중복된 별도 위험표를 운영하지 않는다. 최신 조사 차단과 출시 미충족 상태는 [NEXT_ACTIONS.md](NEXT_ACTIONS.md), [QA_STATUS.md](QA_STATUS.md)를 함께 읽는다.
