# 합성 카탈로그 무결성 기술 위험 PoC

기준일: **2026-10-12 (Asia/Seoul)**. 상태: **Proposed 기술 위험 실험**, 제품·Gate·사용자 승인 아님. 공식 출시 **HOLD**.

Python 3 표준 라이브러리와 로컬 SQLite만 사용한다. 실제 상품·판매처·사용자·아이 정보·키·외부 API·SDK·네트워크·유료 자원을 사용하지 않는다. 임시 DB가 삭제되는 CLI 시연과 독립 QA 테스트용 작은 합성 fixture이며 모바일/Admin 화면이나 실제 상품 수집 파이프라인이 아니다.

## 실행과 산출물

저장소 루트에서 다음 명령으로 임시 SQLite DB를 사용하는 시연을 실행한다. 별도 패키지 설치가 필요 없다.

```bash
PYTHONDONTWRITEBYTECODE=1 python3 experiments/catalog_integrity/demo.py
```

시연은 JSON에 실제 거부 코드·정상 데이터 보존·rollback·stale·현재 권리/사용자 상태·DB 재개 결과를 출력한다. 성공 종료는 이 한정된 개발자 시연의 결과이며 독립 QA나 제품 출시 승인으로 표현하지 않는다. `report_date_kst`와 실행 머신의 `execution_clock_utc`를 별도로 기록하고 가상 상품 시계 `SYNTHETIC_NOW`를 실제 수집일로 쓰지 않는다. DB는 `TemporaryDirectory` 내부에 만들고 종료 시 제거한다.

| 파일 | 역할·담당 |
| --- | --- |
| [CONTRACT.md](CONTRACT.md) | Source/Data와 Backend/QA가 협의한 입력·오류·공개 API·ABA addendum |
| [fixtures.py](fixtures.py) | Source/Data의 명시 식별 합성 입력, deepcopy 격리 |
| [catalog_guard.py](catalog_guard.py) | Backend의 strict full snapshot·SQLite 저장/전환·최신 overlay |
| [demo.py](demo.py) | Backend의 순차 CLI 시연. 자체 QA 승인 아님 |

독립 QA는 별도 테스트와 결과 문서를 작성하고 guard를 직접 수정하지 않는다. 실제 thread barrier를 이용한 별도 SQLite 연결 경쟁, trigger에 의한 DB 쓰기 실패, 손상 baseline, 경계값, 재개·ABA를 검증하며 결함은 Backend에 반환한다. 이 README 자체가 해당 검사를 실행했다는 증거는 아니다.

## 구현한 실험 경계

`CatalogGuard.stage()`는 strict schema·nonempty complete full·선언값/배열/실제 SQL count·옵션 identity·정상 baseline·총량 및 기존 provider/category/쌍 cohort를 확인하고 별도 candidate를 저장한다. bootstrap은 처음의 명시적 `True`만 허용하고 기존 baseline 우회에 사용하지 못한다. delta·부분 피드·모르는 필드·bool 숫자·ID 충돌·과거 모델/옵션 재사용은 거부한다. 동일 모델/variant의 서로 다른 명시 offer는 병합 없이 별도 행으로 보존한다.

`activate()`는 영속 token, stage 시 parent와 epoch, 현재 baseline/권리·실제 저장 count/내용을 재검사한 뒤 SQLite `BEGIN IMMEDIATE` 안에서 release 행·offer 행·active pointer를 함께 commit한다. 실패 시 transaction을 rollback한다. 별도 연결이 오래된 token 또는 parent를 가져오면 거부하며 `state_epoch`가 activate/rollback마다 증가하여 active ID가 R1→R2→R1로 돌아오는 ABA도 차단한다. epoch overflow는 변경 없이 거부한다. 이는 **단일 로컬 SQLite DB의 fencing/CAS**이며 distributed lease 획득·heartbeat·네트워크 분할 검증이 아니다.

`rollback()`은 이미 committed된 release의 pointer만 복구한다. 최신 provider revoke, alert OFF, favorite 삭제, consent 철회, user deletion은 release 밖에 저장하며 rollback하지 않는다. 삭제 tombstone은 이 실험에서 해제할 수 없고 provider 재허가 API도 없다. `read_catalog(now=...)`는 revoked offer를 제외하며 TTL 경계나 미래 관측의 `current_price=None`, `notification_eligible=False`를 반환한다. 저장된 과거 price/observed_at을 새 값으로 덮지 않는다.

`notification_eligible`/`alert_eligible`은 제한된 합성 후보 Gate다. 실제 동일조건 이전/현재 가격하락, 최저가, 알림 watch·동의 종류·OS 권한·push token·cooldown·발송·중복 방지·실제 전달은 구현/검증하지 않았다. favorite도 실제 상품별 찜 대신 최신 삭제를 보존하는 단일 합성 boolean이다.

ratio **4/5(0.8), 7/10(0.7), TTL 3600초**는 Proposed fixture 값이다. 실제 공급처·카테고리·계약·운영 SLA 또는 사용자 승인된 정책으로 적용하지 않는다. 계산은 `Fraction`/정수 곱을 사용하며 경계값을 포함한다. 저장 정수는 strict signed-64 범위이며 bool·문자열·float를 int로 자동 변환하지 않는다.

## 다음 검증과 실서비스 한계

SQLite schema의 `catalog_state(active_release_id, worker_token, state_epoch)`와 `releases(release_id)`는 QA의 로컬 corruption/trigger 검증 경계다. guard의 임의 검증 비활성화나 test fault callback을 제공하지 않는다. 실제 서버 권한, DB 운영 권한·RLS·감사 로그·보존기한·백업/복구와 secret 경계를 시험한 것이 아니다.

현재 실험은 단일 full catalog 범위에 한정한다. 실제 provider adapter·증분 watermark/tombstone·공급처 권리/샘플·분류·merge/unmerge·조건별 돈/통화·검색 인덱스와 DB 세대 일관성·outbox·제휴 전환 원장·OAuth/RBAC·삭제 sink·비용·100만 상품 성능은 별도 계약·PoC·독립 QA가 필요하다. PostgreSQL·관리형 서비스·분산 worker·실제 운영 파이프라인 준비 완료로 확장 보고하지 않는다.

이 작업은 원문에서 허용한 Gate B 전 격리 기술 위험 실험이다. 앱/API/Admin 본격 구현, Gate A~F 통과, 실제 계약 권리, 사용자 승인, 출시 HOLD 해제를 대신하지 않는다. 실제 실행 명령·결과·근거 hash·독립 QA 범위는 Team Lead가 별도 현재 상태 문서에 통합한다.
