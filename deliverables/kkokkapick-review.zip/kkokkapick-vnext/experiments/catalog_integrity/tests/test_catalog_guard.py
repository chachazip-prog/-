"""Independent adversarial tests for the isolated synthetic SQLite contract.

These tests exercise persisted behavior; they do not approve production policy,
PostgreSQL, price-drop delivery, an application, or a release.
"""
from copy import deepcopy
from fractions import Fraction
from pathlib import Path
from queue import Queue
import sqlite3
import tempfile
import threading
import unittest

from experiments.catalog_integrity.catalog_guard import (
    CatalogError,
    CatalogGuard,
    GuardPolicy,
)


NOW = 100000  # A synthetic clock, never a collection/execution timestamp.


def offers(count, *, start=0, provider="synthetic-provider-a",
           category="synthetic-category-a", observed_at=NOW - 10):
    return [
        {
            "offer_id": f"synthetic-offer-{index:04d}",
            "provider_id": provider,
            "category_id": category,
            "model_id": f"synthetic-model-{index:04d}",
            "variant_id": f"synthetic-variant-{index:04d}",
            "price": 1000 + index,
            "observed_at": observed_at,
        }
        for index in range(start, start + count)
    ]


def snapshot(rows):
    return {
        "manifest": {"schema_version": 1, "mode": "full", "complete": True,
                     "declared_count": len(rows)},
        "offers": deepcopy(rows),
    }


class CatalogGuardTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory(prefix="synthetic-catalog-qa-")
        self.addCleanup(self.directory.cleanup)
        self.db_path = str(Path(self.directory.name) / "catalog.sqlite3")
        self.policy = GuardPolicy(total_ratio=Fraction(4, 5),
                                  cohort_ratio=Fraction(7, 10), ttl_seconds=3600)
        self.guard = self.open_guard()
        self.guard.claim_worker(1)

    def open_guard(self):
        guard = CatalogGuard(self.db_path, policy=self.policy)
        self.addCleanup(guard.close)
        return guard

    def current(self, *, now=NOW):
        return self.guard.read_catalog(now=now)

    def publish(self, data, *, bootstrap=False, token=1):
        parent = self.guard.active_release_id()
        candidate = self.guard.stage(data, expected_parent=parent,
                                     worker_token=token, bootstrap=bootstrap)
        self.assertEqual(self.guard.active_release_id(), parent)
        release = self.guard.activate(candidate, expected_parent=parent,
                                      worker_token=token)
        self.assertEqual(self.guard.active_release_id(), release)
        return release

    def baseline(self, rows=None):
        rows = offers(20) if rows is None else rows
        return self.publish(snapshot(rows), bootstrap=True)

    def rejected(self, action, code):
        before_id = self.guard.active_release_id()
        before_read = self.current()
        with self.assertRaises(CatalogError) as caught:
            action()
        self.assertEqual(caught.exception.code, code)
        self.assertEqual(self.guard.active_release_id(), before_id)
        self.assertEqual(self.current(), before_read)

    def reject_stage(self, data, code, *, bootstrap=False, token=1):
        parent = self.guard.active_release_id()
        self.rejected(lambda: self.guard.stage(data, expected_parent=parent,
                                              worker_token=token,
                                              bootstrap=bootstrap), code)

    def sql(self, statement, params=()):
        with sqlite3.connect(self.db_path) as connection:
            return connection.execute(statement, params).fetchall()

    def release_count(self):
        return self.sql("SELECT COUNT(*) FROM releases")[0][0]

    def fail_pointer_update(self):
        self.sql("""CREATE TRIGGER synthetic_qa_pointer_failure
                    BEFORE UPDATE OF active_release_id ON catalog_state
                    BEGIN SELECT RAISE(ABORT, 'synthetic QA SQL failure'); END""")

    def test_empty_catalog_and_explicit_bootstrap(self):
        self.assertEqual(self.current(), {"release_id": None, "offers": []})
        data = snapshot(offers(20))
        self.reject_stage(data, "BOOTSTRAP_REQUIRED")
        release = self.baseline()
        self.assertEqual(self.current()["release_id"], release)
        self.assertEqual(len(self.current()["offers"]), 20)
        self.assertTrue(all(row["fresh"] and row["current_price"] == row["price"]
                            for row in self.current()["offers"]))

    def test_staging_is_separate_and_copies_input(self):
        self.baseline()
        old_read = self.current()
        data = snapshot(offers(21))
        candidate = self.guard.stage(data, expected_parent=old_read["release_id"],
                                     worker_token=1)
        data["offers"][0]["price"] = 999999
        data["offers"].clear()
        self.assertEqual(self.current(), old_read)
        self.assertFalse(self.guard.alert_eligible("synthetic-user-new",
                                                 "synthetic-offer-0020", now=NOW))
        self.guard.activate(candidate, expected_parent=old_read["release_id"],
                            worker_token=1)
        row = next(row for row in self.current()["offers"]
                   if row["offer_id"] == "synthetic-offer-0000")
        self.assertEqual(row["price"], 1000)
        self.assertEqual(len(self.current()["offers"]), 21)

    def test_bootstrap_cannot_bypass_existing_baseline(self):
        self.baseline()
        self.reject_stage(snapshot(offers(20)), "BASELINE_INVALID", bootstrap=True)

    def test_bootstrap_requires_boolean(self):
        for value in (1, "true", None):
            with self.subTest(value=value):
                self.reject_stage(snapshot(offers(20)), "MALFORMED", bootstrap=value)

    def test_declared_count_cannot_hide_actual_array_loss(self):
        self.baseline()
        data = snapshot(offers(1))
        data["manifest"]["declared_count"] = 20
        self.reject_stage(data, "COUNT_MISMATCH")

    def test_stage_checks_actual_sql_rows_after_insert(self):
        self.baseline()
        before_candidates = self.sql("SELECT COUNT(*) FROM candidates")[0][0]
        self.sql("""CREATE TRIGGER synthetic_qa_drop_staged_row
                    AFTER INSERT ON candidate_offers
                    WHEN NEW.offer_id = 'synthetic-offer-0000'
                    BEGIN DELETE FROM candidate_offers
                    WHERE candidate_id = NEW.candidate_id AND offer_id = NEW.offer_id; END""")
        self.reject_stage(snapshot(offers(21)), "COUNT_MISMATCH")
        self.assertEqual(self.sql("SELECT COUNT(*) FROM candidates")[0][0], before_candidates)

    def test_stage_sql_failure_leaves_no_partial_candidate(self):
        self.baseline()
        before_candidates = self.sql("SELECT COUNT(*) FROM candidates")[0][0]
        before_rows = self.sql("SELECT COUNT(*) FROM candidate_offers")[0][0]
        self.sql("""CREATE TRIGGER synthetic_qa_stage_failure
                    BEFORE INSERT ON candidate_offers
                    BEGIN SELECT RAISE(ABORT, 'synthetic QA stage failure'); END""")
        self.reject_stage(snapshot(offers(21)), "TRANSACTION_FAILED")
        self.assertEqual(self.sql("SELECT COUNT(*) FROM candidates")[0][0], before_candidates)
        self.assertEqual(self.sql("SELECT COUNT(*) FROM candidate_offers")[0][0], before_rows)

    def test_activation_rechecks_persisted_candidate_count_and_content(self):
        old = self.baseline()
        mutations = (
            ("DELETE FROM candidate_offers WHERE candidate_id = ? AND offer_id = 'synthetic-offer-0000'",
             "COUNT_MISMATCH"),
            ("UPDATE candidates SET declared_count = 20 WHERE candidate_id = ?", "COUNT_MISMATCH"),
            ("UPDATE candidate_offers SET price = 0 WHERE candidate_id = ? AND offer_id = 'synthetic-offer-0000'",
             "MALFORMED"),
            ("UPDATE candidate_offers SET price = 999999 WHERE candidate_id = ? AND offer_id = 'synthetic-offer-0000'",
             "MALFORMED"),
            ("UPDATE candidates SET digest = 'synthetic-corrupt-digest' WHERE candidate_id = ?", "MALFORMED"),
        )
        for statement, code in mutations:
            with self.subTest(statement=statement):
                candidate = self.guard.stage(snapshot(offers(21)), expected_parent=old, worker_token=1)
                self.sql(statement, (candidate,))
                count = self.release_count()
                self.rejected(lambda: self.guard.activate(candidate, expected_parent=old,
                                                         worker_token=1), code)
                self.assertEqual(self.release_count(), count)

    def test_matching_forged_candidate_count_cannot_hide_row_loss(self):
        old = self.baseline()
        candidate = self.guard.stage(snapshot(offers(21)), expected_parent=old, worker_token=1)
        self.sql("DELETE FROM candidate_offers WHERE candidate_id = ? AND offer_id = 'synthetic-offer-0020'",
                 (candidate,))
        self.sql("UPDATE candidates SET declared_count = 20 WHERE candidate_id = ?", (candidate,))
        self.rejected(lambda: self.guard.activate(candidate, expected_parent=old,
                                                 worker_token=1), "MALFORMED")

    def test_empty_full_is_not_mass_deletion(self):
        self.baseline()
        self.reject_stage(snapshot([]), "EMPTY_SNAPSHOT")

    def test_incomplete_full_rejects_without_changing_catalog(self):
        self.baseline()
        for value in (False, 1, "true", None):
            with self.subTest(value=value):
                data = snapshot(offers(20))
                data["manifest"]["complete"] = value
                self.reject_stage(data, "INCOMPLETE")

    def test_delta_is_explicitly_unsupported(self):
        self.baseline()
        for mode in ("delta", "incremental", "unknown"):
            with self.subTest(mode=mode):
                data = snapshot(offers(20))
                data["manifest"]["mode"] = mode
                self.reject_stage(data, "UNSUPPORTED_MODE")

    def test_schema_and_unknown_fields_reject(self):
        self.baseline()
        malformed = []
        for value in (True, 0, 2, "1"):
            data = snapshot(offers(20))
            data["manifest"]["schema_version"] = value
            malformed.append(data)
        data = snapshot(offers(20))
        data["child_name"] = "synthetic-disallowed-field"
        malformed.append(data)
        data = snapshot(offers(20))
        data["manifest"]["extra"] = True
        malformed.append(data)
        data = snapshot(offers(20))
        data["offers"][0]["extra"] = True
        malformed.append(data)
        data = snapshot(offers(20))
        del data["offers"][0]["variant_id"]
        malformed.append(data)
        for index, data in enumerate(malformed):
            with self.subTest(case=index):
                self.reject_stage(data, "MALFORMED")

    def test_container_types_reject(self):
        self.baseline()
        data = snapshot(offers(20))
        cases = [None, [], {}, {"manifest": [], "offers": data["offers"]},
                 {"manifest": data["manifest"], "offers": tuple(data["offers"])},
                 {"manifest": data["manifest"], "offers": [None] * 20}]
        for index, value in enumerate(cases):
            with self.subTest(case=index):
                self.reject_stage(value, "MALFORMED")

    def test_declared_count_types_reject(self):
        self.baseline()
        for value in (True, -1, 20.0, "20", None):
            with self.subTest(value=value):
                data = snapshot(offers(20))
                data["manifest"]["declared_count"] = value
                self.reject_stage(data, "MALFORMED")

    def test_price_and_observation_types_reject(self):
        self.baseline()
        invalid = {"price": (True, False, 0, -1, 1000.0, "1000", None, 2**63),
                   "observed_at": (True, False, -1, 1.0, "100000", None, 2**63)}
        for field, values in invalid.items():
            for value in values:
                with self.subTest(field=field, value=value):
                    data = snapshot(offers(20))
                    data["offers"][0][field] = value
                    self.reject_stage(data, "MALFORMED")

    def test_ids_are_explicit_nonempty_strings(self):
        self.baseline()
        for field in ("offer_id", "provider_id", "category_id", "model_id", "variant_id"):
            for value in ("", "   ", None, 1, True):
                with self.subTest(field=field, value=value):
                    data = snapshot(offers(20))
                    data["offers"][0][field] = value
                    self.reject_stage(data, "MALFORMED")

    def test_positive_signed64_price_round_trip(self):
        rows = offers(20)
        rows[0]["price"] = 2**63 - 1
        self.baseline(rows)
        self.assertEqual(self.current()["offers"][0]["price"], 2**63 - 1)

    def test_global_decline_is_blocked(self):
        self.baseline(offers(100))
        self.reject_stage(snapshot(offers(79)), "TOTAL_DECLINE")

    def test_global_exact_boundary_is_accepted(self):
        self.baseline(offers(100))
        self.publish(snapshot(offers(80)))
        self.assertEqual(len(self.current()["offers"]), 80)

    def test_category_boundary_and_below_despite_stable_total(self):
        category_b = "synthetic-category-b"
        baseline = offers(10) + offers(90, start=10, category=category_b)
        self.baseline(baseline)
        below = baseline[:6] + baseline[10:] + offers(4, start=100, category=category_b)
        self.reject_stage(snapshot(below), "COHORT_DECLINE")
        boundary = baseline[:7] + baseline[10:] + offers(3, start=100, category=category_b)
        self.publish(snapshot(boundary))
        counts = sum(row["category_id"] == "synthetic-category-a"
                     for row in self.current()["offers"])
        self.assertEqual(counts, 7)
        self.assertEqual(len(self.current()["offers"]), 100)

    def test_provider_boundary_and_below_despite_stable_total(self):
        provider_b = "synthetic-provider-b"
        baseline = offers(10) + offers(90, start=10, provider=provider_b)
        self.baseline(baseline)
        below = baseline[:6] + baseline[10:] + offers(4, start=100, provider=provider_b)
        self.reject_stage(snapshot(below), "COHORT_DECLINE")
        boundary = baseline[:7] + baseline[10:] + offers(3, start=100, provider=provider_b)
        self.publish(snapshot(boundary))
        self.assertEqual(sum(row["provider_id"] == "synthetic-provider-a"
                             for row in self.current()["offers"]), 7)

    def test_missing_provider_and_category_cannot_hide_in_growth(self):
        provider_b = "synthetic-provider-b"
        category_b = "synthetic-category-b"
        baseline = offers(10) + offers(90, start=10, provider=provider_b, category=category_b)
        self.baseline(baseline)
        grown = baseline[10:] + offers(20, start=100, provider=provider_b, category=category_b)
        self.assertEqual(len(grown), 110)
        self.reject_stage(snapshot(grown), "COHORT_DECLINE")

    def test_provider_category_pair_loss_despite_aggregate_growth(self):
        p_b, c_b = "synthetic-provider-b", "synthetic-category-b"
        baseline = (offers(5) + offers(5, start=5, category=c_b)
                    + offers(5, start=10, provider=p_b)
                    + offers(5, start=15, provider=p_b, category=c_b))
        self.baseline(baseline)
        candidate = (baseline[5:] + offers(5, start=20, category=c_b)
                     + offers(5, start=25, provider=p_b))
        for key in ("provider_id", "category_id"):
            for value in {row[key] for row in baseline}:
                self.assertGreaterEqual(sum(row[key] == value for row in candidate),
                                        sum(row[key] == value for row in baseline))
        self.assertEqual(len(candidate), 25)
        self.reject_stage(snapshot(candidate), "COHORT_DECLINE")

    def test_pair_exact_boundary_is_accepted(self):
        p_b, c_b = "synthetic-provider-b", "synthetic-category-b"
        baseline = (offers(10) + offers(10, start=10, category=c_b)
                    + offers(10, start=20, provider=p_b)
                    + offers(10, start=30, provider=p_b, category=c_b))
        self.baseline(baseline)
        self.reject_stage(snapshot(baseline[4:]), "COHORT_DECLINE")
        self.publish(snapshot(baseline[3:]))
        self.assertEqual(len(self.current()["offers"]), 37)

    def test_duplicate_offer_identity_is_rejected(self):
        self.baseline()
        rows = offers(20)
        rows.append(deepcopy(rows[0]))
        self.reject_stage(snapshot(rows), "IDENTITY_CHANGED")

    def test_existing_offer_identity_cannot_be_reassigned(self):
        self.baseline()
        for field in ("provider_id", "category_id", "model_id", "variant_id"):
            with self.subTest(field=field):
                rows = offers(20)
                rows[0][field] = f"synthetic-reassigned-{field}"
                self.reject_stage(snapshot(rows), "IDENTITY_CHANGED")

    def test_variant_cannot_change_model_even_for_new_offer(self):
        self.baseline()
        rows = offers(21)
        rows[-1]["variant_id"] = rows[0]["variant_id"]
        rows[-1]["model_id"] = "synthetic-unrelated-model"
        self.reject_stage(snapshot(rows), "IDENTITY_CHANGED")

    def test_model_and_variant_separation_and_multiple_offers(self):
        rows = offers(20)
        rows[1]["model_id"] = rows[0]["model_id"]  # Different explicit variant.
        rows[2]["model_id"] = rows[0]["model_id"]
        rows[2]["variant_id"] = rows[0]["variant_id"]  # Another sale of same variant.
        self.baseline(rows)
        actual = {row["offer_id"]: (row["model_id"], row["variant_id"])
                  for row in self.current()["offers"]}
        self.assertEqual(len(actual), 20)
        self.assertEqual(actual, {row["offer_id"]: (row["model_id"], row["variant_id"])
                                  for row in rows})
        self.assertNotEqual(actual[rows[0]["offer_id"]], actual[rows[1]["offer_id"]])
        self.assertEqual(actual[rows[0]["offer_id"]], actual[rows[2]["offer_id"]])
        self.assertNotEqual(actual[rows[0]["offer_id"]], actual[rows[3]["offer_id"]])

    def test_freshness_exact_boundary_and_future_observation(self):
        rows = offers(4)
        rows[0]["observed_at"] = NOW - 3599
        rows[1]["observed_at"] = NOW - 3600
        rows[2]["observed_at"] = NOW - 3601
        rows[3]["observed_at"] = NOW + 1
        self.baseline(rows)
        self.guard.set_user_state("synthetic-user", alert_enabled=True,
                                  deleted=False, consent=True)
        result = {row["offer_id"]: row for row in self.current()["offers"]}
        for index, row in enumerate(rows):
            with self.subTest(index=index):
                fresh = index == 0
                actual = result[row["offer_id"]]
                self.assertEqual(actual["fresh"], fresh)
                self.assertEqual(actual["current_price"], row["price"] if fresh else None)
                self.assertEqual(actual["notification_eligible"], fresh)
                self.assertEqual(actual["price"], row["price"])
                self.assertEqual(actual["observed_at"], row["observed_at"])
                self.assertEqual(self.guard.alert_eligible("synthetic-user", row["offer_id"],
                                                          now=NOW), fresh)

    def test_invalid_now_never_treated_as_fresh(self):
        self.baseline()
        for value in (True, False, -1, 1.0, "100000", None, 2**63):
            with self.subTest(value=value):
                with self.assertRaises(CatalogError) as caught:
                    self.guard.read_catalog(now=value)
                self.assertEqual(caught.exception.code, "MALFORMED")
                with self.assertRaises(CatalogError) as caught:
                    self.guard.alert_eligible("synthetic-user", "synthetic-offer-0000", now=value)
                self.assertEqual(caught.exception.code, "MALFORMED")

    def test_stale_lkg_after_rollback_does_not_refresh_prices(self):
        original = offers(20, observed_at=NOW - 3600)
        old = self.baseline(original)
        new = self.publish(snapshot(offers(21)))
        self.guard.set_user_state("synthetic-user", alert_enabled=True,
                                  deleted=False, consent=True)
        self.guard.rollback(old, expected_parent=new, worker_token=1)
        result = self.current()
        self.assertEqual(result["release_id"], old)
        for row in result["offers"]:
            self.assertFalse(row["fresh"])
            self.assertIsNone(row["current_price"])
            self.assertFalse(row["notification_eligible"])
            self.assertEqual(row["observed_at"], NOW - 3600)
            self.assertFalse(self.guard.alert_eligible("synthetic-user", row["offer_id"], now=NOW))

    def test_rights_revocation_before_stage_and_before_activate(self):
        self.baseline()
        candidate = self.guard.stage(snapshot(offers(21)),
                                     expected_parent=self.guard.active_release_id(), worker_token=1)
        parent = self.guard.active_release_id()
        self.guard.revoke_provider("synthetic-provider-a")
        self.assertEqual(self.current()["offers"], [])
        self.reject_stage(snapshot(offers(21)), "RIGHTS_REVOKED")
        self.rejected(lambda: self.guard.activate(candidate, expected_parent=parent,
                                                 worker_token=1), "RIGHTS_REVOKED")

    def test_rights_revocation_survives_rollback_and_reopen(self):
        rows = offers(10) + offers(10, start=10, provider="synthetic-provider-b")
        old = self.baseline(rows)
        new_rows = rows + offers(1, start=20, provider="synthetic-provider-b")
        new = self.publish(snapshot(new_rows))
        self.guard.set_user_state("synthetic-user", alert_enabled=True,
                                  deleted=False, consent=True)
        self.guard.revoke_provider("synthetic-provider-a")
        self.assertFalse(self.guard.alert_eligible("synthetic-user", rows[0]["offer_id"], now=NOW))
        self.assertTrue(self.guard.alert_eligible("synthetic-user", rows[10]["offer_id"], now=NOW))
        self.guard.rollback(old, expected_parent=new, worker_token=1)
        self.guard.close()
        self.guard = self.open_guard()
        self.assertEqual(self.current()["release_id"], old)
        self.assertEqual({row["offer_id"] for row in self.current()["offers"]},
                         {row["offer_id"] for row in rows[10:]})
        self.assertFalse(self.guard.alert_eligible("synthetic-user", rows[0]["offer_id"], now=NOW))
        self.assertTrue(self.guard.alert_eligible("synthetic-user", rows[10]["offer_id"], now=NOW))

    def test_latest_user_state_survives_rollback_and_reopen(self):
        old = self.baseline()
        names = ("synthetic-alert-off", "synthetic-deleted", "synthetic-withdrawn",
                 "synthetic-favorite-deleted")
        for name in names:
            self.guard.set_user_state(name, alert_enabled=True, deleted=False,
                                      consent=True, favorite=True)
        new = self.publish(snapshot(offers(21)))
        states = {
            names[0]: {"alert_enabled": False, "deleted": False, "consent": True, "favorite": True},
            names[1]: {"alert_enabled": True, "deleted": True, "consent": True, "favorite": True},
            names[2]: {"alert_enabled": True, "deleted": False, "consent": False, "favorite": True},
            names[3]: {"alert_enabled": True, "deleted": False, "consent": True, "favorite": False},
        }
        for name, state in states.items():
            self.guard.set_user_state(name, **state)
        self.guard.rollback(old, expected_parent=new, worker_token=1)
        self.guard.close()
        self.guard = self.open_guard()
        for name, state in states.items():
            with self.subTest(user=name):
                self.assertEqual(self.guard.user_state(name), state)
                self.assertEqual(self.guard.alert_eligible(name, "synthetic-offer-0000", now=NOW),
                                 name == names[3])  # Favorites do not force-couple alert consent.

    def test_default_user_and_unknown_offer_are_ineligible(self):
        self.baseline()
        self.assertEqual(self.guard.user_state("synthetic-unknown-user"),
                         {"alert_enabled": False, "deleted": False, "consent": False, "favorite": False})
        self.assertFalse(self.guard.alert_eligible("synthetic-unknown-user",
                                                  "synthetic-offer-0000", now=NOW))
        self.guard.set_user_state("synthetic-user", alert_enabled=True, deleted=False, consent=True)
        self.assertFalse(self.guard.alert_eligible("synthetic-user", "synthetic-unknown-offer", now=NOW))

    def test_deleted_user_cannot_be_resurrected_by_setter(self):
        self.baseline()
        self.guard.set_user_state("synthetic-user", alert_enabled=False, deleted=True,
                                  consent=False, favorite=False)
        previous = self.guard.user_state("synthetic-user")
        self.rejected(lambda: self.guard.set_user_state("synthetic-user", alert_enabled=True,
                                                       deleted=False, consent=True, favorite=True),
                      "USER_DELETED")
        self.assertEqual(self.guard.user_state("synthetic-user"), previous)

    def test_user_flags_require_real_booleans(self):
        self.baseline()
        valid = {"alert_enabled": False, "deleted": False, "consent": False, "favorite": False}
        self.guard.set_user_state("synthetic-user", **valid)
        for field in valid:
            with self.subTest(field=field):
                invalid = dict(valid, **{field: 1})
                self.rejected(lambda: self.guard.set_user_state("synthetic-user", **invalid), "MALFORMED")
                self.assertEqual(self.guard.user_state("synthetic-user"), valid)

    def test_worker_token_strict_increasing_and_signed64(self):
        for token in (True, False, 0, -1, 1, 1.0, "2", 2**63):
            with self.subTest(token=token):
                self.rejected(lambda: self.guard.claim_worker(token), "INVALID_WORKER_TOKEN")
        self.guard.claim_worker(2)
        self.rejected(lambda: self.guard.claim_worker(2), "INVALID_WORKER_TOKEN")

    def test_new_fence_rejects_old_stage_activate_and_rollback(self):
        old = self.baseline()
        candidate = self.guard.stage(snapshot(offers(21)), expected_parent=old, worker_token=1)
        independent = self.open_guard()
        independent.claim_worker(2)
        self.reject_stage(snapshot(offers(21)), "STALE_WORKER", token=1)
        self.rejected(lambda: self.guard.activate(candidate, expected_parent=old,
                                                 worker_token=1), "STALE_WORKER")
        self.rejected(lambda: self.guard.activate(candidate, expected_parent=old,
                                                 worker_token=2), "STALE_WORKER")
        self.rejected(lambda: self.guard.rollback(old, expected_parent=old,
                                                 worker_token=1), "STALE_WORKER")
        self.publish(snapshot(offers(21)), token=2)
        self.guard.close()
        self.guard = self.open_guard()
        self.rejected(lambda: self.guard.claim_worker(2), "INVALID_WORKER_TOKEN")

    def test_boolean_worker_cannot_impersonate_claimed_integer(self):
        old = self.baseline()
        candidate = self.guard.stage(snapshot(offers(21)), expected_parent=old, worker_token=1)
        self.reject_stage(snapshot(offers(21)), "INVALID_WORKER_TOKEN", token=True)
        self.rejected(lambda: self.guard.activate(candidate, expected_parent=old,
                                                 worker_token=True), "INVALID_WORKER_TOKEN")
        self.rejected(lambda: self.guard.rollback(old, expected_parent=old,
                                                 worker_token=True), "INVALID_WORKER_TOKEN")

    def test_caller_cannot_reparent_an_old_candidate(self):
        old = self.baseline()
        late = self.guard.stage(snapshot(offers(21)), expected_parent=old, worker_token=1)
        current = self.publish(snapshot(offers(22)))
        self.rejected(lambda: self.guard.activate(late, expected_parent=current,
                                                 worker_token=1), "CAS_MISMATCH")

    def test_aba_rollback_cannot_revalidate_an_old_candidate(self):
        old = self.baseline()
        late = self.guard.stage(snapshot(offers(21)), expected_parent=old, worker_token=1)
        new = self.publish(snapshot(offers(22)))
        self.guard.rollback(old, expected_parent=new, worker_token=1)
        self.guard.close()
        self.guard = self.open_guard()
        self.assertEqual(self.guard.active_release_id(), old)
        self.rejected(lambda: self.guard.activate(late, expected_parent=old,
                                                 worker_token=1), "CAS_MISMATCH")

    def test_same_release_rollback_advances_epoch_and_invalidates_candidate(self):
        old = self.baseline()
        late = self.guard.stage(snapshot(offers(21)), expected_parent=old, worker_token=1)
        epoch = self.sql("SELECT state_epoch FROM catalog_state")[0][0]
        before = self.current()
        self.guard.rollback(old, expected_parent=old, worker_token=1)
        self.assertEqual(self.current(), before)
        self.assertEqual(self.sql("SELECT state_epoch FROM catalog_state")[0][0], epoch + 1)
        self.rejected(lambda: self.guard.activate(late, expected_parent=old,
                                                 worker_token=1), "CAS_MISMATCH")
        self.assertEqual(self.sql("SELECT state_epoch FROM catalog_state")[0][0], epoch + 1)

    def test_cas_rejects_wrong_expected_parent_in_all_writes(self):
        old = self.baseline()
        candidate = self.guard.stage(snapshot(offers(21)), expected_parent=old, worker_token=1)
        self.rejected(lambda: self.guard.stage(snapshot(offers(21)), expected_parent=None,
                                              worker_token=1), "CAS_MISMATCH")
        self.rejected(lambda: self.guard.activate(candidate, expected_parent=None,
                                                 worker_token=1), "CAS_MISMATCH")
        self.rejected(lambda: self.guard.rollback(old, expected_parent=None,
                                                 worker_token=1), "CAS_MISMATCH")

    def test_simultaneous_sqlite_workers_have_one_cas_winner(self):
        old = self.baseline()
        data = [snapshot(offers(21)), snapshot(offers(22))]
        candidates = [self.guard.stage(item, expected_parent=old, worker_token=1) for item in data]
        barrier = threading.Barrier(2)
        outcomes = Queue()

        def worker(index):
            guard = None
            try:
                guard = CatalogGuard(self.db_path, policy=self.policy)
                barrier.wait(timeout=10)
                release = guard.activate(candidates[index], expected_parent=old, worker_token=1)
                outcomes.put((index, "committed", release))
            except CatalogError as exc:
                outcomes.put((index, "rejected", exc.code))
            except BaseException as exc:
                outcomes.put((index, "unexpected", repr(exc)))
            finally:
                if guard is not None:
                    guard.close()

        threads = [threading.Thread(target=worker, args=(index,), daemon=True) for index in range(2)]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join(timeout=15)
            self.assertFalse(thread.is_alive(), "Concurrent transaction failed to complete")
        self.assertEqual(outcomes.qsize(), 2)
        actual = [outcomes.get_nowait() for _ in range(2)]
        winners = [item for item in actual if item[1] == "committed"]
        losers = [item for item in actual if item[1] == "rejected"]
        self.assertEqual(len(winners), 1, actual)
        self.assertEqual(len(losers), 1, actual)
        self.assertEqual(losers[0][2], "CAS_MISMATCH")
        winner_index, _, release = winners[0]
        self.assertEqual(self.guard.active_release_id(), release)
        self.assertEqual(len(self.current()["offers"]), 21 + winner_index)
        self.assertEqual(self.release_count(), 2)
        self.guard.close()
        self.guard = self.open_guard()
        self.assertEqual(self.guard.active_release_id(), release)
        self.assertEqual({row["offer_id"] for row in self.current()["offers"]},
                         {row["offer_id"] for row in data[winner_index]["offers"]})

    def test_activate_sql_failure_rolls_back_release_and_pointer(self):
        old = self.baseline()
        candidate = self.guard.stage(snapshot(offers(21)), expected_parent=old, worker_token=1)
        before = self.current()
        epoch = self.sql("SELECT state_epoch FROM catalog_state")[0][0]
        count = self.release_count()
        self.fail_pointer_update()
        self.rejected(lambda: self.guard.activate(candidate, expected_parent=old,
                                                 worker_token=1), "TRANSACTION_FAILED")
        self.assertEqual(self.release_count(), count)
        self.assertEqual(self.sql("SELECT state_epoch FROM catalog_state")[0][0], epoch)
        reopened = self.open_guard()
        self.assertEqual(reopened.read_catalog(now=NOW), before)
        self.sql("DROP TRIGGER synthetic_qa_pointer_failure")
        release = self.guard.activate(candidate, expected_parent=old, worker_token=1)
        self.assertEqual(self.guard.active_release_id(), release)
        self.assertEqual(self.release_count(), count + 1)

    def test_rollback_sql_failure_preserves_current_release(self):
        old = self.baseline()
        current = self.publish(snapshot(offers(21)))
        count = self.release_count()
        self.fail_pointer_update()
        self.rejected(lambda: self.guard.rollback(old, expected_parent=current,
                                                 worker_token=1), "TRANSACTION_FAILED")
        self.assertEqual(self.release_count(), count)
        self.sql("DROP TRIGGER synthetic_qa_pointer_failure")
        self.assertEqual(self.guard.rollback(old, expected_parent=current, worker_token=1), old)
        self.assertEqual(self.release_count(), count)  # Rollback creates no new release.

    def test_unknown_candidates_and_releases_reject(self):
        current = self.baseline()
        self.rejected(lambda: self.guard.activate("synthetic-missing-candidate",
                                                 expected_parent=current, worker_token=1),
                      "UNKNOWN_CANDIDATE")
        self.rejected(lambda: self.guard.rollback("synthetic-missing-release",
                                                 expected_parent=current, worker_token=1),
                      "UNKNOWN_RELEASE")

    def test_published_candidate_cannot_make_duplicate_release(self):
        old = self.baseline()
        candidate = self.guard.stage(snapshot(offers(21)), expected_parent=old, worker_token=1)
        new = self.guard.activate(candidate, expected_parent=old, worker_token=1)
        self.guard.rollback(old, expected_parent=new, worker_token=1)
        count = self.release_count()
        before = self.current()
        with self.assertRaises(CatalogError) as caught:
            self.guard.activate(candidate, expected_parent=old, worker_token=1)
        # This input is both published and has an obsolete epoch after rollback.
        # The contract leaves precedence of multiple simultaneous faults unspecified.
        self.assertIn(caught.exception.code, {"ALREADY_PUBLISHED", "CAS_MISMATCH"})
        self.assertEqual(self.current(), before)
        self.assertEqual(self.release_count(), count)

    def test_missing_active_baseline_cannot_bootstrap_or_publish(self):
        old = self.baseline()
        self.sql("DELETE FROM releases WHERE release_id = ?", (old,))
        count = self.release_count()
        for bootstrap in (False, True):
            with self.subTest(bootstrap=bootstrap):
                with self.assertRaises(CatalogError) as caught:
                    self.guard.stage(snapshot(offers(20)), expected_parent=old,
                                     worker_token=1, bootstrap=bootstrap)
                self.assertEqual(caught.exception.code, "BASELINE_INVALID")
                self.assertEqual(self.sql("SELECT active_release_id FROM catalog_state")[0][0], old)
                with self.assertRaises(CatalogError) as read_error:
                    self.guard.read_catalog(now=NOW)
                self.assertEqual(read_error.exception.code, "BASELINE_INVALID")
                self.assertEqual(self.release_count(), count)

    def assert_corrupt_baseline_fails_closed(self, old):
        count = self.release_count()
        with self.assertRaises(CatalogError) as caught:
            self.guard.stage(snapshot(offers(21)), expected_parent=old, worker_token=1)
        self.assertEqual(caught.exception.code, "BASELINE_INVALID")
        self.assertEqual(self.sql("SELECT active_release_id FROM catalog_state")[0][0], old)
        self.assertEqual(self.release_count(), count)
        with self.assertRaises(CatalogError) as caught:
            self.guard.read_catalog(now=NOW)
        self.assertEqual(caught.exception.code, "BASELINE_INVALID")
        reopened = self.open_guard()
        with self.assertRaises(CatalogError) as caught:
            reopened.read_catalog(now=NOW)
        self.assertEqual(caught.exception.code, "BASELINE_INVALID")

    def test_baseline_actual_row_loss_fails_closed(self):
        old = self.baseline()
        self.sql("DELETE FROM release_offers WHERE release_id = ? AND offer_id = 'synthetic-offer-0000'", (old,))
        self.assert_corrupt_baseline_fails_closed(old)

    def test_baseline_declared_count_corruption_fails_closed(self):
        old = self.baseline()
        self.sql("UPDATE releases SET declared_count = 999 WHERE release_id = ?", (old,))
        self.assert_corrupt_baseline_fails_closed(old)

    def test_baseline_content_digest_corruption_fails_closed(self):
        old = self.baseline()
        self.sql("UPDATE release_offers SET price = 999999 WHERE release_id = ? AND offer_id = 'synthetic-offer-0000'", (old,))
        self.assert_corrupt_baseline_fails_closed(old)

    def test_missing_control_state_is_not_reinitialized_over_history(self):
        old = self.baseline()
        self.sql("DELETE FROM catalog_state")
        with self.assertRaises(CatalogError) as caught:
            self.guard.stage(snapshot(offers(21)), expected_parent=old, worker_token=1)
        self.assertEqual(caught.exception.code, "BASELINE_INVALID")
        with self.assertRaises(CatalogError) as caught:
            CatalogGuard(self.db_path, policy=self.policy)
        self.assertEqual(caught.exception.code, "BASELINE_INVALID")
        self.assertEqual(self.sql("SELECT COUNT(*) FROM catalog_state")[0][0], 0)
        self.assertEqual(self.release_count(), 1)

    def test_rollback_cannot_activate_corrupt_historical_release(self):
        old = self.baseline()
        new = self.publish(snapshot(offers(21)))
        self.sql("UPDATE release_offers SET price = 999999 WHERE release_id = ? AND offer_id = 'synthetic-offer-0000'", (old,))
        self.rejected(lambda: self.guard.rollback(old, expected_parent=new,
                                                 worker_token=1), "BASELINE_INVALID")

    def test_read_results_cannot_mutate_persisted_catalog(self):
        self.baseline()
        result = self.current()
        before = deepcopy(result)
        result["offers"][0]["price"] = -1
        result["offers"].clear()
        self.assertEqual(self.current(), before)


if __name__ == "__main__":
    unittest.main(verbosity=2)
