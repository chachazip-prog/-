"""Catalog Integrity PoC synthetic fixtures, contract date 2026-10-12 KST.

No real provider, product, image, user, child or credential data is included.
This module performs no network, filesystem or database operations.  Fixture
prices and the virtual clock do not represent current market observations.
Risk parameters are UNAPPROVED and must not become production defaults.
"""

from copy import deepcopy
from fractions import Fraction


SYNTHETIC_NOW = 100_000
UNAPPROVED_TOTAL_RATIO = Fraction(4, 5)
UNAPPROVED_COHORT_RATIO = Fraction(7, 10)
UNAPPROVED_TTL_SECONDS = 3_600
SQLITE_INT_MAX = 2**63 - 1

PROVIDER_A = "synthetic-provider-a"
PROVIDER_B = "synthetic-provider-b"
CATEGORY_A = "synthetic-category-a"
CATEGORY_B = "synthetic-category-b"
SYNTHETIC_USER_ID = "synthetic-user-a"


def make_offer(
    index,
    *,
    provider_id=PROVIDER_A,
    category_id=CATEGORY_A,
    model_id=None,
    variant_id=None,
    price=1_000,
    observed_at=SYNTHETIC_NOW,
):
    """Return one explicitly identified artificial offer, without validation.

    Deliberately malformed values can be supplied for independent guard tests.
    No model or variant matching is performed; the numeric suffix is only a
    deterministic synthetic identity, not an inference from product contents.
    """
    return {
        "offer_id": f"synthetic-offer-{index:03d}",
        "provider_id": provider_id,
        "category_id": category_id,
        "model_id": model_id if model_id is not None else f"synthetic-model-{index:03d}",
        "variant_id": (
            variant_id if variant_id is not None else f"synthetic-variant-{index:03d}"
        ),
        "price": price,
        "observed_at": observed_at,
    }


def snapshot(
    offers,
    *,
    mode="full",
    complete=True,
    declared_count=None,
    schema_version=1,
):
    """Package synthetic rows, keeping count spoofing an explicit parameter."""
    rows = deepcopy(offers)
    return {
        "manifest": {
            "schema_version": schema_version,
            "mode": mode,
            "complete": complete,
            "declared_count": len(rows) if declared_count is None else declared_count,
        },
        "offers": rows,
    }


def baseline():
    """20 offers: ten provider-A/category-A and ten provider-B/category-B."""
    rows = [make_offer(i) for i in range(10)]
    rows += [
        make_offer(i, provider_id=PROVIDER_B, category_id=CATEGORY_B)
        for i in range(10, 20)
    ]
    return snapshot(rows)


def cross_baseline():
    """20 offers: all four provider/category pairs contain exactly five."""
    rows = []
    for group, (provider_id, category_id) in enumerate(
        (
            (PROVIDER_A, CATEGORY_A),
            (PROVIDER_A, CATEGORY_B),
            (PROVIDER_B, CATEGORY_A),
            (PROVIDER_B, CATEGORY_B),
        )
    ):
        rows += [
            make_offer(
                group * 5 + offset,
                provider_id=provider_id,
                category_id=category_id,
            )
            for offset in range(5)
        ]
    return snapshot(rows)


def _build_fixtures():
    rows = baseline()["offers"]
    fixtures = {"baseline": baseline(), "cross_baseline": cross_baseline()}

    fixtures["normal_growth"] = snapshot(
        rows
        + [
            make_offer(i, provider_id=PROVIDER_B, category_id=CATEGORY_B)
            for i in range(20, 24)
        ]
    )
    updated = deepcopy(rows)
    for row in updated:
        row["price"] = 900
        row["observed_at"] = SYNTHETIC_NOW + 60
    fixtures["fresh_update"] = snapshot(updated)

    # Total 20 -> 16, each existing cohort 10 -> 8: exact total boundary passes.
    fixtures["total_boundary"] = snapshot(rows[:8] + rows[10:18])
    # Total 20 -> 14, each cohort 10 -> 7: only the total gate fails.
    fixtures["total_decline"] = snapshot(rows[:7] + rows[10:17])
    # Total preserved at 20, provider/category A reaches exact 0.7 boundary.
    fixtures["cohort_boundary"] = snapshot(
        rows[:7]
        + rows[10:]
        + [
            make_offer(i, provider_id=PROVIDER_B, category_id=CATEGORY_B)
            for i in range(20, 23)
        ]
    )
    # Total rises 20 -> 22, provider/category A falls 10 -> 6.
    fixtures["cohort_decline_total_growth"] = snapshot(
        rows[:6]
        + rows[10:]
        + [
            make_offer(i, provider_id=PROVIDER_B, category_id=CATEGORY_B)
            for i in range(20, 26)
        ]
    )
    fixtures["cohort_disappears_total_growth"] = snapshot(
        rows[10:]
        + [
            make_offer(i, provider_id=PROVIDER_B, category_id=CATEGORY_B)
            for i in range(20, 32)
        ]
    )

    # Marginal provider/category totals remain 10 each. Two pair cohorts fall
    # from five to three, proving totals alone can hide a coverage collapse.
    cross_rows = cross_baseline()["offers"]
    fixtures["cross_cohort_decline"] = snapshot(
        cross_rows[:3]
        + cross_rows[5:10]
        + cross_rows[10:15]
        + cross_rows[15:18]
        + [make_offer(i, provider_id=PROVIDER_A, category_id=CATEGORY_B) for i in (20, 21)]
        + [make_offer(i, provider_id=PROVIDER_B, category_id=CATEGORY_A) for i in (22, 23)]
    )

    fixtures["declared_count_spoof"] = snapshot(rows[:2], declared_count=20)
    fixtures["partial"] = snapshot(rows, complete=False)
    fixtures["delta_unsupported"] = snapshot(rows, mode="delta")
    fixtures["empty"] = snapshot([])
    fixtures["duplicate_offer_id"] = snapshot(rows + [deepcopy(rows[0])])

    for name, price in (
        ("bool_price", True),
        ("zero_price", 0),
        ("negative_price", -1),
        ("float_price", 1_000.0),
        ("string_price", "1000"),
        ("oversized_price", SQLITE_INT_MAX + 1),
    ):
        bad_rows = deepcopy(rows)
        bad_rows[0]["price"] = price
        fixtures[name] = snapshot(bad_rows)

    for name, observed_at in (
        ("bool_observed_at", True),
        ("negative_observed_at", -1),
        ("oversized_observed_at", SQLITE_INT_MAX + 1),
    ):
        bad_rows = deepcopy(rows)
        bad_rows[0]["observed_at"] = observed_at
        fixtures[name] = snapshot(bad_rows)

    for name, key, replacement in (
        ("blank_model_id", "model_id", "   "),
        ("provider_identity_changed", "provider_id", "synthetic-provider-other"),
        ("category_identity_changed", "category_id", "synthetic-category-other"),
        ("model_identity_changed", "model_id", "synthetic-model-other"),
        ("variant_identity_changed", "variant_id", "synthetic-variant-other"),
    ):
        bad_rows = deepcopy(rows)
        bad_rows[0][key] = replacement
        fixtures[name] = snapshot(bad_rows)

    bad_rows = deepcopy(rows)
    del bad_rows[0]["model_id"]
    fixtures["missing_model_id"] = snapshot(bad_rows)
    bad_rows = deepcopy(rows)
    bad_rows[1]["variant_id"] = bad_rows[0]["variant_id"]
    fixtures["variant_model_conflict"] = snapshot(bad_rows)

    # A second seller offer for one explicit model/variant is valid. It does
    # not merge differing options, reuse offer_id or infer matching from titles.
    extra = make_offer(
        30,
        provider_id=PROVIDER_B,
        category_id=CATEGORY_A,
        model_id=rows[0]["model_id"],
        variant_id=rows[0]["variant_id"],
    )
    fixtures["two_offers_same_variant"] = snapshot(rows + [extra])

    for name, manifest_key, value in (
        ("bool_schema_version", "schema_version", True),
        ("unsupported_schema_version", "schema_version", 2),
        ("bool_declared_count", "declared_count", True),
        ("oversized_declared_count", "declared_count", SQLITE_INT_MAX + 1),
        ("string_complete", "complete", "true"),
    ):
        bad_snapshot = snapshot(rows)
        bad_snapshot["manifest"][manifest_key] = value
        fixtures[name] = bad_snapshot

    bad_rows = deepcopy(rows)
    bad_rows[0]["unapproved_attribute"] = "synthetic-unused-value"
    fixtures["unknown_offer_field"] = snapshot(bad_rows)
    bad_snapshot = snapshot(rows)
    bad_snapshot["manifest"]["unapproved_scope"] = "synthetic-unused-scope"
    fixtures["unknown_manifest_field"] = bad_snapshot
    bad_snapshot = snapshot(rows)
    bad_snapshot["unapproved_data"] = "synthetic-unused-value"
    fixtures["unknown_snapshot_field"] = bad_snapshot

    stale_rows = deepcopy(rows)
    for row in stale_rows:
        row["observed_at"] = SYNTHETIC_NOW - UNAPPROVED_TTL_SECONDS
    fixtures["ttl_boundary_stale"] = snapshot(stale_rows)
    future_rows = deepcopy(rows)
    for row in future_rows:
        row["observed_at"] = SYNTHETIC_NOW + 1
    fixtures["future_observation"] = snapshot(future_rows)
    return fixtures


_FIXTURES = _build_fixtures()


def fixture_names():
    """Return deterministic fixture names; no asserted guard-test outcome."""
    return tuple(sorted(_FIXTURES))


def get_fixture(name):
    """Return an isolated copy so mutations cannot leak across test cases."""
    return deepcopy(_FIXTURES[name])


def user_state_fixture(name):
    """Independent synthetic state bits, never stored in catalog snapshots."""
    states = {
        "opted_in": {
            "alert_enabled": True,
            "deleted": False,
            "consent": True,
            "favorite": True,
        },
        "alerts_off": {
            "alert_enabled": False,
            "deleted": False,
            "consent": True,
            "favorite": True,
        },
        "withdrawn": {
            "alert_enabled": True,
            "deleted": False,
            "consent": False,
            "favorite": True,
        },
        "deleted": {
            "alert_enabled": False,
            "deleted": True,
            "consent": False,
            "favorite": False,
        },
        "favorite_removed": {
            "alert_enabled": False,
            "deleted": False,
            "consent": True,
            "favorite": False,
        },
    }
    return deepcopy(states[name])
