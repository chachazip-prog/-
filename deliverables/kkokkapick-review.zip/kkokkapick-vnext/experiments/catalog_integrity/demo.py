"""Run a disposable, synthetic catalog demonstration without external access."""

from datetime import datetime, timezone
import json
from pathlib import Path
import sqlite3
import tempfile

from catalog_guard import CatalogError, CatalogGuard
from fixtures import (PROVIDER_A, SYNTHETIC_NOW, SYNTHETIC_USER_ID,
                      UNAPPROVED_TTL_SECONDS, get_fixture, user_state_fixture)


def rejected(operation, expected_code):
    try:
        operation()
    except CatalogError as exc:
        if exc.code != expected_code:
            raise RuntimeError(f"Expected {expected_code}; observed {exc.code}") from exc
        return exc.code
    raise RuntimeError(f"Expected a rejection: {expected_code}")


def run_demo():
    report = {
        "report_date_kst": "2026-10-12",
        "execution_clock_utc": datetime.now(timezone.utc).isoformat(),
        "scope": "isolated stdlib SQLite synthetic demonstration",
        "policy_status": "Proposed fixture values; not user/Gate C approved",
        "synthetic_clock": SYNTHETIC_NOW,
        "external_requests": 0,
        "real_products_or_users": 0,
        "release_status": "HOLD",
        "independent_qa": "separate; this demonstration does not approve its implementation",
        "rejections": [],
    }
    with tempfile.TemporaryDirectory(prefix="kkokkapick-catalog-poc-") as directory:
        db_path = str(Path(directory) / "synthetic.sqlite3")
        guard = CatalogGuard(db_path)
        try:
            guard.claim_worker(1)
            baseline = get_fixture("baseline")
            code = rejected(lambda: guard.stage(baseline, expected_parent=None, worker_token=1),
                            "BOOTSTRAP_REQUIRED")
            report["rejections"].append({"scenario": "unapproved_bootstrap", "code": code})
            candidate = guard.stage(baseline, expected_parent=None, worker_token=1, bootstrap=True)
            if guard.active_release_id() is not None:
                raise RuntimeError("Staging changed the active catalog")
            first = guard.activate(candidate, expected_parent=None, worker_token=1)
            first_read = guard.read_catalog(now=SYNTHETIC_NOW)
            guard.set_user_state(SYNTHETIC_USER_ID, **user_state_fixture("opted_in"))
            report["bootstrap"] = {
                "stored_offers": len(first_read["offers"]),
                "fresh_current_prices": sum(row["current_price"] is not None
                                             for row in first_read["offers"]),
                "synthetic_alert_gate": guard.alert_eligible(
                    SYNTHETIC_USER_ID, baseline["offers"][0]["offer_id"], now=SYNTHETIC_NOW),
            }

            scenarios = (
                ("declared_count_spoof", "COUNT_MISMATCH"),
                ("partial", "INCOMPLETE"),
                ("delta_unsupported", "UNSUPPORTED_MODE"),
                ("empty", "EMPTY_SNAPSHOT"),
                ("bool_price", "MALFORMED"),
                ("missing_model_id", "MALFORMED"),
                ("duplicate_offer_id", "IDENTITY_CHANGED"),
                ("model_identity_changed", "IDENTITY_CHANGED"),
                ("total_decline", "TOTAL_DECLINE"),
                ("cohort_decline_total_growth", "COHORT_DECLINE"),
            )
            for name, expected in scenarios:
                code = rejected(lambda name=name: guard.stage(
                    get_fixture(name), expected_parent=first, worker_token=1), expected)
                if guard.active_release_id() != first or guard.read_catalog(now=SYNTHETIC_NOW) != first_read:
                    raise RuntimeError("A rejected candidate changed the active data")
                report["rejections"].append({"scenario": name, "code": code,
                                             "active_and_data_preserved": True})

            older_candidate = guard.stage(get_fixture("fresh_update"),
                                          expected_parent=first, worker_token=1)
            growth = get_fixture("normal_growth")
            growth_candidate = guard.stage(growth, expected_parent=first, worker_token=1)
            # Caller mutation after staging must not affect the persisted candidate.
            growth["offers"][0]["price"] = -1
            second = guard.activate(growth_candidate, expected_parent=first, worker_token=1)
            report["growth"] = {"stored_offers": len(guard.read_catalog(now=SYNTHETIC_NOW)["offers"]),
                                "caller_mutation_did_not_change_stored_candidate": True}

            guard.set_user_state(SYNTHETIC_USER_ID, alert_enabled=False, deleted=False,
                                 consent=False, favorite=False)
            deleted_user = "synthetic-user-deleted"
            guard.set_user_state(deleted_user, **user_state_fixture("deleted"))
            guard.revoke_provider(PROVIDER_A)
            guard.rollback(first, expected_parent=second, worker_token=1)
            code = rejected(lambda: guard.activate(older_candidate,
                            expected_parent=first, worker_token=1), "CAS_MISMATCH")
            report["rejections"].append({"scenario": "ABA_same_id_new_epoch", "code": code})
            guard.claim_worker(2)
            code = rejected(lambda: guard.activate(older_candidate,
                            expected_parent=first, worker_token=1), "STALE_WORKER")
            report["rejections"].append({"scenario": "persisted_newer_fence", "code": code})
            code = rejected(lambda: guard.set_user_state(deleted_user, alert_enabled=True,
                            deleted=False, consent=True), "USER_DELETED")
            report["rejections"].append({"scenario": "deletion_tombstone_reset", "code": code})

            stale = guard.read_catalog(now=SYNTHETIC_NOW + UNAPPROVED_TTL_SECONDS)
            if any(row["current_price"] is not None or row["notification_eligible"]
                   for row in stale["offers"]):
                raise RuntimeError("TTL-boundary LKG was treated as current")
            report["rollback"] = {
                "restored_original_release": guard.active_release_id() == first,
                "revoked_provider_hidden": all(row["provider_id"] != PROVIDER_A
                                                for row in stale["offers"]),
                "visible_stale_offers": len(stale["offers"]),
                "current_prices_at_TTL_boundary": 0,
                "notification_candidates_at_TTL_boundary": 0,
                "current_user_state": guard.user_state(SYNTHETIC_USER_ID),
                "deleted_user_state": guard.user_state(deleted_user),
            }
        finally:
            guard.close()

        reopened = CatalogGuard(db_path)
        try:
            if (reopened.read_catalog(now=SYNTHETIC_NOW + UNAPPROVED_TTL_SECONDS) != stale
                    or reopened.user_state(SYNTHETIC_USER_ID) != report["rollback"]["current_user_state"]
                    or not reopened.user_state(deleted_user)["deleted"]):
                raise RuntimeError("Database reopen lost catalog or latest overlays")
            with sqlite3.connect(db_path) as connection:
                epoch, token = connection.execute(
                    "SELECT state_epoch, worker_token FROM catalog_state WHERE singleton = 1"
                ).fetchone()
            report["reopen"] = {"snapshot_and_overlays_persisted": True,
                                "state_epoch": epoch, "worker_token": token}
        finally:
            reopened.close()
    report["temporary_database_removed"] = True
    report["rejection_scenarios_observed"] = len(report["rejections"])
    return report


if __name__ == "__main__":
    print(json.dumps(run_demo(), ensure_ascii=False, indent=2))
