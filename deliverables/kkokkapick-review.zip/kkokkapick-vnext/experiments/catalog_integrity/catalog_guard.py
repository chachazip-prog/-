"""Synthetic, local SQLite catalog-integrity experiment; no production adapters.

See CONTRACT.md for the deliberately narrow full-snapshot API. Ratios and TTL
are proposed fixture values, not approved operational policies.
"""

from __future__ import annotations

from collections import Counter
from contextlib import contextmanager
from dataclasses import dataclass
from fractions import Fraction
import hashlib
import json
import sqlite3
import threading
from typing import Iterator
from uuid import uuid4


MAX_SQLITE_INT = (1 << 63) - 1
IDENTITY_FIELDS = (
    "offer_id", "provider_id", "category_id", "model_id", "variant_id"
)
OFFER_FIELDS = frozenset((*IDENTITY_FIELDS, "price", "observed_at"))
MANIFEST_FIELDS = frozenset(("schema_version", "mode", "complete", "declared_count"))


class CatalogError(Exception):
    """A stable reason code without provider payloads or secret values."""

    def __init__(self, code: str, message: str = "") -> None:
        self.code = code
        super().__init__(message or code)


@dataclass(frozen=True)
class GuardPolicy:
    total_ratio: Fraction = Fraction(4, 5)
    cohort_ratio: Fraction = Fraction(7, 10)
    ttl_seconds: int = 3600

    def __post_init__(self) -> None:
        for ratio in (self.total_ratio, self.cohort_ratio):
            if not isinstance(ratio, Fraction) or not 0 < ratio <= 1:
                raise CatalogError("MALFORMED", "Ratios must be exact positive fractions <= 1")
        _integer(self.ttl_seconds, positive=True)


def _integer(value: object, *, positive: bool = False,
             code: str = "MALFORMED") -> int:
    minimum = 1 if positive else 0
    if type(value) is not int or not minimum <= value <= MAX_SQLITE_INT:
        raise CatalogError(code, "Expected a strict integer in the supported SQLite range")
    return value


def _identifier(value: object) -> str:
    if type(value) is not str or not value.strip():
        raise CatalogError("MALFORMED", "Expected a nonempty string identifier")
    return value


def _parent(value: object) -> str | None:
    return None if value is None else _identifier(value)


def _snapshot(snapshot: object) -> tuple[dict, list[dict]]:
    if type(snapshot) is not dict or set(snapshot) != {"manifest", "offers"}:
        raise CatalogError("MALFORMED", "Unexpected snapshot schema")
    manifest, offers = snapshot["manifest"], snapshot["offers"]
    if type(manifest) is not dict or set(manifest) != MANIFEST_FIELDS:
        raise CatalogError("MALFORMED", "Unexpected manifest schema")
    if type(manifest["schema_version"]) is not int or manifest["schema_version"] != 1:
        raise CatalogError("MALFORMED", "Unsupported schema version")
    if manifest["mode"] != "full":
        raise CatalogError("UNSUPPORTED_MODE", "Only complete full snapshots are supported")
    if manifest["complete"] is not True:
        raise CatalogError("INCOMPLETE", "Full completion evidence is required")
    declared = _integer(manifest["declared_count"])
    if type(offers) is not list:
        raise CatalogError("MALFORMED", "Offers must be a list")
    if len(offers) != declared:
        raise CatalogError("COUNT_MISMATCH", "Declared and actual array counts differ")
    if not offers:
        raise CatalogError("EMPTY_SNAPSHOT", "An empty full snapshot cannot be published")
    rows, seen, variants = [], set(), {}
    for offer in offers:
        if type(offer) is not dict or set(offer) != OFFER_FIELDS:
            raise CatalogError("MALFORMED", "Unexpected offer schema")
        row = {field: _identifier(offer[field]) for field in IDENTITY_FIELDS}
        row["price"] = _integer(offer["price"], positive=True)
        row["observed_at"] = _integer(offer["observed_at"])
        if row["offer_id"] in seen:
            raise CatalogError("IDENTITY_CHANGED", "Duplicate offer identifier")
        seen.add(row["offer_id"])
        variant, model = row["variant_id"], row["model_id"]
        if variant in variants and variants[variant] != model:
            raise CatalogError("IDENTITY_CHANGED", "A variant cannot belong to different models")
        variants[variant] = model
        rows.append(row)
    return dict(manifest), sorted(rows, key=lambda row: row["offer_id"])


def _digest(manifest: dict, rows: list[dict]) -> str:
    payload = json.dumps({"manifest": manifest, "offers": rows},
                         sort_keys=True, ensure_ascii=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


class CatalogGuard:
    """Thread-safe per object; separate connections serialize through SQLite.

    The database path is caller-owned. Nothing loads a real provider or user.
    Persisted fencing is a local monotone token check, not a distributed lease.
    """

    def __init__(self, db_path: str = ":memory:", policy: GuardPolicy | None = None) -> None:
        self.policy = GuardPolicy() if policy is None else policy
        if not isinstance(self.policy, GuardPolicy):
            raise CatalogError("MALFORMED", "Expected GuardPolicy")
        self._lock = threading.RLock()
        try:
            self._db = sqlite3.connect(db_path, timeout=5, isolation_level=None,
                                       check_same_thread=False)
            self._db.row_factory = sqlite3.Row
            self._db.execute("PRAGMA foreign_keys = ON")
            self._db.execute("PRAGMA busy_timeout = 5000")
            with self._transaction(write=True):
                statements = (
                    """CREATE TABLE IF NOT EXISTS catalog_state (
                        singleton INTEGER PRIMARY KEY CHECK(singleton = 1),
                        active_release_id TEXT,
                        worker_token INTEGER NOT NULL CHECK(worker_token >= 0),
                        state_epoch INTEGER NOT NULL CHECK(state_epoch >= 0))""",
                    """CREATE TABLE IF NOT EXISTS candidates (
                        candidate_id TEXT PRIMARY KEY, expected_parent TEXT,
                        parent_epoch INTEGER NOT NULL,
                        worker_token INTEGER NOT NULL, bootstrap INTEGER NOT NULL,
                        declared_count INTEGER NOT NULL, digest TEXT NOT NULL,
                        published_release_id TEXT)""",
                    """CREATE TABLE IF NOT EXISTS candidate_offers (
                        candidate_id TEXT NOT NULL REFERENCES candidates(candidate_id),
                        offer_id TEXT NOT NULL, provider_id TEXT NOT NULL,
                        category_id TEXT NOT NULL, model_id TEXT NOT NULL,
                        variant_id TEXT NOT NULL, price INTEGER NOT NULL,
                        observed_at INTEGER NOT NULL,
                        PRIMARY KEY(candidate_id, offer_id))""",
                    """CREATE TABLE IF NOT EXISTS releases (
                        release_id TEXT PRIMARY KEY, parent_release_id TEXT,
                        worker_token INTEGER NOT NULL, declared_count INTEGER NOT NULL,
                        digest TEXT NOT NULL)""",
                    """CREATE TABLE IF NOT EXISTS release_offers (
                        release_id TEXT NOT NULL REFERENCES releases(release_id),
                        offer_id TEXT NOT NULL, provider_id TEXT NOT NULL,
                        category_id TEXT NOT NULL, model_id TEXT NOT NULL,
                        variant_id TEXT NOT NULL, price INTEGER NOT NULL,
                        observed_at INTEGER NOT NULL,
                        PRIMARY KEY(release_id, offer_id))""",
                    """CREATE TABLE IF NOT EXISTS provider_revocations (
                        provider_id TEXT PRIMARY KEY)""",
                    """CREATE TABLE IF NOT EXISTS user_states (
                        user_id TEXT PRIMARY KEY, alert_enabled INTEGER NOT NULL,
                        deleted INTEGER NOT NULL, consent INTEGER NOT NULL,
                        favorite INTEGER NOT NULL)""",
                )
                for statement in statements:
                    self._db.execute(statement)
                if (self._db.execute("SELECT 1 FROM catalog_state WHERE singleton = 1").fetchone()
                        is None and self._db.execute("SELECT 1 FROM releases LIMIT 1").fetchone()):
                    raise CatalogError("BASELINE_INVALID", "Existing releases have lost control state")
                self._db.execute("""INSERT OR IGNORE INTO catalog_state
                    (singleton, active_release_id, worker_token, state_epoch)
                    VALUES (1, NULL, 0, 0)""")
        except sqlite3.Error as exc:
            raise CatalogError("TRANSACTION_FAILED", "SQLite initialization failed") from exc

    @contextmanager
    def _transaction(self, *, write: bool) -> Iterator[None]:
        with self._lock:
            try:
                self._db.execute("BEGIN IMMEDIATE" if write else "BEGIN")
                yield
                self._db.execute("COMMIT")
            except sqlite3.Error as exc:
                if self._db.in_transaction:
                    self._db.execute("ROLLBACK")
                raise CatalogError("TRANSACTION_FAILED", "SQLite transaction failed") from exc
            except BaseException:
                if self._db.in_transaction:
                    self._db.execute("ROLLBACK")
                raise

    def close(self) -> None:
        with self._lock:
            self._db.close()

    def _state(self) -> sqlite3.Row:
        state = self._db.execute("SELECT * FROM catalog_state WHERE singleton = 1").fetchone()
        if state is None:
            raise CatalogError("BASELINE_INVALID", "Catalog control state is missing")
        try:
            _integer(state["worker_token"])
            _integer(state["state_epoch"])
            _parent(state["active_release_id"])
        except CatalogError as exc:
            raise CatalogError("BASELINE_INVALID", "Catalog control state is invalid") from exc
        if (state["active_release_id"] is None
                and self._db.execute("SELECT 1 FROM releases LIMIT 1").fetchone()):
            raise CatalogError("BASELINE_INVALID", "Committed history has lost its active pointer")
        return state

    @staticmethod
    def _next_epoch(state: sqlite3.Row) -> int:
        if state["state_epoch"] >= MAX_SQLITE_INT:
            raise CatalogError("BASELINE_INVALID", "Catalog epoch cannot increase safely")
        return state["state_epoch"] + 1

    def _context(self, expected_parent: str | None, worker_token: int) -> sqlite3.Row:
        _parent(expected_parent)
        _integer(worker_token, positive=True, code="INVALID_WORKER_TOKEN")
        state = self._state()
        if state["worker_token"] != worker_token:
            raise CatalogError("STALE_WORKER", "The persisted fence no longer authorizes this worker")
        if state["active_release_id"] != expected_parent:
            raise CatalogError("CAS_MISMATCH", "The active release has changed")
        return state

    def claim_worker(self, token: int) -> None:
        token = _integer(token, positive=True, code="INVALID_WORKER_TOKEN")
        with self._transaction(write=True):
            if token <= self._state()["worker_token"]:
                raise CatalogError("INVALID_WORKER_TOKEN", "Fence claims must strictly increase")
            self._db.execute("UPDATE catalog_state SET worker_token = ? WHERE singleton = 1",
                             (token,))

    def _load_rows(self, owner: str, owner_id: str) -> list[dict]:
        # owner is an internal literal, never a caller-provided table name.
        rows = self._db.execute(
            f"SELECT {', '.join((*IDENTITY_FIELDS, 'price', 'observed_at'))} "
            f"FROM {owner}_offers WHERE {owner}_id = ? ORDER BY offer_id", (owner_id,)
        ).fetchall()
        return [dict(row) for row in rows]

    def _stored_snapshot(self, owner: str, owner_id: str, declared_count: int,
                         digest: str) -> list[dict]:
        rows = self._load_rows(owner, owner_id)
        actual = self._db.execute(
            f"SELECT COUNT(*) FROM {owner}_offers WHERE {owner}_id = ?", (owner_id,)
        ).fetchone()[0]
        manifest = {"schema_version": 1, "mode": "full", "complete": True,
                    "declared_count": declared_count}
        try:
            if actual != declared_count:
                raise CatalogError("COUNT_MISMATCH")
            _, checked = _snapshot({"manifest": manifest, "offers": rows})
            if _digest(manifest, checked) != digest:
                raise CatalogError("MALFORMED", "Stored content digest mismatch")
        except CatalogError as exc:
            code = "BASELINE_INVALID" if owner == "release" else exc.code
            raise CatalogError(code, "Stored catalog content failed integrity validation") from exc
        return checked

    def _release_rows(self, release_id: str, *, baseline: bool = False) -> list[dict]:
        release = self._db.execute("SELECT * FROM releases WHERE release_id = ?",
                                   (release_id,)).fetchone()
        if release is None:
            code = "BASELINE_INVALID" if baseline else "UNKNOWN_RELEASE"
            raise CatalogError(code, "The requested committed release is missing")
        return self._stored_snapshot("release", release_id, release["declared_count"],
                                     release["digest"])

    def _baseline(self, active: str | None, bootstrap: bool) -> list[dict]:
        if type(bootstrap) is not bool:
            raise CatalogError("MALFORMED", "Bootstrap must be boolean")
        if active is None:
            if not bootstrap:
                raise CatalogError("BOOTSTRAP_REQUIRED", "Initial publication needs explicit bootstrap")
            return []
        if bootstrap:
            raise CatalogError("BASELINE_INVALID", "Bootstrap cannot bypass an existing baseline")
        return self._release_rows(active, baseline=True)

    def _rights(self, rows: list[dict]) -> None:
        denied = {row[0] for row in self._db.execute("SELECT provider_id FROM provider_revocations")}
        if any(row["provider_id"] in denied for row in rows):
            raise CatalogError("RIGHTS_REVOKED", "Candidate includes a currently revoked provider")

    def _quality(self, rows: list[dict], baseline: list[dict]) -> None:
        old_offers = {row["offer_id"]: row for row in baseline}
        old_variants = {row["variant_id"]: row["model_id"] for row in baseline}
        for row in rows:
            old = old_offers.get(row["offer_id"])
            if old and any(row[field] != old[field] for field in IDENTITY_FIELDS):
                raise CatalogError("IDENTITY_CHANGED", "Existing offer identity cannot change")
            variant = row["variant_id"]
            if variant in old_variants and old_variants[variant] != row["model_id"]:
                raise CatalogError("IDENTITY_CHANGED", "Existing variant identity cannot change")
        if not baseline:
            return
        total = self.policy.total_ratio
        if len(rows) * total.denominator < len(baseline) * total.numerator:
            raise CatalogError("TOTAL_DECLINE", "Actual total retention fell below the fixture gate")
        ratio = self.policy.cohort_ratio
        for fields in (("provider_id",), ("category_id",), ("provider_id", "category_id")):
            old = Counter(tuple(row[field] for field in fields) for row in baseline)
            new = Counter(tuple(row[field] for field in fields) for row in rows)
            if any(new[key] * ratio.denominator < count * ratio.numerator
                   for key, count in old.items()):
                raise CatalogError("COHORT_DECLINE", "An existing cohort fell below the fixture gate")

    def _insert_offers(self, owner: str, owner_id: str, rows: list[dict]) -> None:
        columns = (*IDENTITY_FIELDS, "price", "observed_at")
        self._db.executemany(
            f"INSERT INTO {owner}_offers ({owner}_id, {', '.join(columns)}) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            ((owner_id, *(row[field] for field in columns)) for row in rows),
        )

    def stage(self, snapshot: dict, *, expected_parent: str | None,
              worker_token: int, bootstrap: bool = False) -> str:
        manifest, rows = _snapshot(snapshot)
        if type(bootstrap) is not bool:
            raise CatalogError("MALFORMED", "Bootstrap must be boolean")
        with self._transaction(write=True):
            state = self._context(expected_parent, worker_token)
            baseline = self._baseline(state["active_release_id"], bootstrap)
            self._rights(rows)
            self._quality(rows, baseline)
            candidate_id, digest = "candidate-" + uuid4().hex, _digest(manifest, rows)
            self._db.execute("""INSERT INTO candidates
                (candidate_id, expected_parent, parent_epoch, worker_token,
                 bootstrap, declared_count, digest) VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (candidate_id, expected_parent, state["state_epoch"], worker_token,
                 int(bootstrap), len(rows), digest))
            self._insert_offers("candidate", candidate_id, rows)
            self._stored_snapshot("candidate", candidate_id, manifest["declared_count"], digest)
        return candidate_id

    def activate(self, candidate_id: str, *, expected_parent: str | None,
                 worker_token: int) -> str:
        _identifier(candidate_id)
        with self._transaction(write=True):
            candidate = self._db.execute("SELECT * FROM candidates WHERE candidate_id = ?",
                                         (candidate_id,)).fetchone()
            if candidate is None:
                raise CatalogError("UNKNOWN_CANDIDATE", "Candidate does not exist")
            if candidate["published_release_id"] is not None:
                raise CatalogError("ALREADY_PUBLISHED", "A candidate cannot be published twice")
            state = self._context(expected_parent, worker_token)
            if candidate["expected_parent"] != expected_parent:
                raise CatalogError("CAS_MISMATCH", "A staged candidate cannot be rebased by changing a parent")
            if candidate["parent_epoch"] != state["state_epoch"]:
                raise CatalogError("CAS_MISMATCH", "Catalog changed after staging, even if its ID returned")
            if candidate["worker_token"] != worker_token:
                raise CatalogError("STALE_WORKER", "Candidate belongs to an older fence")
            baseline = self._baseline(state["active_release_id"], bool(candidate["bootstrap"]))
            rows = self._stored_snapshot("candidate", candidate_id, candidate["declared_count"],
                                         candidate["digest"])
            self._rights(rows)
            self._quality(rows, baseline)
            next_epoch = self._next_epoch(state)
            release_id = "release-" + uuid4().hex
            self._db.execute("""INSERT INTO releases
                (release_id, parent_release_id, worker_token, declared_count, digest)
                VALUES (?, ?, ?, ?, ?)""",
                (release_id, expected_parent, worker_token, len(rows), candidate["digest"]))
            self._insert_offers("release", release_id, rows)
            self._release_rows(release_id)
            # BEGIN IMMEDIATE protects the checked state through this commit.
            changed = self._db.execute("""UPDATE catalog_state
                SET active_release_id = ?, state_epoch = ?
                WHERE singleton = 1 AND active_release_id IS ?
                AND worker_token = ? AND state_epoch = ?""",
                (release_id, next_epoch, expected_parent, worker_token,
                 state["state_epoch"])).rowcount
            if changed != 1:
                raise CatalogError("CAS_MISMATCH", "Atomic active pointer update was rejected")
            self._db.execute("UPDATE candidates SET published_release_id = ? WHERE candidate_id = ?",
                             (release_id, candidate_id))
        return release_id

    def rollback(self, target_release_id: str, *, expected_parent: str | None,
                 worker_token: int) -> str:
        _identifier(target_release_id)
        with self._transaction(write=True):
            state = self._context(expected_parent, worker_token)
            self._release_rows(target_release_id)
            next_epoch = self._next_epoch(state)
            changed = self._db.execute("""UPDATE catalog_state
                SET active_release_id = ?, state_epoch = ?
                WHERE singleton = 1 AND active_release_id IS ?
                AND worker_token = ? AND state_epoch = ?""",
                (target_release_id, next_epoch, expected_parent, worker_token,
                 state["state_epoch"])).rowcount
            if changed != 1:
                raise CatalogError("CAS_MISMATCH", "Atomic rollback pointer update was rejected")
        return target_release_id

    def active_release_id(self) -> str | None:
        with self._transaction(write=False):
            active = self._state()["active_release_id"]
            if active is not None:
                self._release_rows(active, baseline=True)
            return active

    def _catalog(self, now: int) -> dict:
        active = self._state()["active_release_id"]
        if active is None:
            return {"release_id": None, "offers": []}
        rows = self._release_rows(active, baseline=True)
        denied = {row[0] for row in self._db.execute("SELECT provider_id FROM provider_revocations")}
        visible = []
        for row in rows:
            if row["provider_id"] in denied:
                continue
            fresh = 0 <= now - row["observed_at"] < self.policy.ttl_seconds
            visible.append({**row, "fresh": fresh,
                            "current_price": row["price"] if fresh else None,
                            "notification_eligible": fresh})
        return {"release_id": active, "offers": visible}

    def read_catalog(self, *, now: int) -> dict:
        now = _integer(now)
        with self._transaction(write=False):
            return self._catalog(now)

    def revoke_provider(self, provider_id: str) -> None:
        provider_id = _identifier(provider_id)
        with self._transaction(write=True):
            self._db.execute("INSERT OR IGNORE INTO provider_revocations(provider_id) VALUES (?)",
                             (provider_id,))

    def _user(self, user_id: str) -> dict:
        row = self._db.execute("SELECT alert_enabled, deleted, consent, favorite FROM user_states "
                               "WHERE user_id = ?", (user_id,)).fetchone()
        return {field: bool(row[field]) if row else False
                for field in ("alert_enabled", "deleted", "consent", "favorite")}

    def set_user_state(self, user_id: str, *, alert_enabled: bool, deleted: bool,
                       consent: bool, favorite: bool = False) -> None:
        user_id = _identifier(user_id)
        values = (alert_enabled, deleted, consent, favorite)
        if any(type(value) is not bool for value in values):
            raise CatalogError("MALFORMED", "User overlay values must be booleans")
        with self._transaction(write=True):
            if self._user(user_id)["deleted"] and not deleted:
                raise CatalogError("USER_DELETED", "Deletion tombstone cannot be removed")
            self._db.execute("""INSERT INTO user_states
                (user_id, alert_enabled, deleted, consent, favorite) VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(user_id) DO UPDATE SET alert_enabled = excluded.alert_enabled,
                deleted = excluded.deleted, consent = excluded.consent, favorite = excluded.favorite""",
                (user_id, *(int(value) for value in values)))

    def user_state(self, user_id: str) -> dict:
        user_id = _identifier(user_id)
        with self._transaction(write=False):
            return self._user(user_id)

    def alert_eligible(self, user_id: str, offer_id: str, *, now: int) -> bool:
        user_id, offer_id, now = _identifier(user_id), _identifier(offer_id), _integer(now)
        with self._transaction(write=False):
            state = self._user(user_id)
            catalog = self._catalog(now)
            return (state["alert_enabled"] and not state["deleted"] and state["consent"]
                    and any(row["offer_id"] == offer_id and row["notification_eligible"]
                            for row in catalog["offers"]))
