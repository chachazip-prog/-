# Catalog Integrity — 격리된 합성 데이터 PoC 계약 v1

- 기준일: **2026-10-12, Asia/Seoul**
- 작성: Source & Data Engineer. 구현: Backend Engineer. 검증: Independent QA.
- 상태: **기술 위험 실험의 실행 계약**. 제품·아키텍처·운영 정책·출시 승인 아님.
- 근거: [원문 §6.6](../../docs/source/MASTER_PROMPT.md), [데이터 전략](../../docs/data/DATA_STRATEGY.md), [POL-05/06](../../docs/product/POLICY_SPECIFICATION.md), [DEC-006/009](../../DECISIONS.md).

## 1. 허용 범위

Python 표준 라이브러리와 로컬 SQLite로 정상 스냅샷 보호, 완결성·수량·식별·신선도 Gate, CAS·fencing, rollback과 최신 권리/사용자 상태 분리를 실행 검증한다. 실제 provider·상품·이미지·회원·아동·자격증명·API·비용·외부 write가 없다. 기존 프로젝트 코드/상품 데이터도 가져오지 않는다. Gate B 전에 허용된 독립 기술 위험 PoC이며 모바일/Admin 화면 또는 실서비스 backend 구현이 아니다.

모든 fixture ID는 `synthetic-` 접두사다. 합성 시각 `SYNTHETIC_NOW`는 가상 정수 시계이며 실제 수집일이나 서비스 실행 시각이 아니다. 가격은 임의 양수 정수로만 사용하며 통화/할인/배송/수익을 주장하지 않는다. 정식 출시는 HOLD다.

실험 상수 **total retention ratio 4/5(0.8), cohort retention ratio 7/10(0.7), freshness TTL 3600초**는 **사용자·Gate C 미승인 위험 fixture 값**이다. 공식 공급처 조건, 운영 SLA, 실상품 감소 정상범위가 아니다. 앞선 DATA_STRATEGY의 다른 검토 숫자/TTL도 승인된 것이 아니므로 운영에 적용하지 않는다.

## 2. 입력 스냅샷

```python
{
    "manifest": {
        "schema_version": 1,
        "mode": "full",
        "complete": True,
        "declared_count": 20,
    },
    "offers": [
        {
            "offer_id": "synthetic-offer-000",
            "provider_id": "synthetic-provider-a",
            "category_id": "synthetic-category-a",
            "model_id": "synthetic-model-000",
            "variant_id": "synthetic-variant-000",
            "price": 1000,
            "observed_at": 100000,
        },
        # 나머지도 같은 명시적 필드 구조. declared_count는 실제 배열 길이와 같아야 한다.
    ],
}
```

- top-level 키는 정확히 `manifest`, `offers`; manifest 키도 위 네 개만 허용한다. offer 키는 위 일곱 개만 허용한다. 알 수 없는 필드를 거부하여 의미·개인정보 확장을 막는다.
- `manifest`/각 offer는 dict, `offers`는 nonempty list다. schema_version은 `type(x) is int`이며 1만 수용한다. 완결성은 정확한 boolean `True`만 수용한다.
- 이 좁은 PoC는 **완결된 full snapshot만** 수용한다. `mode="delta"` 또는 기타 mode는 `UNSUPPORTED_MODE`; `complete=False`는 `INCOMPLETE`로 거부한다. 증분 지원을 완료했다고 보고하지 않는다.
- declared_count는 nonnegative int이며 **bool은 int로 받아들이지 않는다**. 실제 배열 길이와 같아야 한다. staging 저장 후와 activation 전에도 실제 SQL row count와 대조한다. 선언된 수량을 실제 배열/저장 행보다 우선하지 않는다.
- ID 다섯 개는 비어 있지 않은 문자열이다. 공백뿐인 값은 거부한다. `price`는 strict positive int, `observed_at`는 strict nonnegative int다. boolean·float·문자열 숫자는 거부한다. 0/음수 가격은 `MALFORMED`다. SQLite 저장 정수의 상한은 `2**63-1`이며 declared_count·price·observed_at·now·worker token의 상한을 사전 검사한다. price/token은 1부터, 나머지 정수는 0부터다. 초대형 Python 정수도 SQL 저장 전에 입력 오류로 거부한다.
- 입력의 자동 title/image 매칭·model/variant 추측·정규화 병합은 하지 않는다. `offer_id`는 전역 고유다. 다른 offer가 동일 model+variant를 판매하는 것은 허용한다.
- `variant_id`는 입력과 정상 baseline에서 하나의 model_id에만 속한다. 기존 offer_id의 provider/category/model/variant를 변경하는 것을 거부한다. category 재분류·ID 재사용·병합/분리도 이 PoC에서는 지원하지 않는다. 새 모델/옵션은 명시적인 새 ID를 사용한다.
- 처음 bootstrap은 active=None인 상태에서 `bootstrap=True`로만 가능하다. 이미 active가 있거나 baseline이 손상된 상태를 bootstrap으로 우회하지 않는다.

## 3. 수량 Gate

baseline은 현재 active release의 **실제 저장 offer 행**이다. 기존 release가 가리키는 행·선언 count·baseline을 검증할 수 없으면 `BASELINE_INVALID`로 fail closed한다. 같은 full catalog 범위를 전제로 비교한다.

1. 후보 총 실제 수 ≥ baseline 실제 수 × 4/5.
2. baseline에 존재하던 각 provider, 각 category, 각 **(provider, category) 쌍**의 후보 실제 수 ≥ 해당 baseline 수 × 7/10.
3. 사라진 기존 cohort는 후보 0으로 계산한다. 새 cohort나 다른 cohort의 증가로 손실을 상쇄하지 않는다.
4. **경계값은 통과**한다. 부동소수점 반올림 대신 Fraction 또는 정수 곱 비교로 판정한다.

예: baseline 20→16은 total 경계에서 통과하며 cohort도 통과해야 한다. total 20→22로 늘어도 기존 provider/category 10→6이면 거부한다. provider/category 합계가 각각 유지되어도 특정 provider×category 5→3이면 거부한다. 이 수치는 실험 사례이며 실행 통과 결과가 아니다.

## 4. 공개 API — catalog_guard.py

```python
from fractions import Fraction

GuardPolicy(total_ratio=Fraction(4, 5),
            cohort_ratio=Fraction(7, 10),
            ttl_seconds=3600)

guard = CatalogGuard(db_path=":memory:", policy=None)
guard.claim_worker(token: int) -> None
guard.stage(snapshot: dict, *, expected_parent: str | None,
            worker_token: int, bootstrap: bool = False) -> str  # candidate ID
guard.activate(candidate_id: str, *, expected_parent: str | None,
               worker_token: int) -> str  # new committed release ID
guard.rollback(target_release_id: str, *, expected_parent: str | None,
               worker_token: int) -> str  # existing target release ID
guard.active_release_id() -> str | None
guard.read_catalog(*, now: int) -> dict
guard.revoke_provider(provider_id: str) -> None
guard.set_user_state(user_id: str, *, alert_enabled: bool, deleted: bool,
                     consent: bool, favorite: bool = False) -> None
guard.user_state(user_id: str) -> dict
guard.alert_eligible(user_id: str, offer_id: str, *, now: int) -> bool
```

`policy=None`는 위 미승인 fixture 상수를 사용한다. 외부 서비스·환경 정책 선택으로 사용하지 않는다. 구현자는 connection cleanup을 위한 `close()`를 추가할 수 있으며 실험 core 의미를 변경하지 않는다.

### stage / activate / rollback

- stage는 완결 manifest·실제 행·식별·baseline·감소 Gate를 검사한 뒤 별도 후보를 저장한다. active와 정상 offer는 변경하지 않는다. 입력 dict를 나중에 바꿔도 저장된 후보를 바꾸지 않는다.
- activate는 저장된 후보 count/내용·현재 baseline·권리·CAS·fence를 다시 검사한다. validation과 release 저장·active pointer 전환은 하나의 실제 SQLite transaction에서 처리한다.
- expected_parent는 현재 active release와 정확히 같아야 한다(None도 정확 비교). 후보가 stage 때 기록한 expected_parent와 activate 인자의 parent도 일치해야 한다. caller가 parent를 최신 것으로 바꿔 예전 후보를 우회 공개할 수 없다.
- **ABA 방어 addendum(2026-10-12)**: persisted `state_epoch`는 처음 0이며 모든 성공한 activate와 rollback에서 증가한다. stage는 현재 `parent_epoch`를 후보에 저장한다. activate는 저장 parent_epoch가 현재 state_epoch와도 정확히 같은지 검사하고 불일치 시 `CAS_MISMATCH`로 거부한다. 같은 token에서 active가 R1→R2→R1로 돌아와 ID만 같아져도 오래된 candidate를 재게시하지 않는다. rollback은 기존 release ID를 복구하므로 pointer ID 검사와 fencing token만으로 이 위험을 차단했다고 간주하지 않는다. 성공한 rollback이 이미 active인 target을 지정한 경우에도 epoch는 증가한다. epoch overflow는 상태 변경 없이 거부한다.
- `claim_worker` token은 strict positive int이며 bool 불가다. persisted 현재 token보다 **엄격히 큰** token만 claim할 수 있다. stage/activate/rollback 각각의 worker_token은 persisted current token과 정확히 같아야 한다. stage에 기록한 token과 activate token도 일치한다.
- current claimed token이 같은 두 후보가 같은 parent로 stage되는 것은 허용한다. 먼저 publish한 한 후보만 CAS를 통과하고 뒤의 후보는 거부한다. 새로운 token claim은 이전 token으로 stage된 candidate의 activate를 차단한다. guard 객체가 캐시한 token이 아니라 SQLite의 최신 상태를 확인한다.
- rollback은 **이미 정상 committed된 기존 release**를 활성 참조로 지정한다. 새 release나 새 사용자 상태를 만들지 않는다. CAS/fence/target 존재·무결성을 검사하고 실제 transaction에서 pointer만 바꾼다. 감소율 Gate는 과거 정상 release 복구에 재적용하지 않는다.
- 실패한 stage/activate/rollback은 성공으로 반환하지 않고 active pointer·정상 release data를 보존한다. SQL 오류 후 부분 release/partial active 전환이 남으면 실패다. 같은 published candidate를 다시 activate하여 새 release를 만들지 않는다.

### SQLite fault 검증 경계

PoC 검증을 위해 backend는 `catalog_state(active_release_id, worker_token, state_epoch)`와 `releases(release_id)`라는 최소 SQL 검사 경계를 제공한다. QA는 임시 DB의 `BEFORE UPDATE ON catalog_state` trigger에서 `RAISE(ABORT, ...)`를 주입해 실제 저장 실패와 원상 복구를 확인할 수 있다. 임시 DB fixture의 raw SQL에 한정하며 production schema/API/보안 설계 승인이 아니다. 별도 test fault callback은 생성하지 않는다.

### read_catalog / 가격·알림 Gate

```python
{
    "release_id": "<active committed release ID 또는 None>",
    "offers": [
        {
            # 위 offer 필드 일곱 개
            "fresh": True,
            "current_price": 1000,  # stale/future일 때 None
            "notification_eligible": True,
        },
    ],
}
```

- now는 strict nonnegative int, bool 불가다. invalid time은 `MALFORMED`로 거부한다. 유효조건은 `0 <= now-observed_at < TTL`다. **age==3600은 stale**, 미래 관측(age<0)도 ineligible이다.
- stale/future offer는 허용된 LKG 데이터로 읽을 수 있지만 `fresh=False`, `current_price=None`, `notification_eligible=False`다. 저장 `price/observed_at`를 새로 쓰지 않고 현재 최저가라고 주장하지 않는다.
- **현재 revoke overlay에 있는 provider의 offer는 읽기 결과에서 제외**한다. unknown/철회 offer에 대해 alert_eligible은 False다.
- `notification_eligible`은 가격·권리 검증을 통과한 **후속 평가 후보** 의미다. 실제 최저가 계산·가격하락 증명·이전 가격 비교·동의 종류·OS push/토큰·cooldown·전송·중복 처리를 검증했다는 의미가 아니다.
- alert_eligible은 그 후보조건에 현재 합성 user state의 `alert_enabled=True`, `deleted=False`, `consent=True`를 추가한다. 이것도 실제 발송 승인 또는 가격 알림 서비스의 완성된 자격 검사가 아니다.
- active=None이면 release_id=None, offers=[]다. 정렬은 offer_id 기준으로 일정하게 하거나 QA가 ID 기준으로 비교한다.

## 5. 현재 권리·사용자 overlay

revoke_provider는 현재 provider deny overlay를 저장하며 이 PoC에 재허가 API는 없다. **권리 차단은 rollback 이후에도 유지**한다. stage/activate의 후보에 revoke된 provider가 포함되면 `RIGHTS_REVOKED`로 거부한다. 과거 release로 rollback한 경우 pointer 자체는 복구할 수 있지만 read/alert는 항상 최신 deny overlay를 적용한다. LKG가 보관 권리를 확장하거나 법적 삭제를 면제한다는 의미가 아니다.

user state는 release에 포함하지 않는다. 사용자 ID는 합성 문자열이다. 존재하지 않는 사용자의 읽기 기본값은 `{alert_enabled: False, deleted: False, consent: False, favorite: False}`다. set_user_state는 네 boolean을 현재 값으로 대체하되 `deleted=True`를 False로 되돌리면 `USER_DELETED`로 거부한다. alert/consent/favorite은 명시적인 최신 호출로 바꿀 수 있으며 **rollback은 이를 변경하지 않는다**.

favorite은 삭제한 찜이 부활하지 않음을 증명할 합성 단일 boolean이다. 실제 상품별 찜 관계나 추천 개인정보가 아니며 알림 watch를 찜과 강제 결합하지 않는다. alert OFF·탈퇴/계정삭제·consent 철회·favorite 삭제·provider rights 철회는 새/과거 release에 상관없이 최신 상태가 우선한다. 아이 이름·정확한 생일·사진·월령 정보도 입력/fixture에 없다(DEC-006).

## 6. 오류 코드

`CatalogError.code`는 다음 식별자를 제공한다. 모든 거부는 CatalogError로 보고하며 SQLite 오류는 `TRANSACTION_FAILED`로 묶고 비밀값이나 외부 원문을 출력하지 않는다. 복수 오류 fixture는 첫 판정 순서를 의존하지 않고 활성 보존을 확인한다.

| 코드 | 의미 |
| --- | --- |
| MALFORMED | 타입·필수/추가 필드·ID·schema·가격·시각·user state 유효성 오류 |
| UNSUPPORTED_MODE / INCOMPLETE | full 외 mode / 완료 True가 아님 |
| COUNT_MISMATCH / EMPTY_SNAPSHOT | 실제 행과 declared count 불일치 / 실제 0행 |
| BOOTSTRAP_REQUIRED / BASELINE_INVALID | 최초 explicit opt-in 없음 / active 존재·손상 상태 bootstrap 또는 정상 baseline 무결성 실패 |
| TOTAL_DECLINE / COHORT_DECLINE | 총량 / 기존 provider·category·쌍 cohort 감소 Gate 실패 |
| IDENTITY_CHANGED | duplicate offer_id, variant→model 충돌, 기존 offer identity 변경 |
| CAS_MISMATCH / STALE_WORKER | expected active 불일치 / persisted 또는 staged worker token 불일치 |
| INVALID_WORKER_TOKEN | claim token invalid 또는 새 claim이 엄격히 증가하지 않음 |
| UNKNOWN_CANDIDATE / UNKNOWN_RELEASE / ALREADY_PUBLISHED | 후보/정상 release 없음 / published 후보의 재게시 |
| RIGHTS_REVOKED / USER_DELETED | 현재 deny provider 포함 / 계정 삭제 tombstone 해제 시도 |
| TRANSACTION_FAILED | SQLite 쓰기·제약·trigger 오류. active와 정상 데이터 원상 보존 필요 |

기존 정상 baseline이 있는데 caller가 bootstrap=True를 전달하면 `BASELINE_INVALID`로 거부한다. `bootstrap`은 boolean만 허용한다. 권리 overlay 때문에 상품 수를 복구할 수 없을 때 사용자 노출/alert 차단이 수량 가용성보다 우선한다.

## 7. Fixture와 검증 제출

[fixtures.py](fixtures.py)는 작은 합성 baseline과 정상 증가/총량 감소/메타데이터 위조/partial/delta/0행/타입/옵션 불일치/hidden cohort 감소 사례를 제공한다. get_fixture는 deepcopy를 반환해 테스트 간 입력 변경이 전파되지 않게 한다. QA는 이 파일을 수정하거나 자체 구현 승인하지 않고 별도의 합성 사례를 추가할 수 있다.

필수 실행 증거는 `baseline→stage→activate`, 잘못된 batch 격리·active 보존, 경계값, total 증가 중 cohort 감소, 실제 SQLite trigger failure, missing/corrupt baseline, stale/future/TTL 경계, CAS 한 승자, newer fence의 old candidate 차단, rollback 이후 rights/user overlay 보존이다. **ABA 검증**은 같은 claimed token으로 R1에서 후보 C_old와 C_new를 stage → C_new activate하여 R2 → rollback R1 → C_old activate 거부(`CAS_MISMATCH`)와 R1/epoch 유지 순서로 실행한다. 이 단계 추가 시점에는 설계 위험이며 실제 재현한 결함이라고 주장하지 않는다. 프로세스 재개나 별도 연결을 통해 저장된 상태의 지속성도 검증한다.

계약 작성, 합성 fixture 생성, 구현, 개발자 테스트, 독립 QA, Team Lead 검수, 사용자 승인은 서로 다른 상태다. 별도 결과 문서에서 실행 명령·수·실패·수정·재검증을 기록하기 전 테스트 통과라고 보고하지 않는다. PostgreSQL/ERD·운영 스케일·분산 lease·권한·보관/삭제·알림 발송·앱 품질은 이 PoC가 확정하거나 검증하지 않는다.
