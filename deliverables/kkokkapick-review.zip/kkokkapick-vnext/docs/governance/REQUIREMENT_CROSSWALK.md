# 주요 원문 구역의 정책·기능 교차 연결

기준일: 2026-10-11. 상태: Initial Crosswalk. 원문 개별 ID와 owner는 [RTM.csv](RTM.csv), 상세 수용 기준은 각 로컬 번호를 따른다. 이 표는 구현·테스트 증빙을 대신하지 않는다.

| 원문 구역 | 요구사항 해석/수용 기준 위치 | 후속 검증 그룹 |
|---|---|---|
| §0·§11~16 | Charter/AGENTS/PROJECT_PLAN, POL-10·BR-15/16 | TC-GOV-01, TC-GATE-01 |
| §1.1~1.3 | PRD 목표/사용자·BR-01/02 | TC-REQ-01 |
| §1.4 | FR 카테고리 속성 표·POL-04·BR-03 | TC-JOURNEY-01 |
| §3·§4 | MARKET_RESEARCH/UX Strategy/Design Direction/Benchmark/Personas | TC-RESEARCH-01, TC-UX-01 |
| §5.1 | FR-01 홈 정상/부분 실패/광고 미노출 | TC-JOURNEY-01 |
| §5.2~5.3 | FR-02 검색/필터·POL-03/04 | TC-JOURNEY-01 |
| §5.4 | FR-03/04 상세·판매처 이동·POL-03/07 | TC-JOURNEY-01, TC-REVENUE-01 |
| §5.5 | FR-05·POL-02/04/06·SEC-01, 세션 기본/신뢰 가능한 추천 | TC-JOURNEY-01, TC-ARCH-01 |
| §5.6 | FR-06·POL-01/02, 소셜 후보·계정 삭제 | TC-JOURNEY-01, TC-ARCH-01 |
| §5.7 | FR-07·POL-06, stale/탈퇴/동의철회/중복 발송 금지 | TC-JOURNEY-01 |
| §6.1~6.3 | Provider Assessment·POL-05·BR-07 | TC-DATA-01, TC-RESEARCH-01 |
| §6.4~6.6 | Data Strategy·FR-08·POL-05·Legacy Retrospective | TC-DATA-01 |
| §7.1~7.4 | FR-16·POL-07·Monetization/Revenue model | TC-REVENUE-01 |
| §8.1~8.7 | FR-09~15·POL-08·Security RBAC/감사 | TC-ADMIN-01 |
| §9.1~9.3 | ADR/ENVIRONMENT/COST/CI, Mobile/Backend Review·POL-09 | TC-ARCH-01 |
| §10.1~10.3 | Marketing/모델·POL-09·BR-14 | TC-BUDGET-01 |
| §2 Security 역할 | Security Plan/Data Inventory/Release Hold | TC-ARCH-01, TC-GATE-01 |

현재 수용 기준은 **제안/계획**이다. 실제 화면·API·코드·test run ID·reviewer·사용자 승인 링크를 추가한 뒤 해당 요구를 Tested/QA Passed/Approved로 올릴 수 있다. 여러 행위가 포함된 원문 항목은 하위 식별자로 더 분해하는 Gate A 작업이 남아 있다.
