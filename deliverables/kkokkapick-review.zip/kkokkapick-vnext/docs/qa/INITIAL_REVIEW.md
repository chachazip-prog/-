# 꼬까픽 vNext — Phase 0/1 독립 초기 문서 검수

- 기준일: 2026-10-11 (Asia/Seoul)
- 수행: Independent QA Engineer `/root/independent_qa`; 대상 문서의 기획·설계·구현·validator 작성자가 아님
- 범위: 원문·거버넌스·초기 정책/설계/조사/보고의 정합성, 실제 실행 근거와 상태 구분
- 현재 결과: **초기 문서 제출 수준 수용 — 미완료·가정·차단을 명시한 검토 초안**. QA 검수 범위에서 발견한 P2 문서 결함 3건은 원 담당 수정 뒤 독립 재검토로 해결했다.
- Gate A: **In Progress / 미통과**. 제품 독립 QA: **Not Started**. 공식 출시: **HOLD**.

## 1. 원래 요구사항과 실제 수행

[마스터 원문](../source/MASTER_PROMPT.md) 전체(§§0–16)를 열람했고 기존 저장소는 참고만 사용한다는 추가 지시를 확인했다. 신규 프로젝트·10개 상품군·10개 독립 역할·요구사항 전파·기획→디자인→검수→구현→QA→승인·다중 공급처/급감 보호·제휴/광고·별도 Admin·비용/50,000원 마케팅·15항목 보고·Gate A–F·HOLD를 기준으로 비교했다.

실제 읽은 자료는 root 상태/계획/결정/RTM/규칙/위험, Charter/조직/회고, Planner 4개 문서와 Market Research, UX 4개 문서, Data 2개 문서, ADR/Mobile/Backend·환경/비용/CI/Start, Security 3개 문서, Growth 2개 계획·입력/계산 도구·출력, 연구 Markdown/JSON/출처 오류·폰트/표준 기록, validator 원문과 kickoff 보고서다. 후속 최종 snapshot에서 crosswalk/추가 사용자 요구/충돌·미결정 분석, 개인정보/rollback/최근 검색 수정, 조직/상태/보고 및 network/start draft 응답 기록을 재독했다. 본 QA는 기존 앱/API·상품 수집·계약·앱/기기 실행 또는 공식 사이트 재요청을 수행하지 않았다.

## 2. 실제 명령과 결과

| 실행 시각/명령 | 실제 결과 | 판정 한계 |
|---|---|---|
| 2026-10-11 21:36:10 KST, `python3 tools/validate_project.py` | failed, source 913/RTM 913, SHA-256 `f6c9d44abfecc972bbf6c364b104ef674f02f54b5cb0da6955104e784052b336`; 작성 중 Growth/QA 파일 및 연결 대상 부재 | 초기 작성 중 snapshot 검사. pending 산출물은 구현 결함으로 집계하지 않음; 최종 재실행 필요 |
| 같은 세션, `git status --short` | 새 문서·tools는 untracked; 기존 tracked 앱/데이터 수정 없음 | 새 문서 존재만으로 원격 push/배포/승인 증거 아님 |
| 같은 세션, Python `csv.DictReader`·JSON 열람 | RTM qa_state Not Run 913, final_review Pending 913; source statement 876/Context 37; planned_test 11그룹; provider/UX/infra/security 접근 오류 확인 | source ledger 전체 항목이 atomic 기능 요구사항인 것은 아님. 실제 기능 테스트 아님 |
| 후속 검수, `python3 tools/revenue_model.py --check` | exit 0, 시나리오 15행/민감도 135행, 산술/재현성 11 checks 통과 | 작성자 모델의 CSV 재현성/산술; 실제 단가·매출·사업성·제품 QA는 미검증 |
| 후속 검수, 별도 Python Decimal 계산·JSON 교차 대조 | base MAU 1,000: 인식 가능한 제휴 가정 31,164.75원 + 광고 가정 5,335.20원 − 원가 가정 96,000원 = −59,500.05원. FinOps 준비금 포함 입력과 모델 일치; 광고/콘텐츠/도구/예비비 합계 50,000원 | 모든 값은 합성/가정. 실제 지출 0과 미측정 수익 `null` 구분 |
| 후속 검수, `sha256sum --check SNAPSHOT_SHA256.txt` (UX 연구 디렉터리)·별도 provider SHA-256 확인 | 공개 보조 문서 snapshot 7개, provider 실패 evidence 4개 일치; provider origin HTTP·excerpt는 null | 저장한 자료 무결성만 확인; 원격 정책 최신성·공급처 권리/사용 허가·UI 준수 아님 |
| 후속 검수, Mobile IDs 정규식/CSV 조회·Market 수정 줄 재독 | QA-DOC-01/02 원 담당 수정 뒤 고유 source IDs 13개 정본/원문 일치, 경쟁 축 13개 표기 | 문서 수정 범위 재검토, 제품 기능 검사 아님 |
| 후속 검수, 참고 checkout에서 Python `subprocess`의 `git show <SHA>:data/{adpick-biz-products,catalog}.json` 파싱과 `git status --porcelain=v1` | 4개 pinned SHA의 실제 원천/통합 배열 564/516→79/78→79/78→832/753 일치, 참고 checkout clean | Git 결과만 독립 재확인. 과거 API 원인·운영 DB/사용자 노출·이미지 라이브 상태·기존 앱/테스트 실행은 미확인/미실행 |
| 2026-10-11 21:45:25 KST, 최종 snapshot에서 `python3 tools/validate_project.py` | exit 0, passed, source 913/RTM 913, 51문서·errors 0, 원문 SHA-256 유지 | 경로/텍스트/ID·HOLD 자동 무결성 범위. 의미적 모든 요구 완결·Gate A 전체 승인 아님 |
| 최종 snapshot에서 `python3 tools/revenue_model.py --check` | exit 0, 15행·135행, FinOps ledger 대조 추가된 12 checks 모두 통과 | 합성 산술/출력/입력 일치만 검증. product_qa_passed=false 유지 |
| 최종 변경 재독·live agent 목록 대조 | Backend BE-C01/02 최신 상태 반영으로 QA-DOC-03 해결. 조직에서 요청10역할+추가 reviewer 분리, Draft Written/QA Reviewing 구분 | 실제 역할 실행과 문서 작성 확인; 모든 역할의 기능 구현/보안·QA·사용자 승인을 뜻하지 않음 |

validator의 scope는 원문/ID·파일 경로·허용 상태·로컬 Markdown 링크·HOLD다. 의미적 기능 완결성·법적 권리·UI·앱·실제 승인 자체는 검사하지 않는다. [Lead 저장 자동 결과](VALIDATION_RESULT.json)는 21:44:09 KST의 passed 실행이며 본 QA는 이후 최종 snapshot에서 위 명령을 별도로 실행했다. 본 QA는 도구/제품/정책/설계 파일을 수정하지 않고 배정받은 QA 문서 3개만 작성했다.

## 3. 현재 확인과 미완료

| 검토 축 | 실제 문서 검토 결과 | 남은 조건 |
|---|---|---|
| 신규/기존 경계 | 새 `/workspace/-`와 `/tmp` 참고 checkout 분리, 기존 코드·데이터 이관 없음이라는 기록 확인 | 원격/코드/배포 변화 시 재확인 |
| 실제 독립 에이전트 | 최종 조직표에서 요청10역할+추가 참고 reviewer의 서로 다른 실제 agent 경로와 산출물 확인, 7슬롯 순차 운영. QA 본인은 구현/정책 작성과 별도 실행; live 목록에서 후속 역할 실행 대조 | 초기 문서 실행이 기능 구현/승인 독립 QA 증거는 아님 |
| 원문 보존/추적 | 913행 source ledger와 원문/텍스트/ID 연결; 문맥 포함·완료율 아님을 명시 | BR/FR/POL·복합 문장 원자 수용 기준을 각 REQ-L별로 세분화; Gate A 의미적 누락 없음은 아직 입증 안 됨 |
| 승인/상태 | 최종 상태/보고에서 Gate A 미통과, B 이후/제품 QA 미시작, 출시 HOLD; 문서/CI/실행/사용자 승인 구분 | 초기 문서 검수 수용 후 Lead가 문서 검수 상태만 반영; Gate 상태 자동 변경 금지 |
| 공식 조사 | CONNECT 403과 origin HTTP 미수신/본문 없음 구분; 경쟁 관찰·가격·권리 미검증 표시 | runtime 정책 적용 뒤 동일 요청, 출처 조항/화면/확인일 확보 |
| 기존 회고 | SHA pinned Git 수량 564→79·516→78, 이미지 79/79 기록·사후 Guard와 라이브 원인/노출 미확인 구분 | 사고 로그 없이 API/DB/사용자 영향의 원인을 확정 금지 |
| 개인정보 | 수정된 PRD/FR/POL/DEC·Security/Inventory/Release/Mobile을 재독해 회원/비회원 memory/session 기본·영속화/동기화 각 off 선택 제안·최근 검색 개별/전체삭제·세션 종료 폐기 확인. UX는 저장을 보안 정책으로 연결 | session lifecycle 상세·opt-in/기간/삭제 UX는 Gate A/B/C 후속 검토이며 사용자 확대 승인 없음 |
| 데이터 | 원문 15엔터티 + CatalogRelease 추가 제안, 모델/옵션/판본/묶음 분리, 실패 batch 격리·baseline·권리 우선·원자 세대·롤백 | 실제 ERD/API·경계값/복구 fixture/공급처 테스트 없음 |
| 회원/알림/재고 | 비회원 핵심 이동 허용; stale/unknown과 판매종료 구분; 알림의 fresh/판매중/동의·OS·발송 직전 조건 | 실제 구현/기기/queued 취소·회귀 없음 |
| UX | 가설·색 대비 산술·폰트 원문과 실제 화면 QA를 구분; 사용자 Gate B 전 본격 구현 금지 | 실제 IA/시안/Figma 호환/프로토타입/사용자 검증·승인 없음 |
| 비용/사업 | 공식 요금 Unknown, MAU×상품 부하와 가상 원화 stress 입력 분리·중복 예비비 금지, Growth 최종 계획·도구 산술/CSV·기준 예시 독립 계산·50,000원 포함 항목 확인 | 실제 단가·견적·사업성/사용자 성과 측정 없음 |
| Admin/보안/운영 | 별도 비개발자 Admin 7영역·역할별 과업, RBAC/MFA/삭제/권리/악성 링크·restore 검증 계획 확인 | 코드·API/실기기·백업·운영 과업 NOT RUN |
| 최초 실행 10항목 | 실제 원문/충돌·미결정 분석/회고/조직/구조/WBS/조사계획/UX초안/초기문서/검수 경로/결정 카드 존재, 최종 경로 검사 passed | Phase 0/1 전체 완료·atomic 의미 완결 선언 불가 |
| 저장/재개 계약 | NETWORK_DRAFT_SAVE의 saved/requires_publish/19도메인과 START_DRAFT_SAVE의 start_skill만 저장·install/secret/repo 미변경 기록 재독. START_SKILL의 검증된 두 명령/기존 checkout/no-worktree/보호 규칙 확인 | runtime/published false, 실제 새 instance 검증 없음. 저장은 네트워크 접근 회복/working 앱 환경 판정 아님 |

## 4. 보고서 15항목 검토

[KICKOFF_REPORT](../reports/KICKOFF_REPORT.md)의 제목은 요청 제목과 일치한다. 단계/기준일은 머리말, 에이전트는 §3, 원래 요구사항/목표는 §1, 실제 수행·산출물/확인 방법은 §§2–10/14, 구현·검증 증거는 §10, 미완료·발견 이슈·위험/대응은 §12 및 연결 REQUIREMENTS_REVIEW/DEFECT_REGISTER, QA 결과/Lead 검수는 §11, 사용자 결정은 §13, 다음 단계는 §14에 연결된다. 14개 절의 수와 원문 15항목의 수는 동일 개념이 아니며 보고 항목 자체를 대조했다. 최종 QA/Growth/조직/실행 결과/draft 저장 경로를 다시 읽고 로컬 링크 검사를 통과했다. 원격 공개 데모·앱·CI/Figma 링크는 생성됐다고 주장하지 않으며 실제 외부 조사 링크는 차단/미확인 상태를 명시했다.

## 5. 이슈·반환·승인·다음

현재 제품 P0/P1 결함을 판정할 실행 대상은 없다. 발견한 P2 문서 결함 3건(Mobile source ID 표기·Market 조사 축 개수·Backend 과거 관찰/최신 정책 상태 구분)은 원 작성자에게 반환하고 수정 후 독립 재검토해 해결했다. **본 초기 문서 검수 범위에서 미해결 확정 결함 0건**, 최종 초기 문서 제출은 미완료·가정·차단을 명시한 초안 수준으로 수용한다. 반영 내역은 [DEFECT_REGISTER](DEFECT_REGISTER.md)에 있다. 이는 모든 원자 요구의 의미적 매핑·공식 조사·제품 기능·Gate A 전체·사용자 승인·출시 수용과 다르다.

QA는 자체 구현/정책 수정이나 사용자 승인 대행을 하지 않는다. Team Lead 통합 검수 및 사용자 결정은 별도다. 주요 위험과 다음 작업은 공식 조사 runtime 적용/재요청→정책·하위 수용 기준/원문별 RTM 의미 상세화→Gate A 검수→실제 UX/사용자 Gate B→설계/구현/독립 실행 QA/RC/법적·운영/사용자 출시 승인이다. SDK/기기·실제 보안/복구·사업/제휴·스토어·인프라 예산이 미확인이고 **제품 QA Not Started와 출시 HOLD를 유지한다.**
