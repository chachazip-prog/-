# 카탈로그 기술 PoC 결함 기록

- 보고 기준일: **2026-10-12**.
- 현재 상태: 동결된 격리 실험 범위 최종57개 테스트 통과. 최초 테스트 관측 오류1건(2 subcase error)은 수정·재검수 완료. 본 실행 범위에서 확인된 미해결 구현 결함은 없음; 서비스 전체 무결함 판정 아님.
- 범위: 격리된 합성 SQLite PoC. 기존 [초기 문서 결함 기록](DEFECT_REGISTER.md)은 변경하지 않는다.
- 수정 책임: 계약·공급 fixture는 Source/Data, 구현은 Backend. QA는 테스트·증거·독립 재검수만 수행한다.

| ID | 심각도 | 실제 실패·근거 | 담당 | 수정·독립 재검수 | 상태 |
|---|---|---|---|---|---|
| POC-QA-01 | P2, QA 테스트 관측 오류 | 최초46-run의 missing active baseline 테스트가 release 삭제 후 `active_release_id()`로 pointer를 읽어 올바른 BASELINE_INVALID를 error로 기록. Bootstrap False/True 두 subcase의 stage 거부는 예상대로 동작. [최초 traceback](catalog_poc/INITIAL_TEST_OUTPUT.txt), 당시 테스트 snapshot line631 | Independent QA, 테스트만 수정 | persisted pointer를 rawSQL로 관측하고 public read fail closed를 기대하도록 수정. 실제 최종57-run failure/error/skip0, exit0. 구현 hash 최초/최종 동일 | Resolved — 테스트 오류, Backend 구현 결함 아님 |

## 실제 실행 및 반환

- 최초: `python3 tools/run_catalog_poc.py`, 관측시각2026-10-12 20:30:49+09:00, executed46/failure0/error2/skip0/expected-failure0/exit1. [최초 JSON](catalog_poc/INITIAL_EXECUTION_RESULT.json)과 출력 SHA-256 `ba2136daa4af46ad3a0cf7ce44004eddb1ad5cc5f038e41c85164c9023dfbab1` 보존.
- 진단은 Lead·Backend에 전달했고 QA의 관측 오류임을 구분했다. QA는 구현·계약·공급 fixture·runner를 수정하지 않았다. 구현 수정 요구가 필요한 실제 결함은 이 실행에서 확인하지 않았다.
- 최종: 동일 명령, 관측시각2026-10-12 20:33:09–20:33:10+09:00, discovered/executed57/failure0/error0/skip0/expected-failure0/exit0. [최종 JSON](catalog_poc/EXECUTION_RESULT.json)과 출력 SHA-256 `2be0f37c42b8f44eb7a21e2e7f00cc8ffb93ce4b6d5ff2c1dddbd8793aa17d79`.
- 최초/최종 guard SHA-256은 모두 `4c3f80188248c145f5c6b0830f5a8b7058eb714e7ce10e8def15ba00090d737b`다. 테스트 수정과 보강 후 재실행한 결과이며 구현 변경·예외 swallow·force-pass·skip으로 통과시키지 않았다.

## 설계 위험과 미검증 범위

**ABA 설계 위험**은 Lead가 구현 검수 전 지적했고 Source/Data·Backend가 persisted state_epoch 계약 addendum을 고정했다. 최초 실행부터 실제 R1→R2→rollbackR1 뒤 old candidate가 CAS_MISMATCH로 거부됐고, 최종에는 재열기 및 동일-ID rollback epoch도 검증했다. 사전에 보강한 설계 위험을 실제 실패 재현·Backend 결함 수정 이력으로 기록하지 않는다.

생산 임계값·TTL 미승인, SQLite와 운영 PostgreSQL/검색/분산 환경 차이, 실제 권리·공급처·서비스 미검증은 범위 한계로 따로 기록한다. 제품 QA/Gate E·출시 승인으로 해석하지 않는다. 공식 출시 **HOLD**.
