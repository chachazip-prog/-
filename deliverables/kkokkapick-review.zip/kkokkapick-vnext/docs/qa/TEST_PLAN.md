# 꼬까픽 vNext — 독립 QA Test Plan

- 기준일: 2026-10-11 (Asia/Seoul)
- 작성·검수 주체: Independent QA Engineer `/root/independent_qa`
- 범위: Phase 0/1 초기 문서 검수 및 향후 Gate B–F 제품 검증 계획
- 현재 제품 테스트: **Not Started / NOT RUN**. 공식 출시: **HOLD**.
- 원문: [MASTER_PROMPT](../source/MASTER_PROMPT.md), 추적: [RTM](../governance/RTM.csv), 실행 기록: [INITIAL_REVIEW](INITIAL_REVIEW.md), 결함: [DEFECT_REGISTER](DEFECT_REGISTER.md)

## 1. 독립성·판정 경계

QA는 정책·디자인·API·제품 코드·문서 validator·수익 계산 도구를 구현하거나 수정하지 않는다. 결함은 원 작성자에게 반환하고 수정된 파일과 실제 명령 결과를 독립적으로 재검토한다. QA 계획·문서 존재·CI 성공·source ledger 913행의 일치가 Gate A 전체 통과, 제품 QA Passed, 사용자 Approved 또는 Released를 의미하지 않는다.

이번 초기 검수는 문서의 범위·사실/가정·권한/동의·승인 상태·경로·추적의 정합성만 판정한다. Gate A의 의미적 요구사항 상세 매핑, 실제 시장/공급처 원문, 미결정 정책이 남아 있으면 초기 문서 제출을 수용하더라도 Gate A는 In Progress다. 미구현 기능을 실패 테스트로 집계하거나, 미래 산출물을 지금 구현 결함으로 분류하지 않는다.

## 2. 원문 추적 그룹 — 계획과 실제 실행 구분

아래 ID는 초기 RTM `planned_test`의 그룹이다. 하나의 그룹을 모든 원문 행의 기능 검증으로 간주하지 않는다. 다중 요구 문장은 원문 `REQ-L`에 연결된 하위 수용 기준과 원자적인 테스트 케이스로 분해해야 한다. 현재 모든 제품 기능 그룹의 실행 결과는 NOT RUN이다. 문서 검수 실행만 INITIAL_REVIEW에 기록한다.

| 그룹 ID | 문서 검수/향후 검증 범위 | 근거·진입 조건 |
|---|---|---|
| TC-GOV-01 | 신규/기존 프로젝트 분리, 실제 에이전트·독립 QA, 승인/비용/외부 변경 경계, 15항목 보고 | 원문 §§0·2·11–16, Charter/조직/AGENTS/보고 |
| TC-REQ-01 | 원문 텍스트/줄 ID/경로/상태 일치; BR/FR/POL와 상세 수용 기준 연결; 추가 사용자 요구 | RTM.csv/RTM_METHOD/PRD/정책; ledger와 의미 완결성 분리 |
| TC-RESEARCH-01 | 6개 서비스·13개 조사 축, 출처·날짜·본문/화면/가설 구분, 프록시 오류와 원본 상태 구분 | 실제 원문/화면 확보 필요; 접근 실패를 조사 완료로 승격 금지 |
| TC-UX-01 | 디자인 순서, 범주별 탐색·신뢰 표시·편집 가능 산출물·한국어/접근성·사용자 승인 | Phase 2/3 실제 시안/프로토타입, Gate B 증빙 |
| TC-JOURNEY-01 | 비회원 홈→검색/필터→상세→외부 이동, 꼬까핏, 로그인·찜·알림·삭제 정상/예외 | 승인된 정책/화면/빌드/API/실제 기기 |
| TC-DATA-01 | 원문 15엔터티, variant/offer, 권리·완결성·급감·baseline·세대 일관성·신선도·롤백 | Data DQ-01~16, 권리 확인/합성 fixture 경계 |
| TC-REVENUE-01 | 클릭/전환/예상/확정/지급, 반품·대사, 광고/no-fill·동의·구매 비강제, MAU 5개 시나리오 | 실제 공급처/광고 capability 또는 명시 합성 모델 |
| TC-ADMIN-01 | 대시보드/상품/공급처/콘텐츠/회원/수익/시스템의 비개발자 역할별 과업, 서버 RBAC·감사 | 별도 Admin 구현/계정/동기화/삭제 업무 |
| TC-ARCH-01 | ADR 후보/확정 구분, 환경·SDK/Android/iOS, 보안·비용·백업/복구·1m 이상 확장 | 실제 PoC/공식 단가/권한·도구·자원 근거 |
| TC-BUDGET-01 | 마케팅 모든 포함 항목 합계 ≤50,000원, 실지출/가정 구분, CAC/채널/리텐션·민감도 | 계산 도구·입력·모델 출력·실제 승인/원장 |
| TC-GATE-01 | A–F 필수 증거/책임/실패 반환, 본격 UI 승인 경계, P0/P1 0·서명 RC·법적/사용자 출시 승인 | 실행/검수/승인 각각 독립 증거, HOLD 유지 |

## 3. 제품 기능용 원자 케이스 초안 — 모두 NOT RUN

아래는 시작 가능한 사례 묶음이며 전체 기능 테스트의 완성본이 아니다. Phase 2/4에서 모든 화면·API·관리자 행위·10개 상품군 속성/경계값을 원문별로 추가한다. FR/VF/DQ/SEC-T는 각 문서의 로컬 ID다.

| 케이스 | 조건과 기대 결과 | 대응 명세 |
|---|---|---|
| TC-HOME-01 | 프로필 없음/광고 실패/부분 공급처 실패에서 탐색 지속; 인기·신규·가격 인하 근거/표시 | FR-01, VF-08 |
| TC-SEARCH-01 | 상품명/브랜드/카테고리·한글 IME·자동완성 역순 응답, 최근 기록 삭제, 추천어 출처 | FR-02 |
| TC-FILTER-01 | 10개 상품군별 필수/누락/충돌/미적용 속성, 필터 해제·정렬·상태 복귀 | FR-02, 기능 §4, VF-01/02/12 |
| TC-DETAIL-01 | 다중 이미지 권리/오류, 브랜드/설명/소재/연령/인증/후기/가격 이력의 근거·없음·확인 중 구분 | FR-03, VF-02~04 |
| TC-VARIANT-01 | 모델·사이즈·색상·단위·판본·bundle·본품/리필·통화·배송/쿠폰 조건 차이의 오병합/최저가 금지 | FR-03/08, DQ-06/07 |
| TC-LINK-01 | 비회원 정상 HTTPS/앱 미설치/만료·미지원 deeplink/redirect; 악성 목적지는 차단, 계측 실패만으로 유효 이동 차단 없음 | FR-04, SEC-T06/07 |
| TC-PROFILE-01 | 입력·개인화 거부 시 일반 탐색; session/memory 기본, persistence/sync 기본 off; opt-in 검토 전 자동 저장/광고 전달 없음 | FR-05, POL-02, DI-01/02 |
| TC-AUTH-01 | 로그인 성공/취소/공급자 장애/만료 복귀, 타계정 격리, 동일 이메일 자동 병합 금지, 연결 철회/복구 | FR-06, VF-06, SEC-T01/09 |
| TC-FAVORITE-01 | 찜 추가/삭제·중복 탭·오프라인·동기화 실패·상품 병합/분리/숨김; 다른 옵션으로 참조 이동 없음 | FR-07, VF-06/10 |
| TC-NOTIFY-01 | fresh 같은 조건의 2개 관측값과 설정/OS 허용만 송신; stale/미확인 재고/종료/철회/탈퇴/queued/rollback·중복은 차단 | FR-07, VF-04/07, DQ-08/10, SEC-T12 |
| TC-SYNC-01 | 0건·partial 200·page/커서 누락·schema drift·count 실제 불일치·baseline 손상·역순 job·lease 만료 | FR-08, DQ-02~05/15/16, SEC-T04/05 |
| TC-PUBLISH-01 | DB/index 준비 실패·버전 혼합·parent 충돌 시 활성 버전 유지; 승인된 후보만 원자 전환 | DQ-09/10/16 |
| TC-REVOKE-01 | 계약 종료·권리/이미지 철회·리콜 후 LKG/rollback에서 해당 정보 재노출/구매/알림 없음 | POL-03/05, DQ-12/14 |
| TC-USERSTATE-01 | 찜 삭제·알림 OFF·계정 삭제·동의 철회 뒤 catalog rollback/merge 복구/DB restore에서 최신 사용자 상태 유지, 불완전 최신 상태는 복구/송신 보류 | DEC-009, POL-05, VF-10, DQ-17, SEC-T10 |
| TC-ADMIN-02 | 콘텐츠 초안/예약/게시/만료/회수, 품질 수정·숨김/복구·merge/unmerge·동기화 보류/승격 실제 업무 | FR-09~15, VF-09/10, DQ-11 |
| TC-RBAC-01 | 읽기 역할의 직접 API/전체 검색 결과 export/권한 변경 거부, 자기 고위험 승인/감사 삭제 금지, MFA/권한 회수 | SEC-T02/14, POL-08 |
| TC-REVENUE-02 | 전환 데이터 미제공·중복/replay·역순/취소/반품/통화/지급 차이에서 클릭·주문·예상·확정·지급 구분 | FR-14/16, VF-11, SEC-T08 |
| TC-AD-01 | 광고 라벨·슬롯/no-fill·요청/노출/클릭·cap, 추적 거부/미동의, 구매 비강제·닫기 혼동 없음 | FR-16, POL-07, VF-08 |
| TC-DELETE-01 | 본인 확인→세션/송신 차단→모든 sink 삭제→실패 재시도→backup 복원 재삭제; 늦은 이벤트로 부활 없음 | DI-17/18, SEC-T10 |
| TC-SECURITY-01 | OAuth/state/issuer·객체 권한·XSS/주입·SSRF·URL/HTML/압축 폭탄·secret/로그 redaction·서명·replay | SEC-T01~14 |
| TC-A11Y-01 | VoiceOver/TalkBack·키보드/포커스·200% 글자·모션 감소·색 외 라벨·대비·터치 목표·한국어 긴 이름 | UX Strategy §10, Phase 3/실제 빌드 |
| TC-VISUAL-01 | 승인한 디자인 버전과 앱/Admin 실제 캡처의 레이아웃·토큰·타입·상태/기기 비교 | Gate B 승인 자료 + 대상 build |
| TC-PERF-01 | 10k/100k/500k/1m 이상에서 한글 검색/필터/정렬·sync·메모리·배터리·이미지·작업 지연, 승인 SLA | ADR/Cost Model/성능 기준 확정 필요 |
| TC-RECOVERY-01 | 격리 백업 restore·RPO/RTO·권한/삭제/검색 일관성, catalog/API/Admin rollback·worker restart 멱등 | CI_RELEASE_PLAN, DQ-10/16 |
| TC-RC-01 | 같은 검증 SHA/config의 Android/iOS/Admin RC·서명/checksum·스토어 정책·법적/사업·운영·명시 사용자 출시 승인 | Gate E/F, RELEASE_HOLD_CHECKLIST |

## 4. 실행 기록 형식·증거 계약

실제 실행마다 케이스 ID와 원문/하위 수용 기준, 대상 commit 또는 파일 hash·build/config revision, fixture 권리/합성 여부·세대, 기기/OS/viewport/네트워크·계정 역할, 시각, 명령/직접 수행 과업, 기대/실제, PASS/FAIL/BLOCKED/NOT RUN, 원시 evidence 경로, defect ID, 수정 담당과 수정 revision, 독립 재검증 시각/결과를 기록한다. 제품 개인정보·키·원본 계약 비밀은 캡처/로그/문서에 넣지 않는다.

HTTP 200과 조항 검증, schema fixture와 실제 Provider 연동, Git 파일 이력과 런타임 사고 원인, 클릭과 구매, 모델 산술과 실제 사업성, Android/Web와 iOS RC를 각각 구분한다. 오래된 evidence는 버전·계약·정책·기기·SDK 변경 시 재검증한다. 접근 불가 링크는 blocked로 남기고 URL 존재/내용을 검증한 것처럼 보고하지 않는다.

## 5. 진입·종료와 결함 책임

Phase 0/1 문서 검수는 원문과 초안이 있으면 시작한다. 작성 중 경로는 pending으로 관리하고 최종 제출 snapshot에서 누락/링크를 다시 검사한다. Gate B에는 주요 화면/정상·예외/사용자 흐름·디자인 시스템·편집 가능한 호환 자료·프로토타입·실제 사용자 승인이 필요하다. Gate C에는 공급처 권리/ERD/API/보안/원가와 기술 PoC 증거가 필요하다.

Gate D/E 제품 실행에는 검증 가능한 build/API/Admin/fixture, 확정 수용 기준과 독립 QA 계정/기기가 필요하다. Gate E 종료는 P0/P1 **제품** 결함 0과 실제 핵심 여정·상품 데이터·기기/화면·보안/성능·회귀 결과로 판정한다. 미구현·Blocked 기능을 성공으로 제외해 분모를 줄이지 않는다. Gate F는 RC/운영·복구·법적/사업·제휴·스토어·사용자 출시 승인까지 확인한다.

문서 P0/P1은 위험한 범위 누락, 무권한 실행 허용, 거짓 QA/승인/출시 주장, 개인정보/데이터 안전정책 모순에 사용한다. 불완전 초기 상세화나 미래 설계 항목은 해당 Gate의 미완료/위험으로 별도 관리한다. 수정은 Lead 또는 해당 Planner/Designer/Data/Backend/Mobile/Security/DevOps/Growth에게 반환하며 QA는 대상 파일을 직접 고치지 않는다.

## 6. 이번 계획의 보고와 다음 작업

실제 수행은 원문·역할 문서 열람과 검증 계획 작성이다. 앱/API/Admin/공급처/기기·보안·복구 테스트는 실행하지 않았다. Lead 검수/사용자 승인 대기이며 이 계획으로 Gate를 통과시키지 않는다. 초기 실행 증거와 반환/재검토 항목은 INITIAL_REVIEW/DEFECT_REGISTER를 따르고, 다음은 최종 문서 snapshot 검수→원문별 세부 수용 기준 분해→공식 근거 확보→Gate별 실제 QA다.
