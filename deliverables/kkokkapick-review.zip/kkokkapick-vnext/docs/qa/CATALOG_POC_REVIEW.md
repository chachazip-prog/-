# 카탈로그 무결성 기술 PoC — 독립 QA 검수

- 보고 기준일: **2026-10-12**. 최초 관측 시계: `2026-10-12 11:20:51 UTC`.
- 상태: **격리된 실험 계약 범위 독립 검증 통과** — 실제 57개 unittest 실행. 제품 QA·아키텍처·운영 정책·사용자 승인 아님.
- 범위: 격리된 SQLite·합성 입력 기술 위험 PoC. 실제 상품 수집·외부 DB·주요 화면·운영 서비스·알림 발송은 범위 밖이다.
- 역할: Source/Data가 계약·공급 fixture 작성, Backend가 구현·데모 작성, 독립 QA가 테스트 작성·실행·결함 반환·재검수. QA는 구현·계약·공급 fixture를 수정하지 않는다.
- 승인 경계: 시나리오 수량 비율 `0.8`/`0.7`과 TTL `3600`은 생산 운영 승인값이 아니다. SQLite 검증은 PostgreSQL·검색 인덱스·분산 작업의 검증을 대신하지 않는다. 제품 QA/Gate E 미통과, 주요 화면 구현은 사용자 Gate B 승인 대기, 출시 **HOLD**.

## 근거와 이전 검수 보존

[사용자 원문 6.6](../source/MASTER_PROMPT.md), [데이터 전략](../data/DATA_STRATEGY.md), [DEC-009](../../DECISIONS.md)의 수량·완결성·마지막 정상 카탈로그 보존·카탈로그 한정 롤백 원칙을 재열람했다. 원문의 이미지·Provider 오류·운영자 알림 등 전체 파이프라인 요구사항을 이 작은 PoC로 완료했다고 주장하지 않는다.

이전 초기 문서 검수의 결과·증거는 고정하며 아래 파일을 변경하지 않는다. 새 기술 PoC 결과를 초기 문서 수용이나 실제 제품 QA 결과와 합치지 않는다.

| 보존 파일 | 착수 시 SHA-256 |
|---|---|
| [INITIAL_REVIEW.md](INITIAL_REVIEW.md) | `07dad942bb2f2197631cbec666d9f7603f043ec00d36b49a532f767999776aec` |
| [TEST_PLAN.md](TEST_PLAN.md) | `e4dac11cd1b5ce58f3c1d82655968df69ec8e1df9c6cf776feb178a84236a7b1` |
| [DEFECT_REGISTER.md](DEFECT_REGISTER.md) | `397236e02a0e3465f1def6f96fdcee447cc2fca22608f852c9b5f89755e6317e` |

## 검증 설계

모든 데이터는 테스트가 생성한 합성 offer이며 임시 SQLite DB에서만 쓰기한다. 선언 수량과 실제 배열 길이 불일치, 최초 baseline·명시 bootstrap, 손실·불완전 full·미지원 delta, 전체 증가 속 특정 provider/category 소실, 경계 비율, 부정 가격·bool·중복 identity, 모델/옵션 분리, 관측시각과 TTL 경계를 검사한다. 실패 시 정상 활성 포인터와 읽기 데이터가 유지되는지 함께 확인한다.

활성화·롤백은 expected parent와 persisted fencing을 검사한다. 독립 DB connection의 두 실제 thread가 barrier 뒤 동시에 동일 parent를 활성화하며 정확히 한 worker만 성공해야 한다. `sleep`, skip, expected-failure, force-pass로 통과시키지 않는다. SQL trigger가 실제 transaction을 중단시키는 실패 주입과 DB 재열기를 통해 상태 보존을 검증한다. Lead가 지적한 ABA 설계 위험도 계약 addendum으로 고정하여 R1→R2→rollback R1 뒤 이전 candidate의 재활성화를 거부하는지 검사했다. 이미 active인 동일 ID로 rollback해도 epoch가 증가하여 이전 candidate를 무효화한다.

권리 철회와 최신 사용자 설정은 release 외부의 현재 상태로 취급한다. 롤백 후 철회 provider 노출·현재 가격·알림 자격을 차단하고 alert OFF·탈퇴·동의 철회가 되살아나지 않는지 확인한다. 미래 시각·오래된 LKG에서 과거 가격은 현재 가격이나 알림 자격으로 승격하지 않는다. 알림 자격 검사는 실제 가격 하락 계산·큐·송신 검증이 아니다.

## 실행·판정

[CONTRACT.md](../../experiments/catalog_integrity/CONTRACT.md), 공급 [fixtures.py](../../experiments/catalog_integrity/fixtures.py), Backend [구현](../../experiments/catalog_integrity/catalog_guard.py)·[README](../../experiments/catalog_integrity/README.md), Lead 실행 runner를 직접 읽었다. 독립 QA의 [test_catalog_guard.py](../../experiments/catalog_integrity/tests/test_catalog_guard.py)는 별도 합성 입력을 생성하여 구현의 실제 SQLite 동작을 검증한다. 공식 상품·가격·권리·개인정보를 사용하지 않았다.

| 실행 | 관측 실행시각 (Asia/Seoul) | 실제 실행 수 | failure / error / skip / expected-failure | exit | 판정 |
|---|---|---:|---|---:|---|
| 최초 | 2026-10-12 20:30:49 | 46 | 0 / 2 / 0 / 0 | 1 | 실패, 테스트 관측 오류 진단 |
| 수정·보강 후 최종 | 2026-10-12 20:33:09–20:33:10 | 57 | 0 / 0 / 0 / 0 | 0 | 실험 계약 범위 통과 |

명령은 두 실행 모두 `python3 tools/run_catalog_poc.py`다. 최종 discovery=executed=57, loader error·unexpected success도 0이다. Python `3.12.14`, SQLite `3.53.1`에서 수행했다. 수는 unittest method 수이며 parameter subcase를 별도 기능 수·완료율로 부풀리지 않는다.

최초 실패의 두 error는 동일 테스트의 bootstrap False/True subcase에서 발생했다. 손상 fixture가 active release 행을 지운 뒤 QA가 `active_release_id()`로 pointer를 관측했는데, guard가 올바르게 `BASELINE_INVALID`로 거부했다. stage/bootstrap의 거부 자체는 예상대로 동작했다. QA는 own 테스트에서 raw SQL의 pointer 비변경 검사와 read의 fail closed 기대를 사용하도록 관측을 수정했다. 구현 수정·실패 숨김·skip 없이 재실행했다. 최초 traceback과 실패 결과를 보존하며 [결함 기록](POC_DEFECT_REGISTER.md)에서 테스트 오류와 구현 결함을 구분한다.

후보/정상 release의 실제 SQL 행·선언 수량·digest 손상, stage 저장 중 silent row loss와 SQL abort, boolean worker token, same-ID rollback epoch 등 계약 범위의 남은 우려를 추가했다. 최종 통과 후 테스트를 동결하고 관련 없는 suite로 확장하지 않았다.

| 증거 | SHA-256 |
|---|---|
| [최초 실행 결과](catalog_poc/INITIAL_EXECUTION_RESULT.json)·[출력 원문](catalog_poc/INITIAL_TEST_OUTPUT.txt) | 출력 `ba2136daa4af46ad3a0cf7ce44004eddb1ad5cc5f038e41c85164c9023dfbab1` |
| [최종 실행 결과](catalog_poc/EXECUTION_RESULT.json)·[출력 원문](catalog_poc/TEST_OUTPUT.txt) | 출력 `2be0f37c42b8f44eb7a21e2e7f00cc8ffb93ce4b6d5ff2c1dddbd8793aa17d79` |
| 동결 테스트 | `d3e05df1545b81f6a0f6c4e7d7ec652421a391aa135f05bcd748e720b1643ee6` |
| 구현 — 최초/최종 동일 | `4c3f80188248c145f5c6b0830f5a8b7058eb714e7ce10e8def15ba00090d737b` |
| 계약 — 최초/최종 동일 | `ceada0ba33a1a8cb8f736004c45eaedfe5602d3cfef67f44685a51f6797c81b0` |

전체 Source/Data fixture·demo·README·runner hash와 정확한 시작/종료 시각은 실행 JSON에 있다. 별도 읽기 검증 명령이 exit0으로 출력 원문2개·최종 source6개·runner1개·기존 초기 QA3문서의 총12개 bytes/hash 일치를 확인했다. 최종57개 실행·실패/error/skip/expected-failure/exit0도 JSON과 대조했다. 검증 후 관측 시계는 `2026-10-12 11:36:10 UTC`다. 초기 QA3문서는 착수 시와 동일하며 새 기술 검수 증거로 덮어쓰지 않았다.

| 검증 축 | 실제 상태에서 확인할 기대 |
|---|---|
| 입력·수량 | 올바른 bootstrap·증가 허용; count spoof·빈 full·partial·delta·잘못된 타입 거부; 실패 후 정상 활성 읽기 보존 |
| 손실·cohort | 전체 비율 경계; 특정 provider·category·교차 cohort 손실을 전체 증가가 숨기지 못함 |
| identity | 중복 offer 거부; 모델/옵션 매핑 혼동·변경 거부; 같은 모델/옵션의 별도 판매 offer는 보존 |
| freshness | TTL 직전 현재 가격 허용, 경계와 이후·미래 관측 현재 가격/알림 자격 차단; stale LKG timestamp 갱신 없음 |
| CAS·fencing | 같은 parent 동시 activate 정확히 한 commit; 새 persisted fence가 오래된 stage/activate/rollback 거부; ABA 및 same-ID rollback 이후 old epoch 후보 거부 |
| 복구·영속성 | committed release로 rollback; trigger 오류의 transaction 원자성; 새 connection에서도 동일 active/deny/user/fence 상태 |
| 최신 상태 | 권리 철회·alert OFF·탈퇴·동의 철회가 카탈로그 rollback으로 복원되지 않음 |

위 축은 최종 suite에서 실제 검증했다. 특히 후보 입력 21행을 stage한 후 저장 row를 삭제하거나 선언 count를 위조해도 activate가 거부하고 정상 20행을 보존했다. trigger로 실제 SQL release INSERT 뒤 pointer UPDATE를 실패시켰을 때 새 release가 남지 않았고 active/epoch가 유지되었다. 독립 SQLite 연결의 실제 두 thread 경쟁에서는 하나만 commit하고 다른 하나는 CAS_MISMATCH를 받았다. 성공 release·rights deny·최신 사용자 state·fence·epoch는 재열기 후에도 유지되었다.

## 판정과 남은 범위

독립 검수의 결론은 **동결된 계약·구현·테스트 hash의 격리 실험 범위 수용**이다. 이 실행 범위에서 확인된 미해결 구현 결함은 없으며 최초 테스트 관측 오류는 해결됐다. 작성자 자체 demo 성공으로 QA 통과를 대체하지 않았고, QA는 구현·계약·공급 fixture를 수정하지 않았다.

이 PoC는 실제 offer 행 수와 명시 모델/옵션 identity를 다루며 서비스 전체 15개 엔터티·canonical 매칭·전체 품질 Gate의 완료를 입증하지 않는다. delta는 지원 대신 안전하게 거부한다. 원문 6.6의 이미지 정상률·Provider별 오류율·운영자 알림, 공식 공급처의 완결성/권리/TTL, PostgreSQL·검색 세대·분산 lease·운영 부하·백업·삭제 sink·RBAC·실제 가격하락 및 전달·주요 여정·실기기는 미검증이다. 단일 합성 favorite boolean은 실제 상품별 찜 관계 검증도 아니다.

생산 임계값·TTL은 미승인이며 Gate A~F 통과나 사용자 Gate B 승인·출시 승인을 추가하지 않는다. 제품 독립 QA **Not Started**, 공식 출시 **HOLD**는 유지한다. 다음 운영 설계/PoC는 실제 공급처 계약·샘플, 운영 DB·검색·분산 모델, 상세 수용 기준과 별도 독립 검증이 필요하다.
