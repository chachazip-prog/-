# 꼬까픽 vNext — 독립 QA 결함·미완료 기록

기준일: 2026-10-11 (Asia/Seoul). 검토자: `/root/independent_qa`. 범위: Phase 0/1 초기 문서. 제품 QA **Not Started**, 출시 **HOLD**.

## 1. 분류와 책임

결함은 잘못된 사실/상태·위험한 정책 모순·요구 누락 등 실제 검토 문제다. 작성 중 링크/미래 설계/미구현 기능은 해당 Gate의 pending/blocked 항목으로 구분한다. P0/P1 제품 결함 0이라고 선언할 기능 테스트는 아직 실행하지 않았다. QA는 반환한 대상 파일을 직접 수정하지 않고 원 담당의 수정 후 재검토만 기록한다.

## 2. 현재 반환할 확정 결함

최종 제출 snapshot을 검토했다. 확인한 P2 문서 결함 3건은 Team Lead/원 담당에게 반환했고 해당 작성자가 수정했다. QA가 수정된 범위와 원문을 다시 읽어 모두 해결을 확인했다. **본 문서 검수 범위의 미해결 확정 결함 0건**이며 제품 결함 0건/제품 QA 통과라는 뜻은 아니다. 작성 중 알려진 경로를 제품 구현 결함으로 등록하지 않는다.

| ID | 심각도·범위 | 경로·줄/관찰·기대 | 반환 책임·수정/재검토 | 상태 |
|---|---|---|---|---|
| QA-DOC-01 | P2 / 추적 표기 | `docs/architecture/MOBILE_READINESS_REVIEW.md:14`, `:124`–`:128`에서 L34/L157/L827처럼 0-padding 없는 표기가 정본 REQ-L0034/L0157/L0827과 불일치했음 | Mobile 작성자 수정 후 QA가 13개 고유 ID의 정본 존재·원문을 Python CSV/정규식으로 독립 대조, 수정된 표 설명 재독. 모두 일치 | Resolved — 원 담당 수정 후 재검수 |
| QA-DOC-02 | P2 / 조사 범위 표기 | `docs/product/MARKET_RESEARCH.md:16`이 12개 경쟁 관점으로 표시, 원문 §3/Benchmark의 13개 축과 불일치했음 | Team Lead가 13개 경쟁 조사 축과 적용·미적용 별도 표시로 수정. QA가 원문/Benchmark와 수정 줄 재독 | Resolved — 원 담당 수정 후 재검수 |
| QA-DOC-03 | P2 / 오래된 정합성 관찰 | `docs/architecture/BACKEND_READINESS_REVIEW.md:32`–`:37`의 BE-C01/02가 초기 local/session·rollback 모호 문구를 현재 충돌처럼 설명해 이미 수정된 Product/Security와 불일치했음 | Backend 작성자가 초기 관찰→DEC-006/009→최신 문서 정합화 확인·실제 동작 NOT RUN으로 구분. QA가 수정된 §2를 PRD/FR/POL/Security/DEC와 재독; 최근 검색 삭제/세션·persistence/sync off·catalog-only/최신 상태 우선 일치 | Resolved — 원 담당 수정 후 재검수 |

## 3. pending/blocked — 결함과 구분

| ID | 상태·영향 | 증거/책임·해제 조건 |
|---|---|---|
| QA-PEND-01 | Resolved / 작성 중 링크가 최종 snapshot에서 존재 | 21:36:10 KST 첫 validator failed는 작성 중. 21:45:25 KST 독립 QA 최종 재실행은 913/913·51문서·errors 0·passed. 실제 제품 구현 검사 아님 |
| QA-PEND-02 | 수정 후 검토 — memory/session 기본·영속화/동기화 각 off 제안 확인 | QA가 PRD/기능/정책/인벤토리/보안/Release/Mobile/결정/보고 수정 구문을 실제 재독; UX는 세션 내 처리와 보안 정책 확정 연결. session lifecycle/opt-in 상세는 미래 Gate 작업 |
| QA-PEND-03 | Resolved / 최종 조직 표에서 10개 실제 역할+추가 reviewer와 작성/검수 상태 구분 | QA가 최종 AGENT_ORGANIZATION의 실제 agent 이름·산출물 경로를 재독하고 live agent 목록의 Backend/Growth/Mobile/Planner/Data/QA 활동과 대조. Draft Written은 제품 구현/승인 완료 아님 |
| QA-BLOCK-01 | 공식 경쟁/공급처/요금/스토어 원문·권리 미확인 | research JSON 실제 CONNECT 오류, 원본 HTTP/본문 없음. Lead·각 연구 담당, runtime 변경 후 요청 및 조항/화면 확보 |
| QA-BLOCK-02 | Gate A 원자적 의미 검수·하위 수용 기준 미완료 | RTM_METHOD가 coarse 구역별 연결/913 source ledger 한계를 명시. Lead/Planner/QA가 각 REQ-L→BR/FR/POL/하위 기준·케이스 구체화 |
| QA-BLOCK-03 | Gate B~F 제품 구현/실행·기기/보안/복구·RC·법적/계약/출시 승인 없음 | PROJECT_STATE/QA_STATUS/RELEASE_HOLD_CHECKLIST. 각 Gate 담당이 실제 대상/증거/검수/사용자 승인 확보 |

## 4. 재검토 계약

결함 발견→원 담당에게 관찰/기대/범위/심각도/줄 번호 전달→원 담당 수정·revision 제시→독립 QA 변경 재독·관련 검사 실제 실행→Resolved 또는 Open과 남은 영향 기록. 문서 검수 수용은 제품 QA·Gate A/B·사용자 승인·출시 HOLD 해제와 별개다. 최종 확인한 결과만 다음 기록에 추가한다.
