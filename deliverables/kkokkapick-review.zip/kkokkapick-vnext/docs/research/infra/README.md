# 인프라 조사·실행 증거

기준일은 2026-10-11 Asia/Seoul이다. DevOps & FinOps Engineer가 실제 읽기 전용 점검 결과를 저장했다.

- [RUNTIME_EVIDENCE.json](RUNTIME_EVIDENCE.json): tool 버전·resource·명령 존재·변수 이름의 presence와 관리형 상태 요약. secret 값은 포함하지 않는다.
- [FETCH_RESULTS.json](FETCH_RESULTS.json): 공식 요금/플랫폼 문서 GET 요청 URL·확인 시각·TLS/proxy 유지·실제 오류.
- [CAPACITY_MODEL.json](CAPACITY_MODEL.json): 실측 전 부하 가정과 MAU×상품 20개 조합의 계산. 무료 용량을 의미하지 않는다.
- [SCENARIO_INPUTS.json](SCENARIO_INPUTS.json): Growth 손익 민감도에 쓰는 원화 가상 지출 입력. 공급자 가격·견적·승인 예산이 아니며 20% 준비금은 포함되어 있다.

6개 공식 HTTPS destination 요청 모두 `Tunnel connection failed: 403 Forbidden`이었다. 이는 CONNECT 단계의 proxy 오류이고 공급자 HTTP response를 받은 것은 아니다. pricing 본문을 보지 못했으므로 별도의 fetched `.txt` 증거 파일은 아직 없다. 현재 요금/무료 capacity/상업 조건을 확인했다고 보고하지 않는다.

조사 재개용 domain 후보는 supabase.com, vercel.com, docs.github.com, www.cloudflare.com, docs.flutter.dev, developer.apple.com이다. 기존 unknown allowlist를 대체하지 않고 지원되는 환경 설정 workflow로 필요한 domain 추가를 검토한다. 직접 연결·TLS 비활성화·proxy 제거로 차단을 우회하지 않는다.

`RUNTIME_EVIDENCE.json`의 network state unknown은 enforced/ready로 추론할 수 없다. snapshot의 VPN false는 미설정 구성 관측이며 건강 상태 판정이 아니다. Docker daemon 응답은 실제 container network·DB·앱 동작의 증빙이 아니다. tool executable presence와 검증된 SDK·배포 capability를 구분한다.
