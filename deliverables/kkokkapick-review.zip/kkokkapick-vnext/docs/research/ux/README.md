# UX 연구 증거 기록

기준일: 2026-10-11, Asia/Seoul · 수행: 독립 UX/UI Designer 에이전트

## 수행 범위

공식 서비스 공개 페이지 6개와 공식 GitHub 기반 접근성/폰트 문서 7개에 실제 HTTPS GET 요청을 실행했다. 기존 프록시와 기본 CA/TLS 검증을 유지했으며 인증·가입·게시·유료 도구·사이트 변경을 하지 않았다. 요청은 다음 형태다.

```sh
curl -L --max-time 25 --silent --show-error --output <local-file> \
  --write-out '%{http_code}\n%{url_effective}\n' <https-url>
```

TLS 비활성화 옵션은 사용하지 않았다. 경쟁사 6개 요청은 CONNECT 단계에서 차단되었으므로 대상 서버의 TLS 핸드셰이크·서버 본문 검증 완료를 의미하지 않는다. 성공한 GitHub 요청만 HTTP 200 원문을 확보했다. 기록 시각은 JSON에서 UTC ISO-8601로 보존하고 보고 기준일은 Asia/Seoul을 따른다.

원시 응답 결과·URL·종료코드·발췌는 [manifest.json](manifest.json)에 있다. 기록은 네트워크 응답의 증거이지 해당 제품 UX의 검수 기록이 아니다. 비밀값·개인정보·로그인 쿠키를 수집하지 않았다.

확보한 공개 문서 스냅샷의 SHA-256은 [SNAPSHOT_SHA256.txt](SNAPSHOT_SHA256.txt)에 있다. 저장 이후 파일 동일성 확인용이며 당시 원격 콘텐츠의 서명 또는 변하지 않는 버전 핀을 대신하지 않는다.

## 공개 서비스 요청 결과

| ID | 요청 URL | 응답/종료코드 | 확보한 증거 |
| --- | --- | --- | --- |
| mamitalk | https://mamitalk.com/ | 사이트 HTTP 000 / curl 56 | [프록시 CONNECT 403](mamitalk.json) |
| kakaotalk | https://www.kakaocorp.com/page/service/service/KakaoTalk | 사이트 HTTP 000 / curl 56 | [프록시 CONNECT 403](kakaotalk.json) |
| instagram | https://about.instagram.com/ | 사이트 HTTP 000 / curl 56 | [프록시 CONNECT 403](instagram.json) |
| karrot | https://about.daangn.com/ | 사이트 HTTP 000 / curl 56 | [프록시 CONNECT 403](karrot.json) |
| babylist | https://www.babylist.com/ | 사이트 HTTP 000 / curl 56 | [프록시 CONNECT 403](babylist.json) |
| danawa | https://www.danawa.com/ | 사이트 HTTP 000 / curl 56 | [프록시 CONNECT 403](danawa.json) |

오류 원문은 `curl: (56) CONNECT tunnel failed, response 403`이다. 출처 본문을 가져오지 못했으므로 관찰 발췌는 없고 실제 앱/웹 스크린샷도 없다. 시장 고객층·홈 배치·필터·상품 카드·수익화 방식의 확인 근거로 이 요청 결과를 사용하지 않는다. 네트워크 정책 변경 후 재검증할 작업이며 차단 우회는 하지 않았다.

## 접근 가능한 공식 보조 문서

모두 2026-10-11 확인, HTTP 200 / curl 0이다. GitHub `main`은 변경 가능한 개발 원문이며 published WCAG Recommendation을 직접 열어 검증한 상태는 아니다. 제품 접근성 목표의 보조 근거로 사용하고 실제 인증·준수 판정을 주장하지 않는다.

| 문서 | 공식 원문 URL | 관찰된 발췌 | 저장 원문/메타 |
| --- | --- | --- | --- |
| W3C WCAG 저장소 안내 | https://raw.githubusercontent.com/w3c/wcag/main/README.md | `This repository is used to develop content for WCAG 2` 및 기준별 파일 구조 | [원문](wcag-readme.txt), [메타](wcag-readme.json) |
| 대비 최소 | https://raw.githubusercontent.com/w3c/wcag/main/guidelines/sc/20/contrast-minimum.html | 텍스트 `at least 4.5:1`, 큰 글자 `at least 3:1` | [원문](wcag-contrast.txt), [메타](wcag-contrast.json) |
| 대상 크기 최소 | https://raw.githubusercontent.com/w3c/wcag/main/guidelines/sc/22/target-size-minimum.html | `at least 24 by 24 CSS pixels`, spacing/inline 등 예외 | [원문](wcag-target.txt), [메타](wcag-target.json) |
| 가려지지 않는 포커스 최소 | https://raw.githubusercontent.com/w3c/wcag/main/guidelines/sc/22/focus-not-obscured-minimum.html | 포커스 요소가 작성 콘텐츠 때문에 `not entirely hidden` | [원문](wcag-focus.txt), [메타](wcag-focus.json) |
| 글자 확대 | https://raw.githubusercontent.com/w3c/wcag/main/guidelines/sc/20/resize-text.html | `up to 200 percent without loss of content or functionality` | [원문](wcag-resize.txt), [메타](wcag-resize.json) |
| Pretendard 라이선스 | https://raw.githubusercontent.com/orioncactus/pretendard/main/LICENSE | `SIL Open Font License, Version 1.1`, Reserved Font Name `Pretendard` | [원문](pretendard-license.txt), [메타](pretendard-license.json) |
| Noto Sans CJK 라이선스 | https://raw.githubusercontent.com/notofonts/noto-cjk/main/Sans/LICENSE | `SIL Open Font License, Version 1.1` | [원문](noto-sans-license.txt), [메타](noto-sans-license.json) |

폰트 본문을 실제로 읽었지만 폰트 파일 설치·번들 배포·리네이밍은 하지 않았다. 라이선스 원문은 후보 검토용이며 최종 배포 시 정확한 배포 아티팩트의 라이선스·고지 조건을 다시 확인한다.

## 색 대비 계산

후보 6개 단색의 sRGB 상대 휘도를 계산하고 `(L1+0.05)/(L2+0.05)`로 5개 쌍을 확인했다. 결과는 [candidate-contrast.json](candidate-contrast.json)에 있다. 일반 텍스트 4.5:1 기준으로 4개 쌍은 통과하고 연보라/화이트는 1.214:1로 실패한다. 따라서 밝은 연보라는 배경 후보이고 필수 텍스트·조작 경계로 사용할 수 없다는 제한을 [디자인 방향](../../design/DESIGN_DIRECTION.md)에 기록했다.

이 계산은 실제 화면의 접근성 검사가 아니다. 글꼴·투명도·합성 이미지·포커스·상태·실제 렌더링·스크린리더·200% 확대·키보드 조작을 테스트하지 않았다.

## 완료와 미완료

실행 완료: 13개 HTTPS 요청, 요청 결과·7개 공개 문서 원문 저장, 5개 후보 색 대비 계산, 초기 UX 문서 작성.

미완료: 경쟁 서비스 본문/정책·화면·이동 관찰, 실제 보호자 연구, 와이어프레임·무드보드 이미지·고해상도 시안·프로토타입·Figma, 앱/관리자 구현·실기기 접근성/사용성 테스트, 독립 QA·Team Lead 검수·사용자 승인.

## 자료 읽는 방법과 재개

경쟁 조사 접근 상태는 [BENCHMARK_MATRIX](../../design/BENCHMARK_MATRIX.md), 초기 방향은 [UX_STRATEGY](../../design/UX_STRATEGY.md)와 [DESIGN_DIRECTION](../../design/DESIGN_DIRECTION.md), 사용자 가설은 [PERSONAS](../../design/PERSONAS.md)를 확인한다. 서술된 경쟁 패턴·페르소나를 검증된 사실로 옮기지 않는다.

재개 시 환경 정책이 바뀐 것을 확인한 뒤 해당 출처 요청을 다시 실행한다. 실제 본문이 확보되면 날짜·원문·발췌·해석을 추가한다. 앱/웹 화면은 별도의 기기·버전·로그인 상태·캡처 기록을 남긴다. 이전 차단 증거를 삭제하거나 성공으로 덮어쓰지 않는다.
