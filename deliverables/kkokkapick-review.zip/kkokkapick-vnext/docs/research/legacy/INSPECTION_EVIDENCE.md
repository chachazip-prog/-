# 기존 저장소 열람 증거

작성일: 2026-10-11 (Asia/Seoul)  
검토자: vNext Team Lead가 위임한 독립 읽기 검토 에이전트 `workflow_review`  
범위: 저장소 코드·문서·Git 이력의 읽기, 분석 문서 2개 작성  
구분: 구현 QA 승인 또는 운영 검증 실행 기록이 아니다.

## 1. 대상과 접근 결과

| 항목 | 결과 |
| --- | --- |
| 원본 저장소 | `chachazip-prog/kkokkapick` |
| 인증정보를 포함하지 않은 URL | `https://github.com/chachazip-prog/kkokkapick.git` |
| 원격 확인 | HEAD와 refs/heads/main 조회 성공, 명령 종료 코드 0 |
| 조회된 SHA | `5d831736bfb9ab8ae220caf0d050db183a5d5f43` |
| 참고용 clone | `/tmp/kkokkapick-vnext-reference` |
| clone 결과 | main 단일 브랜치 clone 성공, 종료 코드 0 |
| 로컬 HEAD | 조회된 SHA와 동일 |
| 변경 여부 | 최초·열람 후 git status --porcelain 출력 없음 |
| Git 이력 범위 | 해당 main에 도달 가능한 커밋 553개, 카탈로그 파일 변경 이력 160개 |
| 새 저장소 | `/workspace/-`, 원본 저장소와 다른 checkout |
| 접근 방법 | 상속된 HTTPS Git 경로·플랫폼 인증 사용; 토큰 요청·추출·복사 없음 |

read-only clone은 로컬 참고 사본을 만드는 작업이며 원격 저장소에는 쓰지 않았다. checkout의 일부 상품 데이터는 검토 목적으로 `/tmp`에 존재하지만 신규 프로젝트에는 옮기지 않았다. 참고 저장소를 `/workspace`의 추가 프로젝트 checkout으로 등록하지 않았다.

관리형 환경 runtime status는 `observations_current: true`, `connected/running`으로 보고됐고 network policy의 상태는 `unknown`이었다. 따라서 정책이 확정적으로 적용됐다고 주장하지 않는다. Git 접근 성공은 **위 저장소의 실제 read operation** 결과로만 입증한다. GitHub API·push·다른 저장소 접근 권한은 검증하지 않았다.

## 2. 수행한 읽기 검사

아래 명령은 실제 수행한 주요 검사의 인증정보 없는 형태다. Git trace, 환경 변수 값 dump, credential 파일 열람은 사용하지 않았다.

```bash
GIT_TERMINAL_PROMPT=0 git ls-remote https://github.com/chachazip-prog/kkokkapick.git HEAD refs/heads/main
GIT_TERMINAL_PROMPT=0 git clone --single-branch --branch main https://github.com/chachazip-prog/kkokkapick.git /tmp/kkokkapick-vnext-reference
# 이후 작업 위치: /tmp/kkokkapick-vnext-reference
git rev-parse HEAD
git status --porcelain=v1
git ls-files
git rev-list --count HEAD
git log --format='%h %cI %s' -- scripts/catalog-coverage-guard.js .github/workflows/sync-adpick-biz.yml
git log --reverse --format=%H -- data/catalog.json
git show 1ffd6404f8e8ec4250f830ffe8b76f30959eed89:data/catalog.json
git show 1313ec4cffbb2fff39fca603e58fc70236d21067:data/catalog.json
git show 1313ec4cffbb2fff39fca603e58fc70236d21067:.github/workflows/sync-adpick-biz.yml
git show 1313ec4cffbb2fff39fca603e58fc70236d21067:scripts/discover-adpick.js
```

JSON 분석은 검토자가 작성한 Python 표준 라이브러리 코드를 사용해 `git show`의 JSON을 파싱했다. 기존 저장소의 JavaScript·install/test/build/sync 명령은 실행하지 않았다. 출력은 경로·커밋·시각·수량·이미지 정상률의 집계로 제한했다.

검사 방식은 다음과 같다.

1. 파일별 선언 수량(`count`, `productCount`)과 실제 `products` 배열 길이를 독립 비교한다.
2. `data/catalog.json`을 변경한 160개 이력을 오래된 순서로 읽는다.
3. 인접 결과의 실제 배열 길이를 비교하고 직전 대비 65% 미만인 모든 감소를 출력한다. 이는 조사용 필터이며 신규 정책의 승인된 임계값이 아니다.
4. 발견한 감소 커밋에서 원천 배열 길이와 기록된 이미지 정상률을 추가 확인한다.
5. 당시 workflow/discover 코드와 사후 guard 도입 커밋의 시각을 비교한다.

## 3. 확인한 수량 증거

| 커밋 | 커밋 시각 (KST) | 원천 선언/실제 배열 | 통합 선언/실제 배열 | 기록된 원천 이미지 정상률 |
| --- | --- | ---: | ---: | ---: |
| `1ffd6404f8e8ec4250f830ffe8b76f30959eed89` | 2026-10-03 13:13:19 | 564 / 564 | 516 / 516 | 564/564 = 100% |
| `1313ec4cffbb2fff39fca603e58fc70236d21067` | 2026-10-03 14:03:06 | 79 / 79 | 78 / 78 | 79/79 = 100% |
| `8f9efb1deca2168833aa120abad7769c69dba18d` | 2026-10-03 14:17:14 | 79 / 79 | 78 / 78 | 79/79 = 100% |
| `5d831736bfb9ab8ae220caf0d050db183a5d5f43` | 2026-10-11 21:06:15 | 832 / 832 | 753 / 753 | HEAD 이미지 정상률 재검증 미실행 |

HEAD 이미지 URL의 라이브 검사는 수행하지 않았다. 저장된 과거 imageHealth 값은 당시의 기록이며 이번 네트워크 검증 결과가 아니다.

- 원천 감소율: `(564 - 79) / 564 = 85.99%`.
- 통합 감소율: `(516 - 78) / 516 = 84.88%`.
- 비교한 160개 카탈로그 변경 이력에서 조사 기준 65% 미만 감소는 위 인접 결과 1개였다. 파일에 기록되지 않은 중간 실패, 다른 브랜치, 운영 DB 변경은 분석 범위에 포함되지 않는다.
- 이전 정상 커밋의 원천 syncedAt: `2026-10-03T04:13:17.460Z`.
- 급감 커밋의 원천 syncedAt: `2026-10-03T05:03:05.814Z`.
- HEAD의 원천/통합 syncedAt: `2026-10-11T12:06:12.087Z`.

## 4. 읽은 자료와 사실 연결

모든 HEAD 경로는 아래 고정 SHA를 기준으로 한다. 링크의 원본 코드·데이터는 참고 자료이며 vNext 구현의 일부가 아니다.

기준 URL: `https://github.com/chachazip-prog/kkokkapick/blob/5d831736bfb9ab8ae220caf0d050db183a5d5f43/`

| 증거 ID | 실제 열람 경로·범위 | 확인 내용과 제한 |
| --- | --- | --- |
| E01 | [AGENTS.md](https://github.com/chachazip-prog/kkokkapick/blob/5d831736bfb9ab8ae220caf0d050db183a5d5f43/AGENTS.md), .agents/ORCHESTRATION.md 전체 | 역할, 10개 디자인 제안 규칙, 독립 QA 규칙이 문서화됨; 실행 이행을 자동 입증하지 않음 |
| E02 | README.md 전체, flutter/pubspec.yaml:1–25 | PWA 데모 설명 및 Flutter 의존성 정의; 앱 실행 안 함 |
| E03 | [scripts/discover-adpick.js](https://github.com/chachazip-prog/kkokkapick/blob/5d831736bfb9ab8ae220caf0d050db183a5d5f43/scripts/discover-adpick.js):1–93, src/adpick-discovery-plan.js:1–27 | 쿼리별 수량, 유일성, 이미지 검사를 보강한 현행 코드; 실제 API 호출 안 함 |
| E04 | src/adpick-biz-provider.js:1–52 | 알 수 없는 envelope가 빈 목록으로 정규화될 수 있음; 실제 사고 payload 미확인 |
| E05 | [scripts/catalog-coverage-guard.js](https://github.com/chachazip-prog/kkokkapick/blob/5d831736bfb9ab8ae220caf0d050db183a5d5f43/scripts/catalog-coverage-guard.js):1–68 | 300/250/0.65 Gate; 기준선 누락 허용, 선언 수량 우선, 총량 중심 |
| E06 | scripts/build-catalog.js:1–39, scripts/sync-adpick-to-json.js:1–25 | 데이터 파일 전체 재작성 경로; DB 전체 삭제를 관찰했다는 뜻이 아님 |
| E07 | [sync-adpick-biz.yml](https://github.com/chachazip-prog/kkokkapick/blob/5d831736bfb9ab8ae220caf0d050db183a5d5f43/.github/workflows/sync-adpick-biz.yml):1–132 | baseline→discover→build→coverage→commit 순서, main 이동 차단, 시간당 스케줄 |
| E08 | [sync-adpick.yml](https://github.com/chachazip-prog/kkokkapick/blob/5d831736bfb9ab8ae220caf0d050db183a5d5f43/.github/workflows/sync-adpick.yml):1–39 | 물리적 마지막 줄이 shell 주석이며 literal backslash-n 5개와 push 문자열 포함 |
| E09 | test/catalog-coverage-guard.test.js:1–58, test/provider-sync-workflow-contract.test.js:1–26 | 급감 fixture 검사 및 workflow 문자열 계약 검사 정의; 실행 통과로 표현하지 않음 |
| E10 | .github/workflows/code-quality.yml:1–142, flutter-quality.yml:1–53 | Node test/syntax 및 Flutter analyze/test/debug build 명령 정의 |
| E11 | [docs/design/d03-product-owner-direction.md](https://github.com/chachazip-prog/kkokkapick/blob/5d831736bfb9ab8ae220caf0d050db183a5d5f43/docs/design/d03-product-owner-direction.md):1–129, docs/v9-approved-home-design-contract.md:1–90 | 선택 방향·참고 비중·반응형 기준·승인 status가 문서에 있음; 원 사용자 선택 대화 미열람 |
| E12 | .agents/qa-reviewer.md:1–4, docs/physical-device-release-qa.md:1–144 | 독립 QA 역할 및 실기기 체크리스트; PREPARED_NOT_EXECUTED가 실제 PASS와 다름을 명시 |
| E13 | docs/release-readiness.md:1–102, docs/release-progress-scorecard.md:1–28 | 데모/저장소/운영 완료를 구별하는 설명이 있지만 시점·수량·진행률이 다른 문서에 분산 |
| E14 | [docs/production-verification-evidence.md](https://github.com/chachazip-prog/kkokkapick/blob/5d831736bfb9ab8ae220caf0d050db183a5d5f43/docs/production-verification-evidence.md):1–71, docs/remaining-release-blockers.md:1–22 | 빈 증거 양식과 외부 차단 목록; 운영 실행 증거로 볼 수 없음 |
| E15 | docs/provider-data-policy.md:1–52, provider-integration.md:1–37, catalog-coverage-size-evidence.md:1–23 | 접근/보존권한 분리·사이즈 출처 원칙·이미지 진단의 문서 기록; 공급자 허가를 독립 검증하지 않음 |
| E16 | src/image-health.js:1–72, scripts/catalog-quality-report.js:1–37 | 이미지 HTTP/MIME와 상품 집계는 별도 검사 축 |
| E17 | `1313ec4c…`의 BIZ workflow:1–77, discover-adpick.js:1–57 | 급감 당시에는 총량 baseline/ratio Gate가 없고 이미지 Gate만 존재 |
| E18 | guard 도입 커밋 `8f9efb1d…`, 파일 변경 이력 | 도입 시각은 급감 커밋 이후; 사후 보강이라는 순서 확인 |

Git 파일 목록에서 현재 tracked `design-preview/d03/index.html`과 여러 디자인 문서가 보였으나 10개 제안 전부를 검토하지 않았다. 외부 이미지·대화·PR artifact에 존재했을 가능성을 배제하지 않는다. 단순 파일 목록으로 사용자 승인 부재를 단정하지 않는다.

## 5. 판정 및 미검증 범위

| 구분 | 결과 |
| --- | --- |
| Git read 접근 | PASS — 실제 요청 종료 0 |
| reference clone 및 SHA 일치 | PASS |
| 열람 후 기존 checkout 변경 여부 | PASS — porcelain 출력 없음 |
| 저장 JSON 건수 비교·이력 파싱 | PASS — 실제 배열 수량 비교 완료 |
| 급감의 저장 결과 | CONFIRMED — 516→78 |
| 급감의 최종 원인 | UNKNOWN — 원본 응답·당시 runtime 로그 미열람 |
| 실제 사용자 노출·프로덕션 DB 손실 | UNVERIFIED |
| 기존 코드 test/build/sync 실행 | NOT RUN |
| 라이브 provider/image/API/DB 접근 | NOT RUN |
| 디자인 캡처/접근성 평가 | NOT RUN |
| PR/독립 QA 실행의 외부 증거 확인 | NOT RUN |
| 코드·상품 데이터 신규 이관 | NOT PERFORMED |
| 원본 저장소 수정·commit·push | NOT PERFORMED |

작성한 신규 산출물은 [LEGACY_RETROSPECTIVE.md](../../phase0/LEGACY_RETROSPECTIVE.md)와 이 문서뿐이다. 읽기 검토는 원본 구현의 QA 승인·재사용 허가·공급자 데이터 이용권한·vNext 출시 준비를 의미하지 않는다.
