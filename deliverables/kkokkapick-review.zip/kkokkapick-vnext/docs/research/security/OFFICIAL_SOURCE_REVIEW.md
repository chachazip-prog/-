# 보안·개인정보 공식 출처 확인 기록

- 기준일: 2026-10-11 (Asia/Seoul)
- 담당: 독립 Security & Privacy Engineer 에이전트
- 상태: **Blocked — 공개 공식 원문 미확인**
- 범위: 공개 공식 문서의 읽기 접근 점검. 앱 심사·법률 적합성·실제 구현 보안 검증은 수행하지 않았다.

## 접근 방법과 실제 결과

관리형 환경의 런타임 상태와 `/etc/codex/network-policy.json`을 먼저 확인했다. 관찰은 `running`, `observations_current=true`였고 HTTP 정책 상태는 `unknown`이었다. 시작 정책은 제한형이며 아래 공식 문서 호스트가 목록에 없었다. Python 표준 HTTPS 요청은 기존 프록시와 기본 TLS 인증서 검증을 유지했다.

아래 8개 요청은 모두 `Tunnel connection failed: 403 Forbidden`으로 실패했다. 이는 실제 원문을 수신하지 못했다는 증거다. 실패를 근거로 로그인 제공 여부, 최신 정책 문구, 심사 적합성 또는 공급처 계약 승인을 추정하지 않는다. TLS 검증 해제, 직접 연결, 도메인 우회는 수행하지 않았다.

실제 요청 시각·URL·오류는 [fetch_results.json](fetch_results.json)에 있다. 본 기록은 **네트워크 접근 점검**이며 **보안 테스트 통과**가 아니다.

| ID | 공식 URL | 확인해야 할 사항 | 현재 증빙 |
| --- | --- | --- | --- |
| SEC-SRC-01 | https://developer.apple.com/app-store/review/guidelines/ | 소셜 로그인 제공 시 로그인 옵션, 개인정보·광고·아동 대상 앱 심사 조건 | 프록시 403, 미확인 |
| SEC-SRC-02 | https://developer.apple.com/documentation/apptrackingtransparency | 선택할 광고·측정 SDK와 데이터 흐름이 ATT 적용 대상인지 | 프록시 403, 미확인 |
| SEC-SRC-03 | https://developer.apple.com/support/offering-account-deletion-in-your-app/ | 앱 내 계정 삭제 제공, 인증 제공자 토큰 폐기·연동 해제 조건 | 프록시 403, 미확인 |
| SEC-SRC-04 | https://support.google.com/googleplay/android-developer/answer/10787469 | Data safety 제출 내용과 SDK의 실제 수집·공유 일치 | 프록시 403, 미확인 |
| SEC-SRC-05 | https://support.google.com/googleplay/android-developer/answer/13327111 | 계정 삭제 기능·웹 경로 및 데이터 삭제 제출 요건 | 프록시 403, 미확인 |
| SEC-SRC-06 | https://developers.google.com/identity/openid-connect/openid-connect | OIDC 흐름, claim 검증, 제한된 scope | 프록시 403, 미확인 |
| SEC-SRC-07 | https://developers.kakao.com/docs/latest/ko/kakaologin/common | 앱 등록·심사·동의 항목·연동 해제, 선택 인증 브로커 지원 | 프록시 403, 미확인 |
| SEC-SRC-08 | https://developers.naver.com/docs/login/overview/overview.md | 앱 등록·심사·동의 항목·연동 해제, 선택 인증 브로커 지원 | 프록시 403, 미확인 |

## 필요한 다음 조치

환경 설정의 기존 목록을 유지하면서 `developer.apple.com`, `support.google.com`, `developers.google.com`, `developers.kakao.com`, `developers.naver.com`의 공개 HTTPS 접근을 추가하도록 Team Lead에게 전달했다. 이 문서 작성 시점에 설정 저장 또는 접근 회복을 확인하지 못했다. 설정 변경 후 영향받은 URL을 재검사하고, 최종 URL·확인 날짜·근거 문단·정책 해석을 보완한다. 정책 페이지가 동적 화면이면 브라우저 또는 공식 정적 원문으로 확인한다.

한국 개인정보·광고·사업자 의무, 국외 이전, 아동 관련 보호자 동의 적용 범위는 별도 최신 공식 원문과 법률·운영 검토가 필요하다. 여기에서 법률 준수를 승인하지 않는다. 공급처 이미지·상품·후기·가격 저장 및 제휴 링크 사용 권한은 실제 계약과 해당 공급처 공식 조건으로 별도 증명해야 한다.

## 후속 증빙 작성 규칙

1. 접근 성공과 해당 내용의 확인을 구분한다. HTTP 200만으로 정책 검증 완료를 표시하지 않는다.
2. 정책 ID에 원문 URL, 문단 또는 절 식별자, 확인일, 적용되는 앱 버전·SDK 버전·데이터 흐름을 연결한다.
3. 로그인 또는 계약자만 읽는 페이지는 권한 보유자의 확인 자료가 필요하다. 접근 제한을 우회하지 않는다.
4. 개인정보, 비밀값, 토큰, 공급처 원본 상품 데이터는 증빙 문서에 넣지 않는다.
5. 정책 변경 확인은 심사 제출 직전 다시 수행한다. 실구현·SDK 트래픽 검증은 독립 QA 결과를 별도로 연결한다.
