# 상품 데이터 전략과 안전한 동기화 제안

- 기준일: 2026-10-11, Asia/Seoul
- 수행: 독립 Source & Data Engineer
- 단계: Phase 1 정책 입력 / Phase 4 설계 선행 초안
- 상태: `Proposed` — 구현, 실제 상품 수집, 데이터 테스트, Gate C 승인 미완료
- 원래 요구사항: 마스터 5.2–5.7, 6.1–6.6, 7.1, 8.2–8.3, 9.1–9.3, 13
- 자료 범위: 사용자 마스터 및 [공급처 평가](PROVIDER_ASSESSMENT.md). 공식 공급처 문서는 네트워크 차단으로 미검증이다.

## 1. 목표와 결정 경계

원본·정규화·상품·옵션·판매처 가격을 분리하고, 데이터 급감 또는 가격·옵션 오류가 발견된 배치를 정상 카탈로그에 자동 반영하지 않는다. 공급처 추가는 adapter·설정·매핑·검증으로 확장하고 의류 전용 속성을 다른 상품군에 강제하지 않는다.

이는 승인 전의 데이터 전략 제안이다. PostgreSQL, 검색 구현, 작업 큐, 스토리지, Supabase 플랜과 실행 주기는 Architecture ADR·비용·보안·공급처 계약 검토로 결정한다. 이 문서를 아키텍처 승인이나 구현 완료로 표시하지 않는다. 원본·정규화·검색 보관도 실제 공급처 계약이 허용하는 범위에서만 가능하다.

## 2. 데이터 엔터티 — 원문 15개와 추가 제안 1개

마스터 6.4의 명시 목록은 **15개**다. 아래 첫 15개는 원문을 보존한다. `CatalogRelease`는 안전한 배치 활성화·롤백을 위해 추가한 **16번째 제안**이며 원문 요구사항으로 위장하지 않는다. 타입·물리 테이블·최종 필드는 Gate C에서 검토한다.

| 엔터티 | 주요 식별·필드 제안 | 정합성·권리 규칙 |
| --- | --- | --- |
| Provider | 내부 ID, 공급자 코드, contract/capability 버전, 상태, secret reference, 쿼터·보관 제한 | 공급자+코드는 고유. 계약과 기술 상태 분리. 비밀값 저장 금지 |
| Merchant | provider의 merchant key, 판매처 식별, 승인 URL 도메인, 상태 | provider 소스 키와 실제 merchant 분리. 같은 판매처의 다른 네트워크 경로를 출처별로 보존 |
| Brand | 내부 ID, 공식명, 별칭, 원본명, 확인 근거 | 브랜드 추론은 미확인으로 저장. 이름 유사성만으로 자동 병합하지 않음 |
| Category | 내부 ID, 부모, taxonomy 버전, 원천 카테고리 매핑 | 의류/완구/교구/도서/이동/수유/위생/수면 등 별도 속성·필터 schema |
| RawProduct | provider, source product/variant key, schema version, observed_at, payload hash, 허용된 원본 참조, sync job | immutable 제안. 계약 보관기한·필드 범위 준수. 권리가 없으면 원본 보관을 비활성화 |
| CanonicalProduct | 내부 ID, 브랜드+검증 모델/GTIN, 카테고리, 이름, 검수 상태, mapping version | 여러 판매처의 같은 모델을 통합. source title만으로 동일성을 확정하지 않음 |
| ProductVariant | canonical ID, 모델 옵션, size/color/material/capacity/pack count/edition 및 category schema | 다른 사이즈·색상·세트 수·규격·판본·구성을 동일 옵션으로 합치지 않음 |
| ProductOffer | provider+merchant+source listing+source variant, canonical/variant mapping, 통화·금액·조건·배송비, 관측일, 출처·매칭 상태 | 가격은 같은 비교 단위·옵션·구매 조건에서만 비교. 출처별 offer key 고유 |
| ProductImage | 출처 URL/asset ref, source ID, variant relation, display/cache/rehost 권한, attribution, expires_at, 검증 상태 | 허가 없는 다운로드·캐시·재호스팅 금지. 이미지 요청도 승인된 source 정책 준수 |
| ProductAttribute | product/variant, attribute key, typed value, unit, provenance, verified status | 소재·연령·인증·안전 정보에 source/verified_at 연결. AI 추론을 공식 정보로 승격하지 않음 |
| ProductPriceHistory | offer+variant, 실제 관측 가격·조건·통화, observed_at, batch/release ID | 과거 가격은 동일 옵션·가격 의미·통화로 비교. 누락·수집오류를 0원으로 저장하지 않음 |
| ProductAvailability | offer/variant, in_stock/out_of_stock/discontinued/unknown, observed_at, source evidence, expires_at | HTTP 실패·빈 응답·페이지 누락을 판매종료로 변환하지 않음 |
| SyncJob | provider, full/incremental, scope, cursor, 시작·종료·완료 증거, counts, metrics, state, 승인·배포 참조 | 다운로드 완료와 사용자 노출 완료는 서로 다름. job 전역 중복·겹침 실행 제어 |
| DataQualityIssue | rule ID, severity, provider/entity/batch scope, evidence, owner, resolution, independent QA verdict | 수정 담당과 독립 QA 승인 담당 분리. 해결 전 원본 증빙 보존 |
| AffiliateLink | offer/provider, approved destination, link method, 계약 범위·공시 버전, 유효기간·검증 상태 | 검색 결과 URL과 제휴 URL을 혼동하지 않음. 클릭 추적·전환 권한은 별도 허용 |
| **CatalogRelease — 추가 제안** | release ID, parent/LKG ID, source job IDs, mapping/taxonomy version, ready search version, metrics, QC/승인 refs, activation/rollback 상태 | 완결된 읽기 버전을 지정. QC 실패·권리 미승인 release 활성화 금지 |

클릭·주문·전환·광고·수수료·정산 이벤트는 수익 도메인의 별도 모델 요구사항이다. 위 16개가 서비스 전체 DB 엔터티라는 의미가 아니다. Backend·Security 담당과 API/ERD에서 연결·최소 보관·삭제·회계 구분을 검토한다.

## 3. 논리 파이프라인과 입력 계약

`Provider Adapter → 허용된 Raw Product → Normalization → Classification → Canonical Product / Product Variant → Offer Mapping → Quality Gate → Search Release → App/API`

1. **Adapter**: 계약상 승인된 엔드포인트·범위만 호출하고 provider source key, observed_at, schema, complete/incomplete, full/incremental, cursor 또는 watermark를 전달한다. 지원 여부를 문서로 확인하지 않은 삭제·차분 의미를 추정하지 않는다.
2. **원본**: 원본과 처리 버전을 분리한다. 전체 payload 보관이 불가하면 허용된 최소 출처·hash·진단 지표만 보관한다. log에 key·토큰·사용자 정보를 남기지 않는다.
3. **정규화**: Unicode, 공백, 통화·단위·URL·typed attribute를 정리하되 원래 의미와 source provenance를 보존한다. 회원가/쿠폰가/최소옵션가/배송비 포함 여부는 필드로 구분한다.
4. **분류**: category-specific schema로 필수 속성을 검사한다. 신뢰도가 부족하면 검수 큐로 보내고 잘못된 카테고리 필터·인증 표시를 노출하지 않는다.
5. **모델·옵션 매칭**: 검증된 ID와 옵션 identity로 매핑하고 모호한 쌍은 자동 합병하지 않는다. 모델·매칭 정책 변경도 데이터 변경으로 QC 대상이다.
6. **Staging Gate**: 권리, batch 완결성, 가격, 모델/옵션, 수량, 이미지·링크, 신선도를 검사하고 후보 release를 만든다.
7. **검색·읽기 준비**: 후보 release의 정규화 데이터와 검색 인덱스/검색 테이블을 완성한다. index 수와 DB 기준 수의 불일치를 검사한다.
8. **활성화**: 모든 준비와 승인 후 한 release ID를 현재 읽기 버전으로 전환한다. DB와 검색이 다른 세대를 섞어 읽는 구조는 허용하지 않는다.

CSV/XML/JSON은 `schema_version`, `export_scope`, `generated_at`, `record_count`, `complete`와 삭제 의미를 제공 계약에 명시하는 것을 제안한다. 공급처가 완료 마커를 주지 않으면 alternative 완결성 검증을 합의해야 하며 조용한 빈 파일을 정상 전체 스냅샷으로 처리하지 않는다. XML 외부 엔터티·압축 폭탄·oversized payload·비정상 URL은 보안 검토의 입력이다.

## 4. 동일 상품·옵션의 안전한 식별

### 매칭 단계

- 검증된 동일 GTIN 또는 제조사 모델 + 브랜드 + 옵션·구성의 일치가 우선이다. GTIN 검증, seller 제공 ID의 진위, 묶음 SKU 여부도 확인한다.
- 제조사 모델이 없으면 판매자 상품명·이미지·속성 유사성을 **후보 생성**에만 활용한다. 확정 매칭 근거가 없는 경우 별도 상품으로 유지하고 검수한다.
- 다른 출처의 자체 product ID가 같다는 이유만으로 merge하지 않는다. key는 provider namespace를 포함한다.
- variant key는 category schema와 단위가 명시된 값으로 결정한다. size "90"이 서로 다른 체계를 쓰거나 색상 코드가 다르면 동등성을 추가 확인한다.
- 1개/2개 묶음, 200ml/400ml, 단품/세트, 본품/리필, 신판/구판, 수입/국내 모델, 새상품/중고를 구분한다. 상품명에 "부터"가 있거나 옵션별 가격이 빠진 경우 정확한 선택 옵션 가격으로 표시하지 않는다.

### 병합·분리와 감사

merge·unmerge는 원본 source mapping을 잃지 않게 기록하고 매칭 정책 버전과 검수자를 남긴다. canonical merge 뒤 상품 수가 줄어드는 경우도 수량 Gate에 감지되어야 한다. offer 수는 유지되는데 canonical 수가 급감하면 정상이라고 자동 통과하지 않는다. 가격 이력과 알림·찜이 다른 옵션으로 이동하지 않는지를 독립 QA가 검증한다.

인증번호와 권장 연령은 확인 가능한 공식 출처를 유지한다. 확인되지 않은 값은 `unknown` 또는 `unverified`로 표시하고 "안전인증 완료" 필터에 포함하지 않는다.

## 5. 가격·재고 신선도와 최저가 표시

가격마다 `observed_at`, `valid_until`, provider 허용 cache 기간, 통화·옵션·조건을 관리한다. fetch 시각이 갱신됐어도 원천 가격 시각이나 내용이 갱신됐는지 구분한다. 상세 화면의 최저가는 같은 variant·구매조건에서 **현재 사용 가능한 확인된 offer**만 대상으로 계산한다.

구체 freshness TTL은 공급처 계약·호출 제한·카테고리 변동성과 비용을 확인한 뒤 확정한다. 검토용 기본안으로 고변동 가격 6시간, 일반 가격 24시간을 제안할 수 있으나 이는 공식 조건·승인된 SLA가 아니며 계약의 더 짧은 제한을 넘길 수 없다. 실제 공급처 조건을 확인하기 전 운영 스케줄에 적용하지 않는다.

- **fresh**: QC 통과, 유효 옵션·가격, 계약상 허용기간 내. 가격 비교·알림 후보가 될 수 있다.
- **stale**: 마지막 정상 가격과 확인일은 허용되는 표시 조건에서만 유지한다. 현재 최저가·가격 하락 알림에서는 제외하고 "가격 확인 필요"를 표시한다.
- **unknown/error**: 수집오류를 재고 없음·0원·판매종료로 해석하지 않는다. 데이터가 없으면 "정보 없음/확인 중"으로 전달한다.
- **discontinued**: 공급처의 명시된 판매종료 신호 또는 승인된 완결 전체 수집의 반복 누락 규칙을 거쳐 처리한다. 단 1회 timeout·partial 응답은 근거가 아니다.

가격 하락 알림은 같은 offer/variant/통화/구매조건의 두 정상 관측값, 유효기간, active release, 사용자의 동의·목표가격을 함께 확인한다. 배치 QC 통과 전 enqueue하지 않고 발송 직전에 최신 release와 freshness를 재검사한다. notification key와 rate limit으로 중복을 막고 rollback/revocation된 release의 대기 알림은 취소한다.

외부 구매 페이지에서 최종 가격·배송비·재고가 달라질 수 있다는 안내는 데이터 오류를 허용하는 면책 수단으로 쓰지 않는다. 판매처 이동은 허용된 link, destination, scheme만 사용하고 위장 도메인·open redirect·비공개 네트워크 URL을 금지하는 보안 설계를 검토한다.

## 6. 데이터 급감·품질 Gate

원문에서 과거 대량 급감 사례를 중대한 사고로 정의했다. [독립 회고](../phase0/LEGACY_RETROSPECTIVE.md)는 2026-10-03 KST의 Git 저장 결과에서 원천 564→79, canonical 516→78을 확인했다. 당시 이미지 정상률 기록은 79/79, 100%였으므로 이미지 검사만으로 수집 범위 보존을 판정할 수 없었다. 수량 Guard는 급감 이후 추가됐다. 이는 버전 관리된 결과의 증거이며 당시 API 응답·운영 로그·실제 사용자 노출과 최종 원인은 미확인이다.

Source/Data 담당은 참고 체크아웃의 현재 coverage guard를 읽기 전용으로 추가 확인했다. 선언된 `count/productCount`가 실제 배열 길이보다 우선되고 baseline 파일이 없으면 비율 검사를 생략하는 코드 경로가 있다. 신규 정책은 이를 그대로 복사하지 않고 실제 저장 결과-메타데이터 일치, baseline 존재·무결성, category cohort Gate를 요구한다. 기존 앱 코드·상품 데이터는 이관하지 않았다.

### 비교 기준

비교 baseline은 해당 provider·카테고리·sync scope의 **마지막 정상 활성 release(LKG)**다. source raw rows, 정상 offers, variants, canonical products, 노출 가능 수를 실제 저장 데이터에서 각각 계산하고 선언된 count와 일치하는지 검사한다. 메타데이터 count만으로 정상 수량을 인정하지 않는다. 증분 batch의 수신 건수를 전체 catalog 수와 직접 비교하지 않고 적용 후의 예상 전체 상태를 계산한다. 기존 정상 baseline의 누락·손상·scope 불일치는 fail closed로 차단한다. baseline이 없는 최초 수집은 명시적인 bootstrapping 검수 경로로 처리하며 "감소 없음"만으로 승인하지 않는다.

| Gate | 차단 조건·검사 제안 | 차단 시 처리 |
| --- | --- | --- |
| 권리 | 공급처·범위·이미지·링크 capability 미승인 또는 철회 | 배치/권리 범위 차단. 사용자 노출과 삭제/보관 정책을 보안·사업 담당에 전달 |
| 완결성 | pagination/cursor 누락, timeout, schema drift, 불완전 export, 실제 row와 선언 count 불일치, baseline 손상, 불명확한 full/delta, job 충돌 | deletion 계산 금지. staging 격리, LKG 유지, 원인 분류 |
| 수량 | source rows/offer/variant/canonical 급감, 대량 비활성화·삭제, 핵심 category 소실 | 자동 반영 차단. provider 및 category별 diff 보고 |
| 가격 | negative/0/잘못된 통화·단위, 비정상 변화, 조건 섞임, stale | 해당 offer 또는 batch 격리. 알림 발송 차단 |
| 매칭 | 모델·옵션 불일치, 대량 merge, mapping 오류, unmatched 급증 | 검수 큐. merge/unmerge 감사와 독립 검증 |
| 이미지·링크 | 권리 없음, 이미지 누락/손상, 비허용 도메인·expired affiliate link | 표시·구매 이동 정책별 차단. 무단 이미지 다운로드 금지 |
| 읽기 일관성 | DB/search 수·release version 불일치, 준비 미완료 | 활성 포인터 전환 차단 |

### 수량 임계값 — 운영 승인 전의 검토용 예시

- provider 전체 정상 offer 수가 baseline 대비 **20% 초과 감소**하면 배치 차단.
- category 정상 offer 수가 **30% 초과 감소**하거나 기존 비어 있지 않은 핵심 category가 0이면 차단.
- 전체 응답이 0, full sync가 incomplete, provider source schema를 파싱할 수 없는 경우에는 비율과 무관하게 차단.
- initial release와 작은 baseline은 비율만 신뢰하지 않고 모든 제거·비활성화를 수동 검수한다. canonical/variant 수와 source count에도 별도 경보·차단 기준을 승인받는다.
- 데이터가 20,000 → 13,900 offers로 줄면 30.5% 감소이므로 첫 예시 Gate에서 차단된다. 이는 수행한 테스트 결과가 아닌 승인 전 정책 예다.

위 숫자는 실제 운영 데이터를 측정해 결정한 값이 아니다. 독립 QA가 경계값·작은 카테고리·증분·정상 판매종료 사례를 검증하고 Team Lead가 조정안을 검수한다. 누락을 감추기 위해 baseline을 실패 batch로 갱신하거나 사후 임계값을 올려 통과시키지 않는다.

증분에서 누락된 SKU는 삭제 신호가 아니다. 삭제는 명시 tombstone 또는 계약으로 의미가 확인된 완결 전체 스냅샷에 근거한다. 일반 판매종료는 soft state 전환을 제안하고 물리 삭제는 보관·권리·개인정보 정책의 별도 작업으로 처리한다. 급감이 정당한 판매처 종료라면 해당 범위의 명시된 근거와 한정된 계획을 독립 검수하여 새로운 release를 만들며 실패 batch를 무조건 승인하지 않는다.

## 7. 안전한 배치 활성화·LKG·롤백

### 상태 흐름 제안

`Created → Fetching → FetchedComplete → Normalized → QualityChecked → Prepared → Authorized → Active`

실패는 `Quarantined/Failed`, 취소는 `Cancelled`, 대체는 `Superseded`, 회복은 `RolledBack`으로 구분한다. 실행 state와 품질 판정·승인 state를 분리한다. `FetchedComplete`를 `Active`로 보고하지 않는다.

### 활성화 순서

1. 후보는 현재 release와 별도 보관한다. 실패 batch가 활성 offer를 직접 덮어쓰거나 삭제하지 않는다.
2. 고정된 source job 집합·원본 hash·mapping/taxonomy version으로 후보 release를 만든다. retry는 같은 idempotency key와 scope를 사용한다. lease/fencing 또는 이에 상응하는 동시 실행 제어를 검토하여 만료된 worker·과거 batch가 최신 release를 덮어쓰지 못하게 한다.
3. QC 전수 지표와 필수 샘플, 감소 diff, stale/가격/옵션·이미지·링크 결과를 보관한다. 문제가 있으면 격리한다.
4. 후보 DB/검색 읽기를 준비하고 release 간 동일 count/핵심 query·상세 결과를 검증한다. technology-specific 원자 전환 방식은 ADR에서 확정한다.
5. 준비된 release ID만 하나의 활성 참조로 전환한다. 전환 시 예상 parent release와 현재 active가 일치하는지 확인하는 compare-and-swap 또는 동등한 보호를 검토한다. API는 그 ID에 연결된 DB/검색을 같이 읽어 세대 혼합을 방지한다. 독립된 검색 alias와 DB pointer를 순서만 믿고 각각 전환하지 않는다.
6. 전환 후 오류율·count·검색·링크·가격 지표를 관측한다. 알림·후속 이벤트는 active release의 commit 확인 뒤 내보낸다. 이전 parent/LKG와 승인·actor·reason을 기록한다.

### LKG와 공급처 장애

마지막 정상 release와 그 metadata를 계약 허용 기한 내 보존한다. provider outage 동안 다른 정상 공급처는 분리 운용할 수 있도록 scope를 유지한다. outage 공급처의 오래된 가격은 정상 데이터 보존과 구분하여 최저가·가격 알림에서 제외한다. 실제 값이 갱신된 것처럼 timestamp를 새로 쓰지 않는다.

데이터 사용권 철회·보안 침해·법정 삭제와 계약 기한 만료는 LKG 유지보다 우선한다. 철회된 이미지/offer/link는 보존된 release에서도 사용자 노출을 차단해야 한다. 롤백이 사용권을 되살리거나 삭제 요구를 무효화하지 않는다. 권리 revocation은 release 외부의 최신 deny gate로도 검토한다.

### 롤백

활성 전환 실패·잘못된 매칭·가격·수량 이상이면 마지막 허용 정상 release로 활성 참조를 되돌리고 API/검색이 같은 release를 읽는지 확인한다. 당시 offer가 stale 또는 권리 철회 상태라면 그 부분을 다시 노출하지 않는다. price-history는 오류 관측의 invalidation 기록을 남기고 다른 옵션 이력에 병합하지 않는다. 대기 알림·caches·후속 이벤트는 해당 release ID로 무효화/취소하고 이미 보낸 잘못된 알림은 별도의 운영 사고 처리 대상으로 기록한다.

카탈로그 롤백의 범위는 **카탈로그·검색·offer mapping의 읽기 세대와 참조 포인터**다. [DEC-009](../../DECISIONS.md)와 [상품 정책 POL-05](../product/POLICY_SPECIFICATION.md)에 따라 현재 사용자 상태와 권리 차단이 항상 우선한다. 최신 찜 삭제, 알림 OFF, 탈퇴·계정 삭제, 동의 철회, 공급처 데이터·이미지·링크 권리 철회/차단은 롤백 후에도 유지하며 과거 스냅샷으로 찜·알림·동의·세션을 되살리지 않는다. 현재 찜·알림의 상품 참조는 복구된 카탈로그에서 재검증하되 사용자 선택을 과거 값으로 복원하지 않는다. 발송 직전에도 최신 계정·동의·알림 설정과 권리 차단을 조회하여 롤백 전 대기 알림의 재발송을 막는다.

롤백은 주문·외부 전환 실적을 되돌리는 작업도 아니다. Backup restore는 별도 복구 시나리오로 DevOps가 비용·RPO/RTO와 함께 검토하고, 사용자 삭제·철회 및 권리 차단 상태를 먼저 재적용하여 해당 상태가 부활하지 않게 한다.

## 8. 운영 권한과 독립성

| 역할·시스템 | 허용 제안 | 금지·추가 증빙 |
| --- | --- | --- |
| 수집 worker | 승인 capability 범위 fetch·staging·QC 실행 | active 포인터 변경, 계약 승인, 원본 비밀 출력 금지 |
| Source/Data 운영자 | 오류 확인, retry 요청, 매핑 수정안, 한정된 activation 제안 | 자기 수정안의 독립 QA 승인 금지 |
| Independent QA | fixture/검수 후보로 QC·복구·매칭 검증, pass/fail 기록 | 자신이 검증하는 매칭·adapter 구현/수정·자체 승인 금지 |
| Catalog approver / Team Lead | 계약·QC·QA 증빙을 확인한 승인된 범위의 release activation | 공급처 법적 사용권 창설, 품질 실패 무효화, 출시 HOLD 해제 금지 |
| Security/사업 담당 | 범위·계약·secret reference·revoke/삭제 정책 검토 | API key 존재만으로 데이터·이미지·수익 권한 승인 금지 |
| DevOps | activation/rollback 실행과 감사·모니터링·복구 | QC 실패 배치 우회 공개 금지. 권리 revoke 상태 롤백 복구 금지 |

승인·실행·검증은 별도 audit actor/reason/evidence로 남긴다. 실제 사람/서비스 계정의 역할 매핑은 Admin RBAC 설계에서 검토한다. 스케줄 동기화의 사전 승인된 정상 범위는 자동화할 수 있지만 첫 release·스키마/매칭 변경·대량 비활성화는 별도 독립 검수를 제안한다. 일반 구현 선택을 매번 사용자 승인으로 막지 않으며 사업·비용·개인정보 확대·실출시 승인만 사용자 Gate로 연결한다.

## 9. 운영 지표·비용·알림

provider/category별 raw/eligible/canonical/variant/offer 수, 마지막 성공·관측·활성화 시각, fresh 비율, stale 비율, 이미지 정상률, unmatched·merge 분포, schema/401/403/429/timeout 오류율, API 호출량·쿼터 잔여, batch latency, 차단 release, rollback 건수, 검색 index/read consistency를 관측한다.

운영 알림은 "공급처 실패", "상품 수 감소", "권리 철회", "가격 알림 차단"을 별도 원인·scope·LKG 시각으로 전달한다. 실제 메시지 발송 채널이나 유료 모니터링 도구는 아직 연결하지 않았다. 원본 다운로드·이미지 proxy·검색 엔진을 무조건 늘리는 대신 증분/필요 필드/합법적 캐시/허용 배치로 비용을 산정한다. API 계약·운영 상품 수·호출량·보관기간이 없어 총비용을 확정하지 않는다.

## 10. 독립 QA에 전달할 필수 검증 사례

아래는 **테스트 설계안**이며 실행 결과가 아니다. 공식 데이터 대신 검수용 synthetic fixture를 사용할 때 실제 상품 또는 인증된 가격이라고 표시하지 않는다.

| ID | 검증할 상황 | 예상 차단·복구 결과 |
| --- | --- | --- |
| DQ-01 | complete full export로 정상 증가, 동일 옵션 가격 | QC 통과 후보, prepared·authorized 후 일관된 release 활성화 |
| DQ-02 | 20,000 → 13,900 정상 offer 감소 | 후보 격리, LKG 유지, 알림 없음, 감소 diff 증빙 |
| DQ-03 | 전체 0, 한 category 0, baseline 0 최초 수집 | empty/소실 차단 또는 bootstrapping 독립 검수; 자동 정상 승인 금지 |
| DQ-04 | page 누락/timeout 후 partial 200 응답 | full completion 불충족, 누락 SKU 비활성화 금지 |
| DQ-05 | incremental 일부 SKU만 변경, 누락 SKU 존재 | 전체 기준의 적용 후 수량 비교; delta 누락은 삭제 아님 |
| DQ-06 | 같은 상품명, 다른 모델/사이즈/pack 수/판본 | 잘못된 canonical/variant merge·가격 비교 차단 |
| DQ-07 | 쿠폰가·회원가·배송비·최소옵션가·다른 통화 | 같은 비교 기준만 최저가에 포함; 미확인은 별도 안내 |
| DQ-08 | stale 가격 하락·중복 이벤트·active 전환 전 발송 | enqueue/발송 차단, release/freshness 재검사, 중복 방지 |
| DQ-09 | candidate search 실패 또는 DB/search 세대 불일치 | active 유지. 기존 사용자 흐름의 version 혼합 없음 |
| DQ-10 | 활성화 뒤 가격·매칭 실패, rollback | 일관된 LKG 복구, stale/revoke 제외, 대기 알림 취소 |
| DQ-11 | 수집 worker의 active 변경, 운영자의 자기 QA 승인 | RBAC 거부·감사 기록. 실행/승인/QA 독립성 유지 |
| DQ-12 | 이미지/데이터 권리 철회 뒤 LKG rollback | 철회 항목 재노출 금지. 기한에 맞는 격리/삭제 |
| DQ-13 | 미확인 안전인증·AI 추정 연령·잘못된 브랜드 | 공식 확인 정보 표시·필터 불가, provenance 검수 큐 |
| DQ-14 | 계약 종료·대량 정상 판매종료 요청 | 명시 근거·scope 검수 후 새 release. 실패 batch 무조건 override 금지 |
| DQ-15 | count 메타데이터 정상이나 실제 배열 급감, 기존 baseline 누락·손상 | count 불일치·기준선 실패 차단. 처음 수집의 명시 bootstrap만 별도 검수 |
| DQ-16 | lease 만료 worker·과거 job이 뒤늦게 활성화 시도 | fencing/예상 parent 검사로 거부, 최신 release 유지, 감사 기록 |
| DQ-17 | 스냅샷 이후 찜 삭제·알림 OFF·탈퇴/계정 삭제·동의 철회·권리 차단 후 catalog rollback | 현재 사용자·권리 상태 유지, 삭제된 찜/알림/동의/세션 부활 없음, 대기 알림 재발송 차단 |

실제 테스트 시 testcase → fixture/source 권리 → 명령/환경 → 기대/실제 결과 → defect → 수정 담당 → 독립 재검증 → RTM Requirement ID를 연결한다. 테스트를 쓰거나 이 문서를 읽었다는 사실만으로 `Tested`/`QA Passed`라고 보고하지 않는다.

## 11. 보고·미완료·승인·다음 단계

- 실제 수행: 마스터 엔터티/데이터 요구사항 분석, 독립 회고 열람과 참고 coverage guard의 읽기 전용 확인, 원문 15개 보존, CatalogRelease 추가안, 품질·신선도·batch·권한·QA 설계 작성. 외부 상품 수집·코드 구현·설치·DB 생성·전환 추적 없음.
- 주요 산출물과 확인: 본 파일, [Provider Assessment](PROVIDER_ASSESSMENT.md), [실제 접근 실패 증빙](../research/provider/SOURCE_REGISTER.md). 저장소 문서 직접 열람 가능.
- 미완료: 공급처 문서·계약·샘플, ERD/API 상세, 검수 threshold·TTL, 실제 adapter, SQL/index/worker, 운영·복구·비용 검증.
- 위험: 미확인 공급처 사용권, option 오매칭, stale 가격·허위 알림, 동기화 급감, partial snapshot, 권리 철회·롤백 재노출. 대응은 위 Gate와 독립 QA이며 아직 실행 검증되지 않았다.
- QA 상태: 테스트 설계만 작성. 실제 단위/통합/E2E/rollback/부하 테스트 미실행, 독립 QA 승인 미완료.
- Team Lead 검수: 별도 검수 기록과 RTM 연결이 필요하다.
- 승인 필요: 이 설계와 가정은 Gate C에 제출할 입력이다. 실제 사업 방향·유료 계약·과금·추가 개인정보·운영 출시를 변경하기 전 사용자 승인을 받는다.
- 다음 단계: 공개 공식 자료를 확보하고 권리·쿼터를 검증 → ERD/API/ADR·비용과 정합성 검토 → synthetic fixture QC PoC 또는 승인된 샘플 → 독립 QA → 승인된 adapter 구현 순서로 진행한다. UI 디자인 승인 전 주요 화면 구현 금지는 별도로 유지한다.
