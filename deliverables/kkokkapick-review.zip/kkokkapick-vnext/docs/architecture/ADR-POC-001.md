# ADR-POC-001 — 격리 카탈로그 안전성 실험

기준일: 2026-10-12 (Asia/Seoul). 상태: **실험 범위 결정 / 운영 기술 결정 아님**. 작성: Team Lead. 앱/핵심 UI 구현·Gate C 확정·출시 승인은 아님. 출시 HOLD.

## 문제와 허용 범위

기존 Git 이력에서 확인된 통합 상품516→78 급감과 이미지 정상률100% 사례에 대해, 문서의 안전 정책이 실제 실패를 차단하는지 증거가 필요하다. 사용자 마스터 §4/11은 Gate B 이전 별도 기술 위험 PoC를 허용하며 2026-10-12 사용자는 계속 진행을 지시했다. 주요 화면 구현 대신 카탈로그 정합성과 트랜잭션 경계만 격리해 검증한다.

## 선택

Python3 표준 라이브러리와 임시 SQLite 파일로 합성 snapshot/수량/완결성/cohort·승격/동시성/복구·현재 권리/알림·삭제 상태를 실험한다. 서비스·실데이터·제휴 API·credential·외부 자원·유료 자원을 만들지 않는다. PostgreSQL/Supabase 또는 Flutter/Next.js 기술 확정은 이 선택의 결과가 아니다.

Source/Data는 별도 [실험 계약](../../experiments/catalog_integrity/CONTRACT.md)과 합성 fixture를 작성한다. Backend는 해당 계약 이후 구현하고 QA는 별도 테스트/검수를 작성한다. QA 실패 시 구현 담당에게 반환하고 QA는 feature 코드를 수정하지 않는다. 구체 인터페이스/자료형/실패 코드는 계약을 정본으로 삼는다.

## 검증과 한계

급감·기준선 누락/불완전수집·선언/실제 count 불일치·없는 cohort·명시 identity·동시 writer·DB transaction failure·재시작·stale/LKG·권리철회·현재 알림OFF/삭제/동의철회가 주요 대상이다. 총량0.8/cohort0.7/TTL3600은 **합성 시나리오 값**이며 실제 supplier 특성/품질/법적/알림 정책을 승인한 값이 아니다.

`python3 tools/run_catalog_poc.py`는 실실행 count/실패/오류/skip/원문 hash/로그를 보존한다. 0개/skip/expected failure로 통과하지 않는다. 합성 SQLite에서 통과해도 PostgreSQL concurrency·live feed·운영 scale·법적권리·클라이언트 UI/기기·제품 QA는 미검증이다. 원문 요구 전체 status를 Tested/QA Passed로 승격하지 않는다.

공식 조사 도메인 runtime 적용은 여전히 별도 prerequisite다. 현재 네트워크 차단을 우회하지 않고 로컬 위험 검증을 진행한다.
