# 모바일 개발 준비성 검토

- 기준일: 2026-10-11 (Asia/Seoul)
- 작성: 독립 Mobile Frontend Engineer 에이전트 `/root/mobile_engineer`
- 범위: Phase 0/1 초기 검토. **설계 제안 / 사용자 미승인 / 앱 구현·빌드·제품 테스트 Not Started / 공식 출시 HOLD**.
- 본 문서는 모바일 기술·상태 책임을 검토한 산출물이다. 작성자가 제품 QA를 승인하지 않으며, 독립 QA·디자인 검수·사용자 Gate B를 대신하지 않는다.

## 1. 입력과 현재 판단

사용자 [마스터 원문](../source/MASTER_PROMPT.md)의 모바일·개인정보·수익화·품질 요구, [PRD](../product/PRD.md), [정책](../product/POLICY_SPECIFICATION.md), [기능 명세](../product/FUNCTIONAL_SPECIFICATION.md), [디자인 방향](../design/DESIGN_DIRECTION.md), [ADR-001](ADR-001-STACK-CANDIDATES.md), [보안·개인정보 계획](../security/SECURITY_PRIVACY_PLAN.md), [데이터 인벤토리](../security/DATA_INVENTORY.md)를 읽었다. 실패 프로젝트의 앱·설정·플러그인을 신규 앱의 검증된 자산으로 간주하거나 복사하지 않는다.

**Flutter를 우선 기술 PoC 후보로 유지한다.** 공유 UI와 상태 모델이 iOS/Android의 디자인 일관성에 유리할 수 있으나, 실제 한글 렌더링·접근성·OAuth·알림·외부 이동 플러그인 검증 없이 확정할 수 없다. React Native 또는 Swift/Kotlin으로 바꾸는 기준은 필수 플랫폼/접근성 제약을 Flutter가 해결하지 못하는 재현 증거와 유지비 비교다. 익숙함이나 SDK 미설치만으로 전환하지 않는다. 상태 관리 라이브러리·라우터·HTTP·secure storage·광고 SDK도 아직 선택하지 않았다.

`com.kkokkapick.app`은 마스터 `REQ-L0034`의 **기본안**이다. 실제 Android application ID/iOS bundle ID 등록·소유권·환경별 suffix·서명·스토어 기록은 미확인이다. 개발·스테이징·운영 빌드를 구분하며 운영 식별자를 임의 등록하지 않는다.

## 2. 실행 환경 근거와 제약

아래는 DevOps가 실제 실행 결과를 저장한 [RUNTIME_EVIDENCE.json](../research/infra/RUNTIME_EVIDENCE.json), 관찰 시각 `2026-10-11T21:25:41+09:00`의 사실이다. 이 검토에서는 SDK를 설치하거나 같은 버전 검사를 반복하지 않았다.

| 항목 | 실제 관찰 | 모바일에 미치는 영향 |
| --- | --- | --- |
| OS | Linux 6.18.44, x86_64 | Android 개발 환경 준비 후보. iOS archive/서명 환경으로 사용할 수 없음 |
| Java | Java 명령 성공, OpenJDK 21.0.12.1 | Flutter/Android Gradle Plugin/Gradle 조합과의 공식 호환 확인 필요. Java 존재만으로 Android 빌드 가능 판정 금지 |
| Flutter·Dart | 명령 경로 없음 | stable SDK 버전·공식 artifact·무결성·Dart pin을 선택한 뒤 설치 필요 |
| Android | adb/emulator/Gradle 경로 없음, ANDROID_HOME/ANDROID_SDK_ROOT 미설정 | Android SDK 설치·라이선스·compile/target/min SDK·Gradle pin 미확정. 경로 검사만으로 모든 디스크의 SDK 부재까지 단정하지 않음 |
| iOS | xcodebuild/Swift 경로 없음 | 승인된 macOS/Xcode runner 또는 Mac, 시뮬레이터와 실기기, 서명·개발자/스토어 권한 별도 필요 |
| 자원 | CPU quota 4 core, 메모리 상한 32 GiB, workspace 여유 약 30 GiB | SDK·Gradle·Android image의 디스크 합산 필요. 초기 빌드 동시성 2부터 계측. KVM·USB·실기기 연결은 미확인 |
| 운영 secret 목록 | 구성 secret/runtime variable/outbound identity 각 0개 | OAuth·push·스토어 자격증명 준비를 의미하지 않음. 실제 필요 이름 확정과 기존 binding 검사 후 안전 설정으로 요청 |

본 에이전트도 환경 상태 도구를 읽었으며 `observations_current: true`, `running`, `connected`, 네트워크 정책 `restricted`/`state: unknown`을 확인했다. 이는 앱 실행 또는 정책 적용 완료 증거가 아니다. [공식 요청 결과](../research/infra/FETCH_RESULTS.json)의 Flutter iOS/Apple 페이지는 proxy CONNECT 403으로 원문 미수신이다. 최신 지원 OS·SDK 요구·정책·개발자 단가는 확인 전 미검증으로 둔다. 네트워크 draft 저장과 현재 runtime 접근 가능 여부는 별개이며, proxy/TLS 검증을 우회하지 않는다.

Android emulator 실행 가능성을 가정하지 않는다. KVM 가용성·권한과 명령 실제 실행을 확인하고, 불가능하면 승인된 기기/runner에서 검증한다. Linux의 Android 빌드 성공이나 Flutter web 데모는 iOS 빌드·실기기·스토어 준비의 대체 증빙이 아니다.

## 3. 앱과 서버의 책임 경계

| 영역 | 모바일 책임 제안 | 서버·다른 역할의 책임 및 의존성 |
| --- | --- | --- |
| 탐색·검색 | 비로그인 경로, 검색 취소·오래된 응답 폐기, 필터/정렬/페이지 상태, 정상·빈 결과·실패·재시도 구분 | Backend/Data: 공개 상품 계약·카테고리 속성·facet 가능 값·검색 품질·페이지 일관성 |
| 카테고리 필터 | 10개 유형을 수용하는 API 정의를 사용. 의류 사이즈/소재/두께와 완구 권장 연령/교육 목적/인증을 구분. 유형 전환 때 무효 필터 해제 사유 표시 | Planner/Data: 유형별 허용 속성과 정보 누락 의미 확정. 모든 유형을 의류 필터로 통일하지 않음 |
| 상세·비교 | canonical/variant/offer를 구분하고 현재 선택 옵션·배송 조건·판매처·관찰 시각 표시. 미확인 인증/추론/정보 없음 구별 | Data/Backend: 비교 가능 조건·공식 출처·권리·generation·freshness 계약. 앱이 다른 옵션을 임의로 최저가 병합하지 않음 |
| 신선도 | 서버 관찰 시각·유효 상태·만료 정보를 유지. 캐시 읽기/화면 재진입 시각을 갱신 시각으로 덮지 않음. resume·외부 이동·push 진입에서 재조회 | Data/Backend: 공급처/상품군 TTL, sold out/stale 정책, last-good revision도 현재 신선도 평가. 단말 시계만으로 최신 판정 금지 |
| 찜·가격 알림 | 로그인 필요한 시점 안내, 취소 복귀, 선택 offer 유지, 낙관 상태 실패 복구, 동의/OS 권한/발송 상태 각각 표현 | Backend: 소유자 인가·중복 방지·발송 직전 신선도·철회 검사. 앱 캐시로 가격 알림 발송 결정 금지 |
| 개인화 | 선택 연령 구간/사이즈 등 최소 입력, 일반 탐색 유지, 추천 이유·조건 수정·삭제 제공 | Planner/Security: 저장·동기화 정책 확정. 추천 이유가 안전성 인증이나 의료 조언으로 오인되지 않게 함 |
| 제휴 이동 | 판매처·제휴 관계 표시, 안전한 승인 URL의 외부 이동, 실패·돌아오기 처리, 중복 탭 억제 | Backend/Security/Data: offer 기반 승인 링크·허용 redirect chain·만료·opaque click ID·계약. 공급처 secret/서명키를 앱에 두지 않음 |
| 광고 | 식별 가능한 라벨, 광고 로딩/실패/미노출/닫기 상태. 판매처 이동을 시청·대기·가입·선택 동의와 교환하지 않음 | Growth/Planner/Security: 슬롯·빈도·SDK·동의·정책·계약. 광고 요청/노출/클릭을 구분하고 클릭을 구매로 표시하지 않음 |

서버 응답은 상품 정보의 확실성·신선도를 구별할 수 있어야 한다. API 필드 이름/enum은 Gate C에서 Backend와 합의할 제안이며 이 문서만으로 확정하지 않는다. 노출 불가 상품은 이전 캐시에 있다는 이유로 정상 판매 상태로 되살리지 않는다. 합성 fixture는 화면/로그/결과에 합성임을 표시하고 실제 가격·주문·이미지 권리로 소개하지 않는다.

제휴/광고 계측 전송 실패만으로 핵심 탐색을 차단하는 설계를 피한다. 안전한 목적지가 확보되지 않으면 임의 URL로 fallback하지 않는다. 승인 URL 캐시의 허용 기간과 계측 실패 시 이동 정책은 Backend/Security 계약으로 확정한다. 앱에서 클릭·브라우저 실행 요청·실제 외부 열림·확인된 주문을 같은 성공 이벤트로 묶지 않는다.

## 4. 화면 상태·복원 책임

Phase 2에서 주요 여정별 상태표를 디자이너에게 전달하고, Gate B 승인 후 구현한다. 각 화면의 최소 상태는 `초기/로딩/성공/빈 결과/부분 정보/오래됨/판매 종료/오류/재시도/권한 부족`이며 광고·계정 삭제·알림은 별도 상태를 갖는다. 부분 정보 상태를 정상 인증/재고/가격으로 대체하지 않는다.

| 상황 | 복원 또는 초기화 제안 | 검증할 실패 사례 |
| --- | --- | --- |
| 같은 현재 세션의 검색→상세→뒤로 | 메모리 내 검색어·유형·유효 필터·정렬·현재 목록/스크롤만 복원. 파일·OS 복원 상태에 검색어/필터 기록을 저장하지 않음 | 응답 순서 역전, 페이지 갱신, 필터 삭제 후 이전 응답, 키보드로 CTA 가림 |
| process 종료·새 세션 재실행 | 검색어·최근 검색·필터·개인화 조건은 폐기하고 복원하지 않음. 개인정보 없는 공개 category/product/option 식별자 route 복원만 별도 검토; schema 불일치·상품 미노출은 안전 화면 이동 | 검색/개인화값이 파일·OS backup·restoration에서 다시 나타남, 오래된 offer를 최신값으로 복원, 폐기 옵션 |
| 외부 판매처→앱 복귀 | 원래 옵션/판매처 문맥 유지, 실제 가격·판매 상태 재조회 | 복귀만으로 구매 완료/수익 표시, 링크 재실행·클릭 중복 |
| 로그인 시작→취소/실패 | 의도한 찜/알림의 대상과 이전 탐색 문맥 복귀 | 탐색 강제 로그인, 무한 로그인 loop, 사용자 의사 없이 pending action 실행 |
| 로그인 성공·계정 전환 | 현재 계정 소유 상태 재조회. 이전 계정 cache/pending write 폐기 | A 계정 찜·추천·알림이 B 계정에 보임, 게스트 정보를 자동 서버 병합 |
| offline→online | 공개 cache는 오래된 상태로 표시하고 조회 재시도. 개인 write는 허용된 작업만 계정·만료·중복 정책에 따라 처리 | offline에서 탈퇴 완료 표시, 가격 갱신 허위 표시, 오래된 요청이 철회/삭제를 되돌림 |
| 삭제·동의 철회 | session/personal cache/push 연결·pending 작업 정리; 삭제 진행/실패/재시도/완료를 분리 | 화면 상태만 삭제하고 서버 계속 발송, restart/backup으로 프로필 부활 |

개인정보와 토큰은 route query·restoration payload·공유 URL·crash breadcrumb에 넣지 않는다. 최근 검색·필터 기록은 회원/비회원 모두 별도 저장 선택 전 현재 메모리·세션에서만 처리하고 종료 시 폐기하며 자동 복원하지 않는다. 파일·OS backup·restoration payload로 보존하지 않으며 개별/전체 지우기를 제공한다. 기기 영속 저장과 계정 동기화는 별도 Proposed opt-in으로 기본 OFF이며, 개인화 저장 opt-in과 최근 검색 저장 opt-in은 서로를 대신하지 않는다. 앱 제거가 OS 백업·Keychain 잔존·서버 데이터를 자동 삭제한다는 가정을 하지 않는다.

**Lead가 정리한 작업 기본값:** 개인화 조건은 회원/비회원 모두 메모리·세션 내에서만 처리하고 세션 종료 시 지운다. 기기 영속 저장·계정 동기화는 각각 별도 명시적 opt-in 제안이며 기본 OFF다. 자동 저장 아동 프로필을 만들지 않는다. 기능 명세 FR-05의 기본값과 맞추고 PoC도 같은 범위로 제한한다. 영속화·기한·OS 백업 제외·재시작 복원은 정책/동의/삭제 UX 검수와 해당 승인 전 활성화하지 않는다. 일반 공개 route 복원과 선택 아동 조건 복원을 별개로 취급한다.

## 5. 인증·개인정보·스토어 준비

Apple/Google/Kakao/Naver/이메일은 후보이며 모두 제공한다고 약속하지 않는다. 선택 broker의 플랫폼별 실제 지원, 최소 scope, 공식 redirect·OAuth/해당 OIDC 검증, 취소·만료·code 재사용 방지·계정 연결/해제·탈퇴를 비교한다. 모바일에 provider client secret이나 특권 Backend 키를 번들링하지 않는다. 검토한 공식 SDK와 OS 안전 저장소를 사용하며 토큰 rotation·폐기·backup/migration 동작을 실기기에서 검증한다. 이메일 일치만으로 계정을 병합하지 않는다.

비회원 탐색에 가입·알림·추적 권한을 선행 요구하지 않는다. 알림 요청은 가격 알림 등 맥락에서 수행하며 OS 거부·서비스 동의·마케팅 동의·토큰 전달·발송 중단을 구분한다. token rotation, logout, 기기 제거, 철회, 탈퇴를 처리하고 push 열기에서 현재 상품·가격을 다시 조회한다. 잠금화면·분석·제휴 URL에 아동 정보나 이메일을 넣지 않는다.

탈퇴 설계는 앱 내 시작 경로, 적절한 재인증, 대상·보존 예외·처리 상태/기간 안내, 로컬 정리, 서버의 `deletion_pending` 및 sink별 결과에 맞춘 진행/실패/완료 표시를 포함한다. 단순 logout을 계정 삭제라고 표시하지 않는다. 최신 플랫폼 정책 확인 후 필요한 외부 웹 삭제 경로·정책 URL·로그인 조건을 확정한다. 외부 판매처의 주문/계정까지 삭제됐다고 알리지 않는다. 서버 삭제·backup 잔존의 실제 기간은 Security/운영 근거를 따르며 잠정 7일/30일을 검증된 보장으로 고지하지 않는다.

초기 PoC에는 광고/analytics/crash tracking SDK를 자동 넣지 않는다. 채택할 SDK마다 전송 필드·수집 시점·동의 거부 동작·국외 전달·삭제를 Security와 검토한다. ATT 해당 여부와 Android Data safety/광고 식별자, 로그인·계정 삭제·심사 target 요구는 **최신 공식 원문 미확인** 상태다. 플랫폼 권한 팝업이 국내 개인정보/마케팅 동의를 대체하지 않는다. SDK 설명만으로 미수집 판정하지 않고 실기기 네트워크·앱 설정·실제 데이터 흐름 증거가 필요하다.

## 6. 접근성·성능과 디자인 구현 수용 기준 제안

다음은 미래 시험의 **제안 목표**이며 실행 결과·확정된 OS 지원 계약이 아니다. 디자이너·QA·Team Lead가 Phase 2/3 및 Gate C에서 범위를 합의한다. 디자인 방향의 단색 대비 계산과 실제 렌더링·스크린리더 검증을 구분한다.

| 대상 | 측정 가능한 제안 기준 | 증빙/책임 |
| --- | --- | --- |
| 터치·레이아웃 | Android 48dp/iOS 44pt 조작 목표를 기본으로 검토. 작은 화면·keyboard·safe area에서 핵심 CTA 가림/겹침 0건 | Designer/Mobile 구현, QA 실기기 과업·좌표/스크린샷 |
| 글자·한국어 | OS 글자 확대 200% 검토에서 상품·옵션·가격·광고/제휴/오류 문구 잘림·의미 유실 0건. 긴 한글/영문 혼합·숫자·용량·사이즈 표본 포함 | 실제 font/license/version과 기기 설정 증빙 |
| 읽기·대비 | 일반 텍스트 4.5:1, 큰 텍스트·필수 UI 3:1을 내부 목표로 검토. 이미지·투명도·disabled/selected/error 상태 포함; 색만으로 의미 구별 0건 | 후보 색 계산 이후 실제 컴포넌트 검사 |
| 보조기술 | TalkBack/VoiceOver로 검색→유형 필터→옵션 상세→판매처 이동, 로그인 취소·찜/알림 거부·삭제 시작 과업 수행. 라벨/읽기 순서/상태 announce 누락·focus trap 0건 | Android/iOS 개별 실제 화면·영상·실패 재검수 |
| 모션 | OS reduced motion에서 비필수 반복/자동 이동 제거, 목록/광고 로딩으로 버튼 위치 급변 0건 | 실제 앱 설정·영상 |
| 이미지·스크롤 | 승인된 권리 또는 합성/placeholder 100상품 fixture로 반복 목록 왕복 10회. 이미지 요청·decode·cache·RSS·frame time 기록. 메모리의 반복 증가/ANR/crash 없음을 검토 | profile/release 기기별 수치. debug mode로 최종 성능 판정 금지 |
| 초기 성능 가설 | 대표 중급 실기기/고정 네트워크에서 cold start 첫 의미 있는 탐색 표시 p95 3초 이내, 60Hz 스크롤 frame p95 16.7ms 이내를 후보로 계측; 각 30회 이상·warm/cold 분리 | QA/Architecture가 기기·네트워크·sample·frame 정의와 현실성을 검토한 후 확정. 달성 주장 없음 |

폰트·token·component 선택은 디자인 승인 이후 구현한다. 실기기 화면과 승인 Figma/동등 산출물을 동일 viewport·내용·글자 설정에서 비교하고, 간격·타입·상태 차이를 독립 QA가 반환한다. 코드상 token 일치 또는 정적 스크린샷 하나가 디자인 정합성·접근성 통과를 의미하지 않는다.

## 7. 제한된 기술 PoC와 진행 순서

Gate B 전 가능한 범위는 **ADR 후보 검토 뒤 명시한 위험별 격리 PoC**다. 정식 앱 scaffold·홈/검색/상세 구현으로 확장하지 않는다. 현재는 그 계획만 작성했다.

1. **준비:** Flutter stable/Android toolchain·Java 호환과 라이선스·공식 artifact 무결성을 확인하고 pin을 기록한다. 지원 OS/기기·Mac 이용 가능성·필요 네트워크를 확인한다. 외부 프로젝트 생성·유료 runner·개발자 가입은 별도 사용자 승인 항목이다. 기존 체크아웃을 사용하며 별도 worktree는 사용자 요청 전 만들지 않는다.
2. **PoC-M1 빌드 위험:** 임시 격리 harness에서 의존성 복원·정적 분석·합성 계약 테스트·Android debug APK 빌드 가능성을 확인한다. 기능 앱으로 소개하지 않는다. 검증된 명령과 artifact checksum을 기록한다.
3. **PoC-M2 데이터/상태 위험:** 순수 Dart 합성 fixture로 카테고리 전환, 옵션 구분, stale timestamp 유지, 응답 순서 역전 취소, 계정 cache 격리, restoration schema 만료를 검증한다. 라이브 상품/회원 데이터는 쓰지 않는다.
4. **PoC-M3 플랫폼 위험:** 별도 작은 기술 harness로 한글·font 확대·semantics, 안전 외부 이동·복귀·OAuth 취소/리다이렉트·secure storage를 검증한다. 먼저 mock 계약을 검증하고 실제 로그인·push는 선택 제공자와 안전 credential/테스트 권한 확보 후 실시한다. 가상 성공을 실제 OAuth/push 성공으로 기록하지 않는다.
5. **iOS 별도:** 승인된 Mac/Xcode에서 같은 소스의 simulator 빌드·기술 harness를 실행하고 실제 기기·서명 단계의 미충족 사항을 기록한다. Linux 작업의 성공과 분리한다.
6. **판정:** 실패 재현·수정·재측정과 Mobile/UX/Backend/Security/독립 QA 의견을 ADR에 전달한다. Gate C 기술 확정 뒤 Gate B 승인된 화면을 구현하고 제품 QA를 진행한다.

설치 성공, `flutter doctor` 결과, 0개 테스트, debug APK만으로 모바일 제품이나 iOS RC를 완료로 표시하지 않는다. 모든 PoC도 입력·예상 결과·실제 명령/exit code·실행일·기기·버전·원본 로그·artifact·실패 목록이 있어야 `Tested`로 기록할 수 있다.

## 8. Android/iOS 빌드·기기 검증의 증빙 기준

| 단계 | 필요한 실제 결과 | 현재 상태 |
| --- | --- | --- |
| Android 기술 PoC | pin된 Flutter/Dart/JDK/SDK/AGP/Gradle, doctor 상세, analyze 결과, 명명된 테스트 수·결과, APK build 로그/checksum, 실행 가능한 emulator 또는 기기 launch | Not Started |
| iOS 기술 PoC | 실제 macOS/Xcode/Flutter 버전, simulator build/test 로그, 실행 기기·semantics 관찰. simulator는 서명/실기기 대체 아님 | Mac·접근권 미확인, Not Started |
| Gate D 제품 빌드 | 승인 디자인/계약 구현, debug/profile와 release 차이, 환경 설정 격리, 테스트/RTM, artifact 및 revision | Not Started |
| Gate E 기기 QA | 실제 지원 최소 OS와 제출 시 지원 최신 OS, Android 최소 1개 중급/작은 화면 실기기와 iPhone 최소 1개 작은 화면 실기기에서 필수 여정. 합의한 추가 기기·tablet/회전 여부도 기록 | 지원 범위·기기 확보 미정, Not Started |
| Gate F RC | Android 서명 AAB/APK와 내부 배포 설치 검증, iOS signed archive/IPA와 승인된 내부 배포 설치 검증, application/bundle ID·version/build·signing·policy/submission 준비, 롤백/운영 점검 | store/서명/법적·사업·출시 승인 미확인, Blocked |

기기 matrix는 OS 버전·모델·화면·메모리·글자 크기·네트워크·빌드 hash를 포함한다. 초기 제안 기기 수가 모든 시장 기기 호환을 보장하지 않으며 실제 타깃과 QA 위험에 따라 확대한다. offline/저속·timeout·이미지 실패·process kill·앱 업데이트·로그인 취소·계정 전환·알림 거부·광고 미노출·삭제 진행을 정상 흐름과 함께 검증한다. 출시 차단 P0/P1 0건과 독립 QA 승인·사용자 출시 승인은 별도 조건이다.

## 9. 요구사항 연결과 반환 항목

| 원문 RTM 항목 | 이 검토의 범위 | 후속 산출물·담당 |
| --- | --- | --- |
| REQ-L0034, REQ-L0157, REQ-L0827 | 앱 ID 기본안·Flutter 우선 검토안 | ADR 확정·PoC/build와 환경/플랫폼 위험 증빙 · Mobile/DevOps/Lead |
| REQ-L0458, REQ-L0479, REQ-L0521 | 미확인 인증/추론 정보의 공식 표기 금지·가격 신선도와 알림 | API/카테고리·freshness contract·실제 과업 · Data/Backend/Mobile/QA |
| REQ-L0498, REQ-L0510 | 충분한 비회원 탐색·SNS 로그인/계정 삭제의 정책/법령 충족 | Gate A 정책 및 Gate B 상태, 실제 OAuth/탈퇴 시험 · Planner/Security/Mobile/QA |
| REQ-L0678 | 강제 광고 시청·오인 닫기 등 다크패턴 금지 | 승인 광고/제휴 흐름·미노출 과업·SDK traffic · Growth/UX/Security/Mobile/QA |
| REQ-L0166, REQ-L0193, REQ-L0402, REQ-L1126 | 접근성/성능·다양한 기기/화면·디자인과 실제 앱 화면 비교·iOS RC | 독립 QA 기기 matrix·디자인 diff·signed RC · Mobile/Designer/DevOps/QA |

이 표의 13개 고유 ID는 4자리 원문 줄번호로 표기하고 [RTM.csv](../governance/RTM.csv)의 존재·source_line·original과 원문 해당 줄을 대조했다. REQ-L0678은 실제 강제 광고 시청·다크패턴 금지 문장과 일치한다. 이 표는 원문 일부와 모바일 검토의 연결이며 전체 RTM coverage/요구사항 승인 판정이 아니다. 세션 처리·미복원 세부안은 원문을 구체화한 정책/보안 문서의 작업 기본값이며 원문에 동일 문구가 있었다고 주장하지 않는다. Team Lead가 전역 RTM의 정책→화면→API→구현→시험 연결을 갱신한다.

**반환/미확정:** 개인화 영속화·동기화 opt-in 후보의 필요성과 보유/삭제/백업, 로그인 조합/broker, Android/iOS 최소 지원과 제출 target, Mac/기기·개발자/서명 권한, ID 환경 분리, 광고/알림 SDK와 데이터 흐름, 실제 가격·정책 공식 원문 접근, 성능 목표·QA 기기 범위. 세션 종료의 정확한 lifecycle 경계(process 종료·logout·명시 종료·오랜 background)는 UX/Privacy가 합의해야 하며 app resume만으로 개인화값을 디스크에 복원하지 않는다. Planner·Security·DevOps·Designer·QA의 해당 담당이 검토하고 Lead가 결정 로그에 반영해야 한다.

**실제 수행:** 기존 문서·관측 JSON·원문 요구와 현재 환경 상태를 읽고 본 문서를 작성했다. SDK 설치·scaffold·앱 화면·실제 상품/API/로그인/push/광고 연동·빌드·실기기·스크린샷·성능·보안·스토어 테스트는 실행하지 않았다. 초기 독립 문서 검수는 QA 담당의 별도 결과를 기다린다. Gate A/B/C/D/E/F, 스토어 준비, 출시 승인을 이 문서로 통과시키지 않는다.
