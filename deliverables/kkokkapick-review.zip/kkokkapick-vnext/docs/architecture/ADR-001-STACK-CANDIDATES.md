# ADR-001 — 모바일·어드민·API·데이터 운영 기술 후보

- 상태: **Proposed**. 기술 확정, 유료 가입, 환경 생성, 구현 승인으로 해석하지 않는다.
- 기준일: 2026-10-11, Asia/Seoul
- 작성: 독립 DevOps & FinOps Engineer
- 범위: Phase 0/1 착수 검토; Gate C 제출에 필요한 초기 선택 기준
- 정식 출시: **HOLD**. 사업자·제휴·개인정보·스토어 요건 및 사용자 출시 승인 전 해제하지 않는다.
- 원문 근거: [MASTER_PROMPT.md](../source/MASTER_PROMPT.md) §6, §9, §13, §14

## 문제와 결정 기준

모바일 탐색·검색·상세·구매처 이동과 비개발자 관리자 운영을 함께 지원해야 한다. 공급처의 수집 권한, 데이터 신선도, 대량 상품 급감 방지, RBAC·감사 로그, 계정 삭제는 구현 편의보다 우선한다. 무료 플랜의 이름만으로 운영 안정성이나 전체 비용이 0원이라고 판단하지 않는다. 초기에는 설명 가능한 추천과 단순한 배포 구조를 우선하되, 100만 상품 확장을 위해 데이터 계약과 비동기 작업 경계를 유지한다.

평가 항목은 디자인 충실도·접근성, iOS/Android 배포 가능성, 인증 및 최소 개인정보, 공급처 어댑터·작업 재실행, 검색 품질, 운영자 권한, 백업·복구, 초기/성장 비용, 개발·스테이징·운영 분리다.

## 후보 비교

| 계층 | 후보 | 유리한 점 | 확인할 한계 | 현재 제안 |
| --- | --- | --- | --- | --- |
| 모바일 | Flutter + Dart | 하나의 화면 체계와 테스트를 iOS/Android에 공유; 사용자 요구의 우선 검토안 | 실제 기기 접근성·한글·폰트·대형 이미지 성능, 광고/제휴/로그인 플러그인 검증; iOS는 macOS/Xcode/서명 별도 필요 | 우선 PoC 후보, 확정 아님 |
| 모바일 대안 | React Native 또는 Swift/Kotlin | 웹 개발 역량 공유 또는 플랫폼별 품질 통제 | Flutter보다 낫다는 근거가 없으며 네이티브 이중 구현·QA 비용 증가 가능 | Flutter PoC가 필수 제약을 충족하지 못할 때 재평가 |
| 관리자 | Next.js + TypeScript | 웹 UI·검색·폼·운영 시나리오 구성, 서버측 인증 경계 구성 가능 | SSR이 필요한 화면과 단순 SPA를 구분; 운영자 RBAC를 프론트 숨김만으로 구현하면 안 됨 | 우선 후보; React SPA도 비교 |
| API A | 경량 TypeScript API + 관리형 PostgreSQL | 관리자와 타입 역량 공유; 수집 worker와 API 분리; 도메인 규칙 명시 가능 | 호스팅·worker·인증·백업 비용, DB pool, 작업 예약 보장 확인 | 기본 비교안 |
| API B | Supabase 관리형 Auth/PostgreSQL/Storage + 얇은 서버 API | 운영 요소를 줄일 수 있음; RLS·Auth 활용 후보 | 실제 무료/유료 용량·휴면·백업·지역·egress·동시성·사용량 과금 미확인; OAuth 지원 범위 검증 | 비용/약관/보안 확인 후 선택 |
| API 대안 | 경량 Python API + PostgreSQL | 데이터 파이프라인 역량 활용, 명시적인 API·worker 경계 | 두 언어의 빌드/타입/운영 관리 추가 | 팀 역량·PoC 기준으로 비교 |
| 로컬 데이터 | Docker PostgreSQL + 합성 fixture | 외부 서비스 생성 없이 API·정규화·삭제 Gate·복구 검증 가능 | 로컬 인증 모형이 실제 관리형 RLS/Auth 동작의 증빙은 아님 | ADR 확정 후 기술 PoC 기본안 |
| 로컬 통합 대안 | Supabase CLI 로컬 스택 | 관리형 선택 시 Auth/RLS/Storage 통합 검증 가능 | 여러 컨테이너, 이미지 다운로드/디스크, proxy/CA, 버전 호환 확인 필요 | 관리형 후보가 우세할 때만 |
| 검색 | PostgreSQL 인덱스 + 정확한 속성 필터 | 별도 검색 과금·복제 운영 부담 줄임 | 한글 형태소·오타·자동완성·대규모 facet 질의 품질을 기본 FTS만으로 보장할 수 없음 | 한글 검색·목표 부하 PoC 후 선택 |
| 검색 확장 | 전용 검색 엔진/관리형 검색 | 검색 품질과 독립적인 확장 후보 | 별도 색인 저장·업데이트·동기화·비용 증가 | 검색 실패율/지연 기준을 못 맞출 때 ADR 추가 |
| 비동기 작업 | DB 작업 큐 + lease/idempotency/outbox | 초기 별도 메시지 브로커 운영 최소화 | 장시간 작업 재시작·중복 실행·재시도·공급처 호출 제한 검증 필요 | 기본 비교안 |
| 모니터링 | 구조화 로그 + 핵심 지표·알림 | 적은 비용으로 데이터 사고·API 장애·예산 이상 탐지 | 사용자/아이 정보·토큰 로깅 금지; 알림 채널 실제 전달 시험 필요 | 모든 후보 공통 필수 |

## 제안 구성과 독립 경계

모바일과 어드민은 공개 API 계약을 사용하고, 관리자 API는 역할별 서버 인가를 별도로 검사한다. 공급처 연동과 외부 비밀키는 신뢰된 API/worker에 한정한다. 모바일·브라우저 번들에 관리자 권한 키를 넣지 않는다. `service_role` 같은 특권 키는 공개 API 사용자의 요청을 무검증 대행하는 데 쓰지 않는다.

데이터 경로는 `Provider Adapter → Raw Product → Normalization → Classification → Canonical Product → Offer Mapping → Quality Gate → Search Index → App/API`다. 상품 전체 교체와 대량 비활성화는 새 generation 검증 후 명시적 승격으로 처리하고 직전 정상 generation으로 되돌릴 수 있게 한다. 크롤링·이미지 미러링·API 구현은 공식 권한과 보관 조건 확인 후 진행한다.

초기 관리형 선택 여부와 관계없이 Provider Adapter·상품 식별자·검색·추천·측정 이벤트 계약은 특정 공급자 SDK로 고정하지 않는다. API·수집 worker·관리자 배포는 분리 가능하게 설계한다. 대규모 메시지 브로커, Kubernetes, 고급 AI 추천을 초기 필수 구성으로 추가할 근거는 현재 없다.

## 실제 환경에서 확인된 사실

[RUNTIME_EVIDENCE.json](../research/infra/RUNTIME_EVIDENCE.json)에 실행 결과를 보관했다. Linux x86_64, Node v24.19.0/npm 11.9.0, Python 3.12.14, Git 2.52.0, Docker CLI·daemon 28.4.0, Java 21.0.12.1을 확인했다. CPU quota는 4 core, cgroup 메모리 상한은 32 GiB다. workspace 디스크 여유는 점검 당시 약 30 GiB다. `go` 경로는 존재하지만 `go version`이 실패했으므로 작동하는 Go SDK로 계산하지 않는다.

Flutter/Dart/Android SDK 도구/Gradle/psql/Supabase CLI/Xcode/Swift는 확인되지 않았다. 문서 중심 착수 단계의 실패가 아니라 이후 PoC 설치 전제다. 기존 Node 24가 후보 프레임워크와 모든 플러그인의 지원 버전이라는 판정은 아직 하지 않았다. 각 저장소의 버전 pin과 공식 지원 범위를 먼저 선택한다.

현재 Linux 환경으로 iOS archive·서명·스토어 심사 후보를 만들 수 없다. 별도 macOS/Xcode runner 또는 승인된 Mac, Apple 개발자 조직·인증서·provisioning profile·앱 식별자·스토어 권한이 필요하다. Simulator 테스트와 서명된 실기기 빌드를 구분한다. SDK 설치만으로 앱 배포가 가능해지는 것은 아니다. Apple 비용·가입 상태는 확인되지 않았으며 가입/결제하지 않았다.

## 비용·네트워크 확인 한계

공식 가격·Flutter iOS·Apple 가입 페이지 HTTPS 요청은 proxy CONNECT 403으로 막혔다. [FETCH_RESULTS.json](../research/infra/FETCH_RESULTS.json)은 요청 URL·일시·진단을 보존한다. 이는 공급자의 HTTP 403이나 계정 인증 실패를 의미하지 않는다. 현재 요금, 무료 허용량, 상업적 이용 조건, 리전, SLA, 백업 보장은 미확인이다.

환경 상태 도구는 `observations_current=true`, running, connected를 보고했지만 네트워크 정책 상태는 `unknown`이었다. 정책 snapshot은 restricted, VPN 미설정, TCP 목적지 없음으로 관측했다. 이 값만으로 정책 적용 또는 VPN 연결 건강 상태를 보장하지 않는다. 확인되지 않은 요금은 [COST_MODEL.md](../operations/COST_MODEL.md)의 미입력 값으로 남긴다.

## 결정 전 필수 검증과 Gate C 조건

1. Gate A 정책과 Gate B 핵심 UX 승인 경계가 정리되어야 한다. 별도 기술 PoC는 승인 전에도 가능하지만 주요 화면 본격 구현으로 확장하지 않는다.
2. Flutter 후보로 한글·접근성·상품 이미지·딥링크·OAuth 취소/복귀·알림·광고 미노출을 Android 및 iOS 실제 기기에서 검증한다. 테스트 실행 전 통과라고 기록하지 않는다.
3. 최소 2개 상품군과 여러 판매처 offer의 공급처 권한·속성·중복/옵션 구분·stale 처리·가격 신선도 규칙을 검증한다.
4. 로컬 합성 fixture로 10k/100k/500k/1m 상품 부하와 한글 검색·운영자 검색·generation 승격/복구를 단계적으로 확인한다. 실제 부하에 맞춰 compute/메모리/색인 비용을 재계산한다.
5. 관리형 후보의 권한, 지역, 개인정보 처리·삭제, DB connection, 백업 복구, task scheduling, 휴면/제한, 가격·세금·환율을 공식 자료와 계정 설정으로 확인한다.
6. 개발·스테이징·운영 자원/비밀키/RBAC/로그 분리와 월 예산 상한을 확정한다. 무료 프로젝트를 포함한 외부 자원 생성도 사용자 승인 후 수행한다.
7. Backend·Source/Data·Security·QA 독립 검토와 비용 시나리오를 수렴하고 Team Lead가 ADR를 Accepted로 변경한다. 승인/이견/증빙을 기록한다.

## 미결정 사항과 책임

| 결정 | 제안 기본값 | 확인/승인 주체 | 현재 상태 |
| --- | --- | --- | --- |
| 모바일 기술 | Flutter 우선 PoC | Mobile, UX, QA, Team Lead | Proposed |
| API 구현 언어/인증 공급자 | 경량 API + PostgreSQL와 관리형 비교 | Backend, Security, DevOps | Proposed |
| 데이터 호스팅·리전·backup | 권한/요금/복구 근거로 결정 | Security, Source/Data, DevOps, 사용자(비용) | 미확인 |
| 월 인프라 상한·CI Mac 비용 | 공식 단가 입력 후 제안 | FinOps, 사용자 | 미승인 |
| iOS Mac/개발자 계정 | 기존 승인된 자원 우선 | Mobile, 사용자 | 존재/권한 미확인 |
| 상품 권한/수집·보관 조건 | 공급처별 공식 계약 | Source/Data, 사용자 | 조사 중 |
| 주요 화면 구현 | Gate B 이후 | 사용자, Team Lead | 승인 전 |
| 운영 배포·공개 출시 | Gate F + 법적 준비 + 별도 사용자 승인 | QA, Security, Team Lead, 사용자 | HOLD |

이번 작업에서 코드 구현, 패키지 설치, 외부 프로젝트 생성, CI 실행, 앱 빌드, 배포, 결제는 수행하지 않았다.
