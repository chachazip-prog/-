# Backend 착수 준비 검토 — Phase 0/1

- 기준일: 2026-10-11 (Asia/Seoul)
- 작성: 독립 Backend Engineer
- 상태: **Proposed — 설계 검토 입력**, 사용자 미승인
- 검토 범위: 정책·데이터·보안·기술 후보의 정적 문서 대조. API, DB, worker, SDK, 실제 공급처 및 테스트를 구현하거나 실행하지 않았다.
- Gate: A 검수 진행 중, B 사용자 승인 없음, C 설계·기술 검증 미완료. 공식 출시 **HOLD**.

## 1. 판단과 근거

현재 자료는 Backend 설계를 구체화할 입력을 제공하지만 구현 준비 또는 Gate C 통과를 입증하지 않는다. 특히 공급처별 권리·완결성 계약, 카테고리 속성 스키마, 가격 비교 단위, 읽기 세대 전환, 인증·관리자 인가, 삭제·보존 및 전환 증빙이 미확정이다. 문서 검토 결과를 실제 API 동작이나 데이터 보호 장치의 통과로 계산하지 않는다.

직접 열람한 근거는 다음과 같다.

| 자료 | 검토에 사용한 내용 | 근거의 한계 |
| --- | --- | --- |
| [마스터 원문](../source/MASTER_PROMPT.md) §§1, 2, 5–9, 11, 13–15 | 상품군·비회원 탐색·정보 진실성·15개 데이터 모델·급감 보호·수익·관리자 요구 | 구현 상세나 기술 선택 승인 아님 |
| [PRD](../product/PRD.md), [정책서](../product/POLICY_SPECIFICATION.md), [기능 명세](../product/FUNCTIONAL_SPECIFICATION.md) | FR-01~16, POL-01~10, 제안 수용 기준과 예외 | Phase 1 초기 초안, 사용자 미승인 |
| [데이터 전략](../data/DATA_STRATEGY.md) | 식별·완결성·baseline·CatalogRelease·신선도·QC·복구 | 공급처 공식 계약·수집·DB·PoC 미검증 |
| [보안·개인정보 계획](../security/SECURITY_PRIVACY_PLAN.md) | 최소 수집·인증·RBAC·위협 모델·삭제·webhook | 법률·스토어·공급처 조건 및 구현 보안 미검증 |
| [기존 프로젝트 회고](../phase0/LEGACY_RETROSPECTIVE.md) | 수량 급감·count/baseline 보호 공백·실행 증빙 구분 | 별도 Reference Reviewer의 저장소 조사. Backend가 기존 앱·API를 실행한 결과 아님 |
| [ADR-001](ADR-001-STACK-CANDIDATES.md) | 경량 API/PostgreSQL·관리형 대안·검색·작업 큐 | Proposed. 언어·호스팅·인증·가격·성능 확정 아님 |

기존 회고는 기준 SHA `5d831736bfb9ab8ae220caf0d050db183a5d5f43`에서 읽은 증거를 설명한다. 원천 564→79, 통합 516→78 감소는 Git 저장 결과이며 사고 당시 공급처 응답, 운영 DB 삭제, 사용자 노출 또는 최종 원인을 확정하지 않는다. 그 코드·상품·인증값을 신규 프로젝트에 이관하지 않았다.

## 2. 정책 정합성 검토 이력과 남은 사항

초기 열람 시 발견한 불일치와 Team Lead 결정 뒤 최신 문서 재열람 결과를 구분한다. BE-C01/02는 **문서 수준 정합화 확인**, BE-C03/04는 구현 전 남은 계약 정리 항목이다. 문서 작성자는 타 역할의 정책·승인을 변경하지 않는다.

| ID | 초기 관찰·현재 문서 상태 | 결정 근거·후속 검증 |
| --- | --- | --- |
| BE-C01 | 초기 snapshot에서는 Security의 꼬까핏 로컬 저장 제안과 Product의 세션 우선 제안이 달랐다. 최신 PRD·POL-01/02·FR-02/05·Security SEC-01/§2를 재열람하여 꼬까핏과 최근 검색 모두 회원/비회원 메모리·현재 세션 기본, 종료 시 폐기·자동 기기 복원 없음으로 정합화됐음을 확인했다. 최근 검색은 세션 내 개별/전체 삭제를 유지한다 | [DEC-006](../../DECISIONS.md)의 Working Default 반영 확인. 기기 지속 저장·계정 동기화는 각각 명시적 opt-in Proposed·기본 OFF다. 꼬까핏과 최근 검색의 저장 선택은 별개이며 목적·동의 UX·보유/삭제기간 확정 전 자동 저장/업로드 금지. **문서 충돌 해소, 구현 동작 미검증** |
| BE-C02 | 초기 snapshot의 POL-05 rollback 문구는 사용자 상태도 과거로 되돌린다는 뜻으로 읽힐 수 있었다. 최신 POL-05·FR-08·Security SEC-06/§5/7을 재열람하여 rollback 범위를 상품/index/offer 매핑 읽기 버전·참조로 한정하고 현재 사용자 상태를 권위 있는 기준으로 명시했음을 확인했다 | [DEC-009](../../DECISIONS.md)의 Working Default 반영 확인. 카탈로그 참조 호환성만 재검증하며 최신 찜 삭제·알림 OFF·탈퇴/계정 삭제·동의 철회·권리 차단은 항상 우선한다. 백업 복원도 최신 삭제/철회 상태를 먼저 재적용한다. **문구 정합화 확인, rollback·복원·발송 동작 미검증** |
| BE-C03 | DATA_STRATEGY에는 20%/30% 감소와 6시간/24시간 TTL의 검토 예가 있고 POL-03/05의 숫자는 미확정이다 | 예시는 운영 설정·API 기본값이 아니다. 권리·비교 범위·표본·변동성 근거를 받아 versioned QC/freshness policy를 승인받기 전 실제 운영 적용 금지 |
| BE-C04 | 수집 서비스 계정·승격 승인자·실행자의 경계는 여러 문서의 역할 이름이 다르다 | 역할 이름보다 action/resource/scope 행렬을 기준으로 통합한다. worker는 staging까지만 쓰며 QC 실패 배치를 승격할 권한이 없다. 승인·실행·독립 QA actor를 구분한다 |

BE-C01/02의 확인은 최신 문서와 결정 기록을 직접 대조한 결과이며 사용자 승인·구현·테스트 통과를 뜻하지 않는다. 최근 검색과 꼬까핏의 기기 지속 저장/계정 동기화·기간·동의 UX는 각각 미승인 제안이며 현재 세션 기본값을 수집/보존 확대 승인으로 해석하지 않는다. BE-C03/04의 운영 임계값·TTL·실제 역할/action/scope 매핑은 여전히 미확정이다. BE-T15/21 등 실제 구현의 저장·복구·철회 시나리오는 모두 NOT RUN이다.

## 3. 카테고리 스키마와 정보 상태 계약

10개 상품군을 공통 Product에 연결하고 `category_id + taxonomy_version + attribute_schema_version`으로 유형별 속성·필터를 정의하는 것을 제안한다. 임의 JSON 필드를 그대로 검색 facet으로 공개하거나 의류 필터를 모든 유형에 적용하지 않는다. 스키마는 값의 타입, 단위, 허용값/범위, product/variant 적용 위치, 비교 의미, 출처와 확인 상태, 노출/필터/추천 허용 조건을 포함해야 한다.

| 유형 | 우선 검토할 속성과 식별 범위 | API의 오인 방지 |
| --- | --- | --- |
| 의류 | 사이즈 체계·공식 치수표·소재·계절·두께·스타일/핏 | 다른 체계의 `90`을 자동 동등화하지 않음; 월령으로 사이즈 보장 금지 |
| 신발·액세서리 | 치수·단위·핏, 액세서리 하위 유형·규격 | 신발과 액세서리의 적용 불가 필드를 구분 |
| 장난감·완구 | 제조사 권장 연령·구성·재질·놀이 유형·인증 근거 | 미확인 연령/인증이 일치 필터를 통과하지 않음 |
| 교구·교육 | 연령/단계 출처·교육 목적·언어·세트 구성 | 학습/발달 효과를 생성하지 않음; 단품/세트 구분 |
| 도서·그림책 | ISBN·판·언어·제본·권수·출판사 | 제목 동일만으로 다른 판본·세트 병합 금지 |
| 외출·이동 | 하위 유형·공식 적재/신체 조건·장착/호환·인증 | 월령 하나로 카시트·띠·유모차 안전 적합 추천 금지 |
| 수유·이유식 | 용량·재질·공식 사용/세척 조건·호환 모델 | 200ml/400ml·본품/리필·부품 구성 분리 |
| 목욕·위생·생활 | 용도·규격/수량·재질/성분 출처·주의 | 비교 단위 미확인 시 개당 최저가 계산 금지 |
| 침구·수면 | 규격·소재·세탁·계절·공식 주의 | 안전 수면·질식 방지 또는 영아 적합 보장 생성 금지 |
| 기타 | 검수된 하위 유형의 확장 스키마 | 분류 미정은 검수 큐; 의류 속성 자동 부여 금지 |

`missing`, `unverified`, `verified`, `conflicting`, `revoked` 같은 정보 상태는 값과 분리한다. `false`, `0`, 빈 문자열을 모두 정보 없음으로 치환하지 않는다. 제조사 권장 연령, 판매자 문구, 사용자의 추천 선호는 각각 다른 필드/근거다. 공식 인증은 번호의 존재만으로 확인 완료가 되지 않으며 제품·모델·범위·출처·확인일을 연결한다. 인증 근거가 철회되면 release를 되돌려도 확인 완료로 재노출하지 않는다.

유형별 필수 속성 누락의 결과도 정책으로 명시해야 한다. 상품 전체 격리인지, 일반 탐색 허용이나 특정 필터/안전 추천 제외인지를 구분한다. API는 확인 가능한 값을 그대로 전달하고 화면을 채우기 위해 연령·안전·소재를 추론하여 공식값으로 반환하지 않는다. 카테고리 변경·다중 분류·schema migration은 기존 필터와 비교 단위·찜·알림 참조에 미치는 영향까지 검수한다.

## 4. 상품·옵션·판매 조건 식별과 15개 모델

`CanonicalProduct`는 검증된 모델, `ProductVariant`는 선택 가능한 규격·구성, `ProductOffer`는 특정 판매처의 해당 옵션 판매 조건이다. 공급처의 source product ID는 provider namespace를 포함하고 다른 공급처의 같은 문자열 ID를 자동 병합하지 않는다. 검증한 GTIN/모델·브랜드·구성 근거를 우선하며 상품명·이미지 유사성은 매칭 후보 생성에만 사용한다.

variant identity에는 카테고리가 요구하는 size system, color code, capacity/unit, pack count, edition, component set 등의 정규화·원본 의미를 포함한다. 옵션이 미확인된 listing의 `최저 옵션가/부터`는 정확한 variant의 가격이 아니다. source ID 재사용·SKU 재발급·모델 변경은 새 관측/매핑 검수 대상이며 기존 가격 이력과 알림을 다른 모델에 자동 이전하지 않는다. 매칭 변경은 merge/unmerge 이력과 alias/참조 정책, 검수자와 mapping version을 남긴다.

원문 §6.4의 **15개 논리 엔터티**를 아래와 같이 보존한다. 물리 테이블·구체 DDL은 아직 제안하지 않았다.

| 원문 모델 | Backend 검토에서 필요한 관계·불변 조건 |
| --- | --- |
| Provider | code 고유, 계약/capability 버전·상태와 기술 연결 상태 분리; secret 값 대신 reference |
| Merchant | provider merchant key와 실제 판매처 identity 분리; 승인 목적지·출처 관계 보존 |
| Brand | 공식명·별칭·출처·확인 상태; 유사 문자열 자동 확정 병합 금지 |
| Category | 버전 있는 taxonomy와 속성 schema, source 분류 매핑·검수 |
| RawProduct | 허용된 원본/최소 증거, provider source key·hash·관측·job 관계; 계약상 삭제/만료 우선 |
| CanonicalProduct | 내부 안정 ID·모델 근거·검수 상태, provider mapping의 가역성 |
| ProductVariant | canonical 소속과 유형별 옵션 identity; 구성/단위 차이 보존 |
| ProductOffer | provider/merchant/listing/source variant 식별, variant mapping·비교조건·가격·상태·관측/만료 |
| ProductImage | source와 product/variant 관계, display/cache/rehost 권리를 분리; 만료/철회 |
| ProductAttribute | typed value·unit·적용 위치·provenance·verification/version |
| ProductPriceHistory | 동일 offer/variant/조건의 실제 관측; 오류 invalidation 이력. 누락을 0원으로 만들지 않음 |
| ProductAvailability | 품절·판매종료·미확인과 관측/근거·만료; 수집 실패를 종료로 변환 금지 |
| SyncJob | full/delta·scope·체크포인트·완결성·단계별 실제 수량·retry/fence·품질/승인 구분 |
| DataQualityIssue | 영향 scope·규칙/version·증거·담당·수정과 독립 재검수 관계 |
| AffiliateLink | offer/provider·승인 목적지/redirect chain·방식·권리·기한·고지 버전 |

**추가 제안 `CatalogRelease`**는 원문 15개 중 하나가 아니다. job 집합·원본/매핑/taxonomy/QC 버전·DB/read/search 참조·parent/LKG·승인 증거·상태를 묶는 읽기 manifest로 검토한다. 이를 16번째 원문 요구사항 또는 서비스 전체 DB 목록으로 표현하지 않는다. 계정·찜·알림·동의·감사·전환 원장은 별도 서비스 모델이 필요하며 이후 ERD에서 상세화한다. 개인화 영구 모델은 BE-C01 결정 전 자동 활성화하지 않는다.

가격 금액은 통화의 소수 자리 규칙을 검토한 정수 minor unit 또는 정확한 decimal로 다루고 부동소수점 합산을 피한다. 같은 variant·묶음·통화·구매 자격·배송/세금/지역 조건만 비교한다. 배송비가 없거나 조건을 모르면 실지불 최저가로 표현하지 않는다. API는 조건별 offer와 비교 가능 여부, 근거 시각을 제공하고 `확인된 판매처 중`이라는 범위를 유지한다. 쿠폰/회원/카드/지역 조건은 일반 가격과 분리한다.

## 5. Provider Adapter와 부분 피드

어댑터의 제안 계약은 `provider/capability_version`, source schema, full/incremental, export/query scope, source snapshot/watermark, page/cursor 증거, declared count의 의미, 실제 수신량, 원천 가격 관측일, completion state, tombstone 의미와 오류 분류다. 범위 전체를 반환하지 않는 검색 API를 전체 재고 feed로 사용하지 않는다. `HTTP 200`, 모든 이미지 정상, 배열 파싱 성공은 범위 완결성의 증거가 아니다.

API 접근·원본 저장·정규화·검색 색인·이미지 표시/캐시/재호스팅·후기·제휴 링크·전환 조회 권한은 각각 확인해야 한다. 키 존재나 가입 성공만으로 허용하지 않으며 미확인 capability의 운영 활성화는 기본 거부한다. 권한 철회/만료는 최신 deny policy로 모든 세대에 적용한다. 허용되지 않은 원본 전체 payload나 개인정보를 로그·감사에 보관하지 않는다.

- full은 계약된 범위·완료 마커 또는 합의된 완결성 증거가 있을 때만 전체 누락 비교를 허용한다. 불완전·알 수 없는 envelope·페이지 누락·파서 오류는 정상 0건으로 반환하지 않는다.
- incremental은 수신 변경을 현재 상태에 적용한 **후보 전체 상태**로 QC한다. delta에 없다는 이유로 기존 SKU를 삭제하지 않는다. 순서/중복/삭제 의미를 공식 계약에서 확인한다.
- tombstone은 source key·scope·원천 revision·명시 사유와 권한을 검증한다. 오래된 tombstone이 다시 활성화된 새 revision을 지우지 못하게 한다.
- pagination 중 원천 snapshot이 바뀌는 API는 stable snapshot/watermark 지원 또는 합의된 재수집 전략이 필요하다. cursor 존재만으로 완결성을 인정하지 않는다.
- 401/403, 429, timeout, schema drift, partial export는 별도 상태다. 허용한 retry/backoff·quota·checkpoint를 적용하되 매 retry로 실패 Gate 또는 관측 시각을 초기화하지 않는다.
- feed/이미지의 XML 외부 엔터티, oversized/압축 payload, 악성 HTML/URL, private 주소·redirect·DNS 변화는 보안 통제를 검토한다. 서명·TLS 검증을 끄지 않는다.

공식 공급처 계약·샘플·삭제 의미가 현재 미확인이다. 위 필드를 공급처가 제공한다고 가정하거나 임의 webhook/HMAC 규격을 공급처 기능처럼 구현하지 않는다.

## 6. 실제 count·baseline·cohort Gate

수량의 단위를 먼저 고정해야 한다. 전송 row, 중복 제거한 source key, 유효 offer, variant, canonical, 검색 문서, 노출 가능 상품은 서로 다른 수다. 각 단계의 실제 저장 결과를 해당 단계의 manifest와 대조하며 raw declared row count를 canonical 수에 직접 맞추지 않는다. 합법적으로 전체 원본 보관이 불가하면 허용된 필드/키 집합과 계수 증거를 사용하는 별도 계약이 필요하다.

비교 baseline은 동일 provider/export scope/taxonomy/mapping 의미를 갖는 **마지막 정상 활성 release**다. baseline 존재·무결성·버전·집계 의미가 불일치하면 감소율 검사를 생략하지 않고 차단한다. 최초 bootstrap은 명시된 초기 범위·권리·완결성·표본·QC·독립 검수 절차로 처리한다. baseline=0을 `감소 없음`으로 해석하거나 실패 candidate로 baseline을 낮추지 않는다.

| 검사 축 | 제안 계약 | 실패 결과 |
| --- | --- | --- |
| 선언값 대조 | 단계별 선언 count와 실제 rows/distinct keys/저장 성공·탈락/중복 결과를 같은 단위로 대조 | count 불일치·불명확한 단위는 후보 격리 |
| 전체 변화 | raw/offer/variant/canonical/eligible/search 수 각각 절대 감소·상대 감소·merge/탈락 사유 | 한 지표 정상만으로 나머지 급감 통과 금지 |
| 세부 cohort | provider × category × sync scope를 기본으로 baseline과 candidate의 **합집합** 키를 검사; merchant/brand 등은 승인 범위에 추가 | candidate에서 사라진 cohort도 검사; 총량 증가로 특정 유형 소실을 감추지 않음 |
| 작은 cohort/초기 범위 | 작은 분모·처음 등장·0건의 특별 검수 경로와 절대 건수 검사 | 비율 단독 자동 승인 금지 |
| 증분 적용 결과 | source revision과 중복 제거 규칙을 반영한 후보 전체 projection count | delta 수를 전체 수와 비교하거나 누락=삭제 금지 |
| 읽기 일관성 | 준비된 read/search의 동일 release, index 필터/집계 단위를 명시하고 차이를 설명 | DB/search 세대·지표 불일치 시 활성화 금지 |

QC metrics는 release·QC policy version·baseline ID·scope·계산시각·실제 집계 근거를 고정한다. API 조회 시 동적으로 달라지는 권리 철회/TTL로 노출 수가 줄어드는 경우와 수집·매칭 수량 급감은 별도 지표다. 법적 삭제나 권리 회수로 필요한 중지를 급감 방지가 되돌려서는 안 된다. 정상적인 판매처 종료도 공식 근거·한정 범위·제거 영향·독립 검수 후 새 release로 처리하며 검사 전체를 끄는 override로 통과시키지 않는다.

승인 임계값·허용 변동·오류율·표본 기준은 현재 없다. 이전 프로젝트 수치 또는 DATA_STRATEGY 검토 예를 운영값으로 채택하지 않는다. QC 실패 candidate는 격리하고 LKG 유지, 운영 알림과 원인별 diff를 남긴다.

## 7. 멱등성·lease/fencing·원자 전환·복구

배치 멱등 키는 provider·scope·원천 snapshot/revision·처리 policy version을 묶는 계약으로 정의한다. 같은 key에 다른 payload가 들어오면 정상 retry로 인정하지 않고 충돌을 기록한다. retry 횟수나 실행시각만 바꿔 동일 작업을 새 변경으로 만들지 않는다. 원본 관측일·source revision과 fetch/normalize/activate 시각을 구분한다.

lease는 만료된 worker가 이미 가진 write 권한을 자동으로 없애지 않는다. provider/scope 실행권을 얻을 때 단조 증가 fencing token을 발급하고 **영속 쓰기와 체크포인트·승격 경계에서도** 현재 token을 검사하는 설계를 검토한다. 오래된 worker가 lease 상실 뒤 돌아오면 write/complete 요청을 거부해야 한다. 서로 다른 provider의 정상 작업도 같은 전역 카탈로그 parent에 기반하면 승격 경합이 생기므로 provider lock만으로 충분하지 않다.

제안 승격 절차는 다음과 같다.

1. active parent를 고정하고 candidate의 데이터·source jobs·QC·권리/스키마/매핑 버전과 승인 범위를 준비한다. candidate는 운영 active 행을 직접 덮거나 지우지 않는다.
2. DB/read/search를 같은 release ID로 준비한다. 검색 준비 실패는 `Prepared`가 아니다. 규모에 따라 전체 물리 복사 대신 immutable partition/참조 구조도 검토하되 읽기 결과는 하나의 manifest로 결정되어야 한다.
3. 승격 트랜잭션에서 expected parent, active revision, fence, 준비 상태, 승인·권리 상태를 재검사한다. `active == expected_parent`일 때만 CAS로 전환하고 audit/outbox를 함께 commit하는 것을 제안한다.
4. parent가 바뀌었으면 승격을 거부한다. 새 parent로 합성/재계산하고 **전체 필요한 QC·diff·승인 범위**를 재검증한다. expected parent 값만 새 값으로 바꿔 기존 검사를 재사용하지 않는다.
5. 공개 API의 한 응답은 capture한 release ID로 DB와 검색을 같이 읽는다. 독립 검색 alias와 DB pointer를 순서대로 바꾸는 방식만으로 원자성을 주장하지 않는다. 외부 검색 장애 때 동일 release의 허용된 fallback 또는 명시 오류를 사용하고 서로 다른 세대를 조용히 섞지 않는다.
6. pagination/cursor는 release·query/filter 기준을 묶고 만료/retired 세대는 정책에 따라 명시 재조회로 처리한다. page 2에서 다른 세대를 섞어 누락/중복을 만들지 않는다. 최신 권리/삭제 deny gate는 pinned release에도 적용한다.
7. commit 후 outbox를 전달한다. worker delivery는 재시도 가능한 at-least-once를 전제로 소비 측 멱등성을 설계하고 DB commit 전 알림·외부 변경을 내보내지 않는다.

rollback도 `expected_current`를 가진 CAS와 별도 승인·감사를 사용한다. 문제 release 복구 작업이 더 최신 정상 release를 덮어쓰지 못하게 한다. 복구 후보의 권리·TTL·read/search readiness를 재검사하고 문제가 있으면 해당 범위를 unavailable로 두며 허위 정상 표시를 하지 않는다.

되돌리는 대상은 **카탈로그 읽기 세대**다. 사용자 계정·최신 찜/알림 설정·탈퇴/동의 철회·권리 철회·정산 사실을 과거 시점으로 되돌리지 않는다. 찜/알림은 현재 사용자가 선택한 stable product/variant identity에 대해 mapping 호환성을 재검사하고 다른 옵션으로 조용히 치환하지 않는다. 잘못된 가격 이력은 invalidation 증거를 보존한다. 문제 release의 queued 알림·cache·추천 후속 작업은 무효화하며 이미 발송된 잘못된 알림은 사고 대응으로 남긴다. 백업 복원은 별도 삭제 재적용·RPO/RTO 검증 대상이다.

## 8. stale LKG·가격 알림·사용자 삭제

LKG는 마지막 정상 **읽기 버전**이고 항상 fresh한 가격을 뜻하지 않는다. 제공자 장애 동안 계약상 허용한 상품/과거 가격만 마지막 관측일·stale 상태와 함께 표시한다. 로딩·retry·release 재활성화 시각으로 `observed_at`을 갱신하지 않는다. stale/unknown/종료/권리 회수/격리 offer는 현재 최저가·가격 인하 정렬·추천·알림 후보에서 제외한다. 링크 이동 허용 여부는 가격 freshness와 별도로 권리·보안·링크 유효성을 검사한다.

알림 기준이 개별 offer, 같은 variant의 유효 offer 최저가, 목표가격 중 무엇인지 아직 미확정이다. 어떤 기준이든 동일 옵션·통화·구매조건의 실제 정상 이전/현재 관측, active release, freshness, 판매 상태, watch/동의/계정 상태를 이벤트 생성과 송신 직전에 재검사한다. dedupe key는 watch ID와 가격 원인 revision/비교 기준을 묶고 여러 worker·rollback·재시도로 동일 원인을 다시 생성하지 않게 한다. 금액·쿨다운·발송 cap·야간 정책은 승인 policy version으로 관리한다.

OS 권한/토큰의 backend 기록만으로 현재 단말 권한을 확정하지 않는다. 실제 앱 권한 변화·token 폐기와 provider 응답을 연결하며 OS 거부·발송 실패·성공·결과 불명을 구분한다. 서비스 동의 철회·알림 해제·탈퇴는 서버에서 발송 자격을 즉시 제거한다. push 제공자가 idempotency/신뢰할 전달 확인을 제공하지 않는 경우 timeout 후 전달 여부가 불명일 수 있다. DB 중복 차단만으로 단말의 정확히 1회 전달을 보장했다고 표현하지 않으며 불명 상태의 retry와 duplicate 억제 정책을 실제 통합 시험으로 결정한다.

계정 소유 자원은 서버에서 요청별 소유권을 검사한다. 탈퇴 요청은 `deletion_pending`으로 세션·알림·동기화를 먼저 중단하고 각 sink의 삭제 결과를 추적한다. 복구와 늦은 이벤트 처리에도 삭제 명부/버전이 우선한다. 개인화 기본값은 세션이며 로그인·재설치·추천 요청이 승인 없는 영구 저장 또는 서버 동기화를 발생시키지 않아야 한다. 소셜 제공자 subject와 내부 사용자 identity를 분리하고 같은 이메일만으로 계정을 병합하지 않는다.

## 9. 제휴 클릭·전환·replay-safe 원장

제휴 클릭은 판매처 링크를 누른 관찰이다. 링크 생성/redirect 응답, 외부 페이지가 열렸는지, 주문, 결제, 확정 수수료, 지급은 각각 다른 사실이다. 이동 계측 장애가 유효한 구매처 이동을 불필요하게 차단하지 않도록 하되 미허용 목적지·권리 회수·만료 링크는 차단한다. 서버 opaque offer/link ID로 승인된 목적지를 조회하고 임의 URL, 위장 host, 미승인 scheme/redirect는 거부한다. 이메일·아이 정보·토큰을 추적 링크에 넣지 않는다.

`ClickEvent`, `ProviderEventInbox`, `ConversionFact`, `CommissionLedgerEntry`, `ReconciliationRun` 등은 **별도 수익 도메인 논리 모델 제안**이다. 원문 15개 데이터 모델을 대체하지 않으며 실제 주문·결제 서비스를 만드는 제안도 아니다. 저장 필드·보존 근거·귀속 기간·통화·provider 주문 참조의 최소화는 Growth/Security와 결정해야 한다.

검증 가능한 공식 전환/정산 피드가 없으면 `미제공/측정 불가`로 유지한다. 클릭에 추정 CVR·수수료를 곱한 모델은 실제 구매/수익 원장에 적재하지 않는다. 실제 전환을 얻더라도 제공자의 귀속 확인, 취소/반품·확정·지급·차감·기간·통화를 구분하며 주문금액과 수수료·입금액을 섞지 않는다.

제안 수신·원장 계약은 다음과 같다.

1. 공식 제공자의 서명 방식·raw body·키 버전·timestamp/nonce 지원 여부를 검증한다. 다른 provider key, 위조·변조·공식 허용 창 밖의 replay는 차단한다. 서명 지원이 없으면 IP 또는 자체 HMAC으로 진위를 꾸미지 않고 공식 인증 조회/대사·격리 경로를 검토한다.
2. provider namespace의 event ID와 공식 revision/sequence 의미를 따른다. 같은 ID가 상태 갱신에 재사용되는지 계약으로 확인한다. 같은 key+revision에 다른 payload가 오면 충돌 격리한다. ID가 없으면 합의된 안정 식별·중복 판정 계약이 필요하며 임의 hash만으로 주문 동일성을 보장하지 않는다.
3. inbox accepted, 검증된 fact와 원장 기입, 처리상태·후속 outbox는 transaction/고유성 제약으로 연결한다. 처리 도중 crash 뒤 재전송을 받아도 같은 사실·금전 효과를 두 번 적용하지 않는다. 감사는 원본 개인정보/전체 payload가 아니라 허용된 최소 증거·hash·상태를 남긴다.
4. 늦게 도착한 estimated 이벤트가 최신 confirmed/returned 상태를 덮지 못하게 한다. 도착시각만으로 상태를 정하지 않으며 공식 source revision/정산자료와 대사한다. 알 수 없는 순서·모순은 격리한다.
5. 취소·반품·차감은 원래 사실을 지우거나 이미 지급된 사실을 몰래 변경하지 않고 참조한 조정/반대 원장으로 기록한다. 같은 adjustment의 재전송은 한 번만 반영한다. 예측 원장·확정 수수료·지급 사실은 분리한다.
6. 운영 대시보드는 실측 클릭, 확인된 귀속 주문, 예상/확정/지급/차감, 미제공 상태와 대사일을 각각 표시한다. 주문 CVR의 분모·귀속 기간·취소 처리·중복 클릭 정의는 Growth 정책이 필요하다. catalog rollback은 이 원장을 되돌리지 않는다.

실제 전환 provider 기능·서명·event ID·정산 권한과 원장 구현은 모두 미검증이다. replay-safe는 향후 검증할 계약이며 현재 보장한 동작이 아니다.

## 10. 관리자 deny-by-default RBAC

인가 행렬은 actor role × action × resource × scope × current account/권한 상태로 정의하는 것을 제안한다. 공개 사용자 JWT claim이나 UI 버튼 숨김으로 관리자 권한을 만들지 않는다. 모든 읽기/쓰기/export와 service job에서 검사하며 권한 회수·계정 정지·재인증 만료가 기존 세션에 적용되도록 한다. deny 결과와 허용한 고위험 작업은 민감값 없는 감사로 남긴다.

| 역할 후보 | 허용할 제한 범위 | 기본 거부 또는 추가 조건 |
| --- | --- | --- |
| 일반 사용자/비회원 | 권리·품질을 통과한 공개 카탈로그; 회원은 본인 찜·설정 | Admin, 타 계정 정보, 숨김 원본·secret·공급처 raw 오류 |
| 운영 조회자 | scope가 제한된 상품·작업/집계·마스킹 결과 | 변경, 개인정보 상세, export, 활성 포인터 변경 |
| 상품 운영자 | 수정/매칭 제안·격리 요청·증거 검토 | 원본 증거 조작, 자기 고위험 변경 승인, 임의 인증/가격 생성 |
| 데이터 승인자 | 권리·QC·독립 QA·diff의 한정 승격/복구 검토 | QC 우회, 계약 권리 창설, 자기 제안 자체 승인 |
| 지원/Privacy 담당 | 문의·삭제에 필요한 최소 정보와 사유/ticket | 일반 찜·아동 선호 일괄 열람, 무제한 export, 원문 토큰 |
| 수익 운영자 | 최소 전환/정산 집계·대사·계약 링크 상태 | 개인정보 결합 export, 수익 사실 임의 수정, 광고비 무승인 집행 |
| 보안 관리자 | 개별 운영자 초대·권한 회수·MFA·감사 확인 | 자기 권한 승격 자체 승인, 감사 삭제/변조 |
| 수집 worker | 승인 provider/scope의 fetch·staging·체크포인트·QC | active 변경, 사용자 데이터, 역할 관리, 계약 승인 |
| 승격/복구 실행 서비스 | 승인 증거가 있는 준비 release의 CAS와 audit/outbox | 임의 candidate/권리 회수 세대 활성화, 무승인 대량 변경 |

초기 인원·역할 조합은 미확정이다. 2인 승인 기본안이 충족되지 않으면 고위험 대량 변경을 보류하고 별도 실효적 대안을 검토한다. 동일 담당자의 긴급 중지 권한은 최소 scope로 줄 수 있지만 무증빙 자동 재개 권한으로 확대하지 않는다. break-glass는 별도 승인·사유·기간·알림·사후 검토 대상이다. 일반적인 한정 retry/제안은 모든 건마다 사용자 승인을 요구하지 않되 비용·개인정보 확대·사업 변경·공개 출시의 사용자 경계는 유지한다.

특권 DB 키는 신뢰된 서비스에 한정하고 공개 API 사용자 요청을 무검증 대행하지 않는다. API의 소유권/RBAC와 실제 DB 권한/RLS가 서로 맞는지는 선택 기술의 통합 시험 대상이다. local mock 통과는 관리형 RLS/Auth가 안전하다는 증거가 아니다.

## 11. 제한 기술 PoC 제안과 향후 계약/API 검증 행렬

Gate B 승인 전에도 허용된 기술 위험 PoC는 주요 화면 본격 구현이나 실제 외부 수집으로 확대하지 않는다. 이 문서에서는 PoC도 **실행하지 않았다**. ADR 후보·버전·자원·읽기 계약을 먼저 한정하고 로컬 합성 fixture, fake clock, controlled concurrency로 다음 assertion부터 검증하는 것을 제안한다.

- **POC-B01 모델/계약:** 최소 의류·완구와 판본/묶음의 구별 fixture로 잘못된 옵션 병합·조건 섞인 최저가 계산을 거부한다. 전 10개 유형 운영 완료의 증거로 쓰지 않는다.
- **POC-B02 count/부분 수집:** 정상 bootstrap, metadata 위조, baseline 누락/손상, 부분 full, 정상 delta, 총량 정상/한 category 소실에서 예상 차단과 active 불변을 확인한다.
- **POC-B03 동시성/복구:** lease 만료·stale writer·역순 완료·parent 경합·검색 준비 실패·문제 release rollback에서 fence/CAS/동일 읽기 세대와 최신 deny 상태를 확인한다.
- **POC-B04 수익/알림:** 합성 서명 계약과 inbox/ledger·outbox의 crash/retry에서 중복 금전 효과를 막고 stale/철회 알림을 억제한다. 합성 서명은 실제 provider 지원 증거가 아니다.
- **POC-B05 검색:** 한글·유형별 facet·정렬·pagination·동일 세대 읽기의 작은 대표 corpus를 사용한다. 기본 PostgreSQL FTS 지원만으로 형태소/오타 검색 품질을 통과 처리하지 않는다.

10k/100k/500k/1m 확장 시험은 상품·offer·이미지·이력의 실제 관계 배수, 쿼리·refresh 부하와 자원을 정의한 후 단계적으로 수행한다. 지금 백만 건을 생성하거나 성능/운영비 목표를 임의 통과시키지 않는다. 최소 PoC가 통과해도 실제 인증·외부 검색·공급처·푸시·운영 장애 시험을 별도로 해야 한다.

아래 표는 **future test matrix — 전 항목 NOT RUN**이다. route·OpenAPI·DB schema 확정 후 test ID → 원문 Requirement ID → fixture/version → command/environment → 기대/실제 → defect → 담당 수정 → 독립 재검증을 연결한다. 서버 내부 문자열 존재만 확인하는 테스트는 공개 API·저장 결과 불변 조건을 대신하지 않는다.

| ID | 계약/API 시나리오 | 기대할 관찰 결과 | 담당 입력/연결 |
| --- | --- | --- | --- |
| BE-T01 | 비회원 홈→검색/필터→상세→유효 구매처 이동 | 로그인 강제 없음; 권리 확인한 공개 데이터만 반환 | FR-01~04, POL-01 |
| BE-T02 | 의류 필터를 완구에 전달, 타입/단위 불일치·missing | 적용 불가 필터 오류/정책 처리; unknown이 검증 일치로 통과하지 않음 | FR-02, 유형별 schema |
| BE-T03 | 동일 이름의 다른 옵션·번들·판본, source ID 충돌 | 모델/variant/offer 분리, 가격 이력과 알림 오이전 없음 | FR-03/08, Data |
| BE-T04 | 쿠폰/회원/배송 미확인·다른 통화·최소옵션가 | 비교 불가 사유 전달, 허위 실지불/시장 최저가 없음 | POL-03, 가격 정책 |
| BE-T05 | 인증번호만 존재·AI 추론·원본 충돌/철회 | 공식 확인 필터/추천 제외, provenance/state 전달 | SEC-T03, POL-03/04 |
| BE-T06 | full 200 partial·cursor 누락·schema drift·0건 | completion 실패, active 불변, 누락 SKU 비활성화 없음 | DQ-03/04, SEC-T04 |
| BE-T07 | 선언 count 정상/실제 저장 급감, baseline 손상/범위 불일치 | fail closed; 명시 bootstrap 이외 검사 생략 없음 | DQ-15, count 계약 |
| BE-T08 | 총량 증가/한 provider-category 0, canonical만 대량 merge | 사라진 cohort/모델 급감 검출, 후보 격리 | DQ-02/06, QC 정책 |
| BE-T09 | delta 변경·중복·역순·오래된 tombstone | 적용 후 전체 수량 QC; 누락≠삭제, 최신 revision 보호 | DQ-05, adapter 계약 |
| BE-T10 | 같은 idempotency key retry·다른 payload 충돌·worker crash | 재처리 일관·충돌 격리, 같은 사실의 중복 효과 없음 | SyncJob 계약 |
| BE-T11 | lease 만료 writer·두 provider parent 경합 | stale 쓰기/승격 거부, 새 parent에서 재QC 필요 | DQ-16, SEC-T05 |
| BE-T12 | 검색 준비 실패·DB/search 혼합·pagination 세대 변경 | active 유지/명시 오류, 단일 응답/cursor의 세대 일관 | DQ-09, read 계약 |
| BE-T13 | 잘못된 release 복구·동시에 새 정상 승격·권리 회수 | CAS로 최신 상태 보호, 철회/stale 재노출 없음 | DQ-10/12, rollback |
| BE-T14 | TTL 만료·active 전 enqueue·동의/알림 해제 직전·rollback | 부적격 이벤트/송신 차단, 원인별 dedupe; 실제 provider 불명 상태 구분 | DQ-08, SEC-T12 |
| BE-T15 | 추천 세션 종료·로그인·재실행, 추가 profile 필드 | 승인 없는 영구 저장/업로드 없음; 기본 일반 탐색 가능 | BE-C01, FR-05 |
| BE-T16 | 다른 사용자 object ID·만료/정지/삭제중 세션 | 소유권·현재 계정 상태 검사, 읽기/변경/송신 차단 | SEC-T01/09/10 |
| BE-T17 | 직접 Admin API/export·claim 변조·권한 회수·자기 승인 | 서버 기본 거부, scope/MFA/재인증/승인 검사와 최소 감사 | SEC-T02, FR-09~15 |
| BE-T18 | 임의 URL/encoded host/private redirect·권리 회수 link | opaque 대상 검증·보안 차단, 클릭을 구매 완료로 집계하지 않음 | SEC-T06/07, FR-04/16 |
| BE-T19 | 위조/동일/변조/지연/역순 전환·처리 중 crash | 공식 서명/revision 검증·중복 금전 효과 없음·충돌 격리 | SEC-T08, 원장 계약 |
| BE-T20 | 반품/취소/차감 재전송·전환 미제공·catalog rollback | 조정 한 번 반영, 미제공≠0확정, 정산 사실 rollback 없음 | POL-07, Growth |
| BE-T21 | 탈퇴 뒤 늦은 sync/webhook·backup restore·queued push | 삭제/철회 우선, 개인정보·알림·세션 부활 없음 | SEC-T10, 삭제 계약 |

HTTP 오류코드·pagination 제한·API version·rate limit·동의/삭제 기간·알림 cap·성능 SLA는 미확정이다. BE-T의 예상 결과를 이미 반환하는 API 또는 실제 실행한 시험으로 표현하지 않는다. Backend/Data 구현 담당과 Independent QA 담당은 구분하며 QA 실패는 담당에게 반환하고 수정 뒤 독립 재실행해야 한다.

## 12. Gate C에 제출할 남은 산출물과 보고 상태

Backend의 다음 설계 산출물은 역할/소유권·필드/상태·오류/pagination·멱등 key가 포함된 API 계약, 15개 모델 및 추가 모델의 ERD/제약, 카테고리 schema registry, provider adapter manifest, versioned 가격/QC 정책, lease/fence/CAS/outbox·읽기 consistency·rollback 계약, 삭제/보존·권리 deny policy, 최소 수익 fact/원장·대사 계약이다. 원문 ID를 FR/POL과 연결하고 각 필드의 출처·사용권·관측·확인 상태를 추적해야 한다.

공식 provider 권리·완결성·전환 증빙과 로그인 제공자 기능은 외부 미확인 전제다. 이를 확인하지 못해도 합성 fixture 기반 제한 설계/PoC 준비는 가능하지만 실제 수집·OAuth·정산·push·운영 통과로 승격할 수 없다. 실제 실행을 시작할 때마다 선택 도구·버전·현재 자원·비용·권한을 다시 확인한다. 일반 개발 판단을 매번 승인 요청으로 막지 않으며 사용자 Gate B, 비용/외부 변경, 개인정보 확대, 공개 출시 경계는 유지한다.

- **실제 수행:** 위 근거 문서 정적 열람·상호 대조, Backend 위험·정책 반환 항목·계약 제안·future test matrix 작성. 배정받은 이 문서만 작성했다.
- **미수행:** 코드/SQL/OpenAPI 구현, 패키지 설치, DB/계정/외부 자원 생성, API/공급처 호출, PoC·단위/통합/부하/E2E·보안·rollback 시험, 배포/광고비 집행.
- **QA/검수:** Backend 작성자 검토 문서다. Independent QA 승인·제품 기능 테스트·Team Lead Gate C 검수·사용자 승인 없음.
- **현재 판정:** 설계 구체화와 제한 PoC 준비 항목을 제시했다. 구현 준비 완료, Gate 통과, 출시 준비 완료로 보고하지 않는다. 공식 출시 **HOLD** 유지.

원문 RTM 연결은 `REQ-L0465`, `REQ-L0470`, `REQ-L0477`, `REQ-L0479`, `REQ-L0492`, `REQ-L0498`, `REQ-L0500`, `REQ-L0510`, `REQ-L0518`, `REQ-L0521`, `REQ-L0529`, `REQ-L0531`, `REQ-L0564`, `REQ-L0566`, `REQ-L0581`, `REQ-L0583`, `REQ-L0587`~`REQ-L0601`, `REQ-L0619`, `REQ-L0621`, `REQ-L0629`~`REQ-L0637`, `REQ-L0639`, `REQ-L0801`~`REQ-L0805`, `REQ-L0809`, `REQ-L0810`, `REQ-L0817`, `REQ-L0836` 등을 시작점으로 Team Lead가 **각 원문 행**을 대조한다. 범위 표기는 중간 행의 추적을 생략한다는 의미가 아니다. 이 문서의 BE-C/POC-B/BE-T는 내부 검토 ID이며 사용자 요구사항 ID를 대체하지 않는다.
