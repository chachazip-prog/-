# 꼬까픽 vNext 클라우드 작업 재개 지침

이 작업은 이미 격리된 클라우드 환경이다. 기존 체크아웃 `/workspace/-`를 사용하고, 사용자가 명시적으로 요청하지 않으면 Git worktree를 만들지 않는다. 현재 산출물은 Phase 0/1 초기 문서·가정 모델·격리 SQLite 카탈로그 PoC이며 앱 서비스/SDK 환경이 완성됐다는 뜻은 아니다.

1. `/workspace/-`에서 `AGENTS.md`, `PROJECT_STATE.md`, `NEXT_ACTIONS.md`, `DECISIONS.md`, `QA_STATUS.md`를 읽고 `git status --short`로 기존 변경을 보존한다.
2. 검증된 환경은 Python3.12.14 / SQLite3.53.1이다. 외부 패키지 설치 없이 저장소 루트에서 아래 검사를 실행할 수 있다. 이전 통과 코드/계약이 변하지 않았으면 결과/hash를 확인하고 이유없이 suite를 반복하지 않는다. 새 환경/변경/실패 진단 시 해당 명령을 실제 실행한다.

```sh
cd /workspace/-
python3 tools/validate_project.py
python3 tools/revenue_model.py --check
python3 tools/run_catalog_poc.py
```

첫 검사는 원문/RTM·PoC추적/문서 연결·HOLD, 둘째는 가정 기반 수익 CSV 재현/산술, 셋째는 독립 QA가 작성한 격리 SQLite 합성57tests다. 최초46/error2 관측 오류와 최종57/57 결과는 별도 보존돼 있다. 제품 기능/공급처 권한/운영PostgreSQL/디자인/기기/사용자 승인 검사로 표현하지 않는다. 실패 시 실제 이유를 읽고 관련 담당에게 반환한다.

PoC의 실제 임시DB 시연 명령은 `PYTHONDONTWRITEBYTECODE=1 python3 experiments/catalog_integrity/demo.py`다. 실행 후 임시 DB를 제거하며 실제 상품/사용자·비용·외부write가 없다. 최신 결과/범위는 `docs/qa/CATALOG_POC_REVIEW.md`, `docs/qa/catalog_poc/EXECUTION_RESULT.json`, `docs/reports/CONTINUATION_REPORT_2026-10-12.md`를 읽는다. 재현은 새 운영서비스를 승인하지 않는다.

3. 공식 경쟁/공급처/가격/스토어 조사는 저장된 network draft의 runtime 적용을 확인한 뒤 실제 TLS/프록시 읽기 요청으로 재검증한다. 저장/발행/현재 동작은 별개다. 기존 Git 인증을 사용하고 토큰 값/credential 파일을 출력하지 않는다. `/tmp/kkokkapick-vnext-reference`가 없으면 사용자 지정 기존 프로젝트를 읽기 전용 참고 경로에 다시 clone하여 저장된 commit을 검증하되 신규 앱 코드/데이터로 이관하지 않는다.
4. 원문 source ledger의 913행을 기능 완료율로 해석하지 않는다. Gate A의 상세 의미/정책 연결을 보강하고, Gate B 사용자 승인 전에 주요 화면 본격 구현을 하지 않는다. 독립 QA는 검증 대상을 직접 수정/자체 승인하지 않는다.
5. 현 단계에서 다시 시작할 앱/API/DB/worker 프로세스는 없다. 향후 ADR/PoC 이후 실제 필요 SDK·서비스를 설치하고 build/health/기능 요청을 실행한 뒤 install/start 설정을 업데이트한다. helper 파일이나 PID만으로 준비 완료라고 표시하지 않는다. Linux에서 iOS 서명/RC를 검증했다고 보고하지 않는다.
6. 정식 출시 **HOLD**를 유지한다. 외부 유료 자원·광고 집행·외부 데이터 변경·출시는 별도 사용자 승인 대상이다. 작업 결과와 증거를 repository 상태 문서/RTM에 저장하고 실제 진행하지 않는 백그라운드 작업을 주장하지 않는다.
