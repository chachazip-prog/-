# 개발·검증·운영 환경 계획

- 기준일: 2026-10-11, Asia/Seoul
- 작성: 독립 DevOps & FinOps Engineer
- 상태: 착수 문서 작성/읽기 전용 점검 완료; 앱 환경 설치·실행은 **Not Started**
- 적용 ADR: [ADR-001](../architecture/ADR-001-STACK-CANDIDATES.md), **Proposed**
- 일반 사용자 출시: **HOLD**

## 확인한 실행 환경

검증 명령과 원문 결과는 [RUNTIME_EVIDENCE.json](../research/infra/RUNTIME_EVIDENCE.json)에 있다. Node 24.19.0, npm 11.9.0, Python 3.12.14, Git 2.52.0, Java 21.0.12.1, Docker CLI·daemon 28.4.0을 확인했다. 4 core CPU quota, 32 GiB 메모리 상한, workspace 약 30 GiB 여유를 관측했다. `nproc=5`보다 quota를 빌드 병렬성 기준으로 삼는다. Go executable은 버전 명령이 실패하므로 사용 가능하다고 보고하지 않는다.

Flutter, Dart, Android adb/emulator, Gradle, psql, Supabase CLI, Xcode, Swift는 현재 확인되지 않았다. 초기 기획 산출물에는 필요하지 않으며 ADR 이후 기술 PoC 준비 대상으로 기록한다. Android emulator가 동작하려면 가상화/KVM·메모리·가상 기기 지원을 별도 확인한다. macOS/Xcode가 없는 Linux에서 iOS archive·서명 검증을 수행했다고 보고할 수 없다.

관리형 환경 상태는 running/connected, 최신 관측이며 네트워크 state는 unknown이었다. 구성된 app secret/runtime variable/outbound identity는 0개로 보고되었다. 실제 프로세스에는 GitHub token 이름이 존재했지만 값을 읽거나 복사하지 않았다. DB/Supabase/Apple/FCM 관련 명시적 환경 변수는 미설정이다. 기존 바인딩·HTTPS Git proxy가 별도로 인증을 제공할 수 있으므로 특정 토큰 이름 없음만으로 GitHub 접근 불가라고 판단하지 않는다.

## 기본 개발 동선과 필요한 체크

Phase 0/1은 Markdown/JSON/CSV 검토·요구사항 추적·공식 자료 조사다. 코드를 구현하거나 외부 서비스를 생성하지 않는다. ADR 선택 후 기술 PoC는 기존 `/workspace/-` checkout과 합성 fixture를 사용한다. 각 cloud task는 이미 격리되므로 별도 Git worktree를 생성하지 않는다.

| 시점 | 필요한 검증 | 선택/후속 검증 |
| --- | --- | --- |
| 착수 | Git 상태, 읽기 전용 도구·자원·네트워크 관측, 문서 정합성 | 외부 단가 확인(허용 도메인 필요) |
| 기술 PoC | 선택한 SDK 버전/무결성, 로컬 DB, API smoke, 공급처 합성 데이터 품질 Gate/복구 | Supabase 로컬 스택, Android emulator(가능할 때) |
| 구현 | lint/typecheck, meaningful unit/integration, API 권한, signed contract/schema compatibility | 추가 브라우저/디바이스 matrix 확대 |
| 통합/출시 준비 | 기기 E2E, 성능·검색·복구·권한·개인정보 삭제, 외부 공급처 권한, 독립 QA | 확장 규모의 soak와 장애 주입 |
| 릴리즈 | iOS/Android 서명 RC, staging 운영 시나리오, 실제 restore/rollback, 법적 요건, 사용자 승인 | 공개 출시 이후 자동 확장(별도 비용 승인) |

## 환경 분리

| 환경 | 데이터 | 인증·권한 | 외부 연동 | 배포/사용 범위 |
| --- | --- | --- | --- | --- |
| Local/Cloud dev | 합성 데이터, 합법적 fixture | dev 계정, 운영 권한·키 금지 | 기본 mock; 승인된 sandbox만 | 개발자·검수 전용 |
| Staging | 합성 또는 적법하게 비식별 처리된 검증 데이터 | 독립 프로젝트·키·OAuth redirect·역할 | 승인된 test credentials, 송금·광고 집행 없음 | 제한된 검수자, 자동 공개 preview 금지 |
| Production | 수집 권한·동의·보관 근거가 있는 실제 데이터 | 별도 최소 권한·감사·강제 MFA 운영자 | 승인된 계약·키·정산·광고 계정 | Gate F 및 사용자 출시 승인 전 HOLD |

같은 DB의 schema 이름만 달리한 staging/production은 권한·삭제·백업 사고 격리가 부족하다. 독립 데이터베이스/자원·비밀키·스토리지·백업·로그를 원칙으로 하고 무료 프로젝트 수/요금은 확인 후 예산에 반영한다. production 데이터를 staging으로 복사하는 기본 동선은 두지 않는다. 공개 staging과 관리자 페이지에는 색인 금지뿐 아니라 접근 통제를 적용한다.

## 설치·로컬 실행의 다음 순서

1. Git 상태 및 사용자 변경을 보존하고 선택 SDK/프레임워크 version pin, 지원 플랫폼, lockfile을 확인한다. 기존 저장소에서 코드·lockfile·데이터를 복사하지 않는다.
2. 공식 artifact·checksum·서명·TLS를 유지해 workspace 안의 도구/캐시로 설치한다. verification을 비활성화하지 않는다. root 권한이나 sandbox 밖 쓰기가 필요하면 이유와 실제 경로를 검토한다.
3. Node/Flutter/Android 캐시는 로컬 전용/ignored 경로 또는 checkout 밖 workspace 경로를 사용한다. 선택한 repo의 frozen-lockfile 설치를 사용한다. installer가 tracked dependency/lockfile을 바꾸지 않는지 확인한다.
4. PostgreSQL 컨테이너 1개로 시작하고 service port는 loopback에만 바인딩한다. 실제 secret이 아닌 로컬 전용 값도 version control에 저장하지 않는다. Supabase 전체 스택은 후보 선택 이후 필요할 때만 추가한다.
5. 컨테이너 실행 전 managed runtime의 Docker proxy·CA 안내를 읽는다. host proxy를 임의로 제거하지 않고 container trust를 지원 방식으로 구성한다. credential placeholder를 이미지 layer·build arg·로그에 복사하지 않는다.
6. Flutter SDK/Android toolchain이 필요할 때 artifact를 검증하고 `flutter doctor` 결과를 기록한다. SDK licence가 별도 동의 조건을 요구하면 내용을 확인한다. iOS toolchain은 승인된 macOS 자원에서 별도로 준비한다.
7. 준비한 서비스는 실제 health/readiness, API smoke, fixture import, quality rejection, worker 재실행을 검증한다. 이 체크 전 설치 성공만으로 working environment로 판정하지 않는다.
8. 실제 확정된 명령만 reusable install/start 지침에 저장한다. 아직 명령을 실행하지 않았으므로 현재는 실행 가능한 설치 script나 보장된 demo URL을 제공하지 않는다.

시작 시 병렬성은 2 worker를 제안한다. 실제 peak RSS·디스크·CPU를 관측하고 필요하면 4 quota 안에서 조정한다. SDK·Gradle·container image는 디스크를 공유하므로 중복 전체 빌드와 불필요한 image pull을 피한다.

## 프로세스 수명·재시작 계약

cloud 개발 환경은 운영 호스팅이 아니다. 세션 종료/재생성 뒤 프로세스·포트·로컬 DB volume이 영구 보존된다고 보장하지 않는다. 시작한 프로세스마다 명령·working directory·pid/session id·포트·로그 경로·health 결과를 기록한다. 실제 실행 중일 때만 실행 중이라고 보고하고 종료되면 상태를 갱신한다.

재시작 지침은 DB health → idempotent migration → synthetic seed 존재 확인 → worker lease 회수 → API/Admin start → health/smoke 순서다. seed는 기존 데이터를 덮어쓰기 전에 명시적 개발 모드를 검사한다. 운영 migration과 seed를 한 자동 명령으로 묶지 않는다. 이미 실행 중인 포트/서비스를 확인해 중복 시작하지 않는다. 작업 종료 시 불필요한 프로세스는 정리하고, 유지가 필요한 개발 서비스도 세션 지속 범위를 기록한다.

worker는 장시간 프로세스의 생존에만 의존하지 않고 DB 작업 상태·lease 만료·retry 수·idempotency key·checkpoint를 저장한다. 중단 뒤 재실행해도 중복 클릭·알림·상품 비활성화가 없어야 한다. production scheduler·worker autoscaling 정책은 승인 후 선택한다.

## 네트워크 목적지와 실제 차단

공식 HTTPS 요청은 기본 CA/TLS 검증과 inherited proxy로 수행했다. 아래 6개 목적지는 모두 proxy tunnel 403으로 차단되었고 공식 본문을 받지 못했다. [FETCH_RESULTS.json](../research/infra/FETCH_RESULTS.json)에 실제 진단이 있다. proxy 경유 정책 오류이며 provider 계정 실패로 분류하지 않는다.

| 목적 | 요청 domain | 필요한 내용 |
| --- | --- | --- |
| PostgreSQL/Auth 관리형 후보 | supabase.com | 요금·용량·백업·상업 이용 조건 |
| 관리자 hosting 후보 | vercel.com | 요금·usage·plan 조건 |
| CI 후보 | docs.github.com | Actions runner·artifact·billing |
| CDN/edge 후보 | www.cloudflare.com | 요금·상품별 조건 |
| Flutter iOS | docs.flutter.dev | macOS/Xcode·플랫폼 지원 지침 |
| Apple 배포 | developer.apple.com | 가입/서명/배포 조건과 요금 |

기존 전체 allowlist를 불명 상태에서 대체하지 않는다. 위 항목은 **문서 조사용 추가 후보**다. 실제 DB host/API/OAuth callback/FCM/APNs/공급처 endpoint는 공급자와 권한을 확정한 뒤 최소 목적지로 검토한다. DB 직접 TCP는 현재 허용 목적지 구성이 없어 별도 지원 workflow가 필요할 수 있다. TLS를 끄거나 proxy/VPN 경로를 우회해 차단을 해결하지 않는다.

## 필요한 변수·인증은 선택 후 최소 요청

| 기능 | 후보 요구사항 이름(값 금지) | 시점/범위 |
| --- | --- | --- |
| DB/API | DATABASE_URL 또는 선택 DB binding | 기술 PoC는 로컬값, staging/prod는 환경별 secure settings |
| Supabase 선택 시 | SUPABASE_URL, 공개 클라이언트 키, 서버용 privileged binding | 공개 키도 RLS 검증; privileged 키는 서버 전용 |
| 공급처 | 공급처별 credential binding + 승인 계정 | 공식 계약 확인 후 worker 전용 |
| Apple/Android | Apple Team/App ID, signing certificate/profile, Android keystore binding | RC 단계, mobile/CI secure storage |
| 푸시 | APNs/FCM 선택 provider binding | 실제 알림 검증 시 최소 scope |
| 관리자 | 운영자 identity/MFA/RBAC 연결 | staging부터 서버·DB에서 강제 |

표는 누락 secret을 일괄 생성하라는 지시가 아니다. 선택되지 않은 공급자의 secret을 미리 요구하지 않는다. 설정 names/presence 및 실제 동작을 먼저 확인하고, 필요한 경우에만 secure environment settings를 통해 값을 입력하도록 안내한다. 채팅에 secret 값을 요청하지 않는다.

## 현재 검증 상태와 다음 작업

실행한 것은 환경 관측·버전 명령·공식 자료의 읽기 전용 요청이다. Docker 서비스가 존재함을 확인했으나 PostgreSQL/앱/worker는 시작하지 않았다. 가격 확인은 Blocked, 앱 SDK 설치/빌드·API smoke·기기 테스트·복구 테스트는 Not Started다. 공식 단가 조사용 network 설정 후 요청을 재시도하고, ADR·기술 PoC 범위 선택 뒤 설치/실행 지침을 구체화한다. 외부 자원 생성·배포·과금은 별도 사용자 승인 전 수행하지 않는다.
