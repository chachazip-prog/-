# CI·릴리즈·모니터링·복구 계획

- 기준일: 2026-10-11, Asia/Seoul
- 작성: 독립 DevOps & FinOps Engineer
- 상태: **Proposed**; CI workflow 생성/실행·배포·복구 훈련은 Not Started
- 기술 결정: [ADR-001](../architecture/ADR-001-STACK-CANDIDATES.md) 확정 전
- 정식 출시: **HOLD**

## 단계별 CI 검증과 독립 QA

CI는 반복 가능한 검사를 담당하고 QA는 기능·정책·기기·디자인·운영 여정을 독립 검증한다. CI 성공만으로 QA Passed 또는 Approved/Released로 표시하지 않는다. 구현 담당이 자신의 QA 승인이나 보안 승인을 대신하지 않는다.

| pipeline | trigger/범위 | 필요한 검사 | 결과/다음 Gate |
| --- | --- | --- | --- |
| 문서 착수 | 로컬 변경 검토 | 원문·RTM·link·상태·JSON/CSV 검증 | Phase 0/1 증빙; 제품 QA 아님 |
| PR 검증 | 승인된 저장소에서 신뢰 경계별 trigger | version pin/lockfile, lint/typecheck, 의미 있는 unit/integration, contract/schema, 권한 테스트, secret/dependency 검사 | Gate D 근거 일부 |
| 공급처/데이터 | 변경 fixture/adapter 또는 승인된 sandbox | idempotency·partial failure·out-of-order·stale·delta/full 구분·count drop·quality rejection·rollback | Gate C/D/E 증빙 |
| 관리자 E2E | staging 또는 로컬 격리 fixture | role별 조회·수정·품질 큐·동기화 제어·대량 변경 거부·audit·삭제 시나리오 | 독립 QA 실행에 제출 |
| 모바일 CI | SDK 확정 후 | flutter analyze/test 후보, Android build, iOS simulator/build(별도 Mac), API 계약·route/deeplink | 기기 QA와 서명 RC를 대체하지 않음 |
| 성능/복구 | 승인된 합성 부하·격리 restore target | 10k/100k/500k/1m 단계 부하, 검색 p95, restart/retry·backup restore·catalog generation rollback | 미달 시 Release 차단 |
| RC | 검증된 commit + 명시적 release 요청 | immutable artifact, SBOM/checksum/version, signing, smoke, staging 여정, approval evidence | Gate E/F 검토 후 제한 배포 |

실제 CI toolchain 명령·SDK matrix는 repo가 생성되고 ADR가 확정된 후 기록한다. 존재하지 않는 app code/lockfile에 대한 workflow를 먼저 생성하거나 실행 성공을 주장하지 않는다. 캐시 키는 SDK/OS/lockfile을 포함하고 mutation된 cache를 release artifact의 신뢰 근거로 사용하지 않는다.

## CI 보안과 비용

GitHub Actions는 후보이며 repo의 public/private 여부, 계정 plan, Linux/Mac runner·artifact/cache 단가가 미확인이다. 공식 billing 문서 요청은 [FETCH_RESULTS.json](../research/infra/FETCH_RESULTS.json)의 CONNECT 403으로 실패했다. 현재 CI 사용량/무료 분량/Apple 가입 비용을 임의로 기재하지 않는다. 실제 runner 실행·유료분 활성화는 승인된 예산 범위에서만 진행한다.

PR untrusted code에는 production/staging/signing secret을 제공하지 않는다. fork 입력과 권한 있는 release job을 분리하고 untrusted PR 코드를 privileged `pull_request_target`류 context에서 실행하지 않는다. action 버전/commit pin을 검토하고 permissions는 job별 최소값으로 둔다. OIDC 또는 secure binding을 지원하면 단기 권한을 우선하며 실제 공급자 지원·trust policy를 확인한다. CI 로그·artifact·crash dump에 secret/사용자 데이터가 없는지 검사한다.

release signing key·keystore·certificate·profile은 secure settings에서 환경별 분리한다. ephemeral Mac keychain에 필요한 범위만 주입하고 빌드 후 정리한다. 인증서 만료·revocation·접근 소유자와 recovery 절차를 기록한다. 인증 자료를 repository·artifact·도커 layer에 저장하지 않는다.

취소 가능한 중복 PR job과 변경 범위 filter, lockfile cache, artifact 만료를 사용한다. 단, cache 때문에 서명/checksum을 생략하거나 필수 iOS QA를 비용 절감 명목으로 제거하지 않는다. Mac runner 분당 단가·OS/version·queue wait는 실제 확인 후 CI 월 예상비에 반영한다.

## 개발·staging·production 승격

개발은 현재 격리 cloud/local 환경의 합성 데이터가 기본이다. staging은 production과 별도 resource·DB·storage·키·OAuth redirect·audit scope를 사용한다. 외부 preview/프로젝트 생성·데이터 upload도 사용자 승인 없이 실행하지 않는다. CI code 작성과 외부 CI 실행·배포는 다른 실행 상태로 기록한다.

staging artifact가 검증되면 동일 commit·version·checksum으로 production 후보를 만든다. staging에서 다시 build한 출력과 production에서 별도 생성한 출력이 동일하다고 추정하지 않는다. 환경변수 주입·공급자 차이가 있으면 동등성 검사 항목을 기록한다. 배포 가능한 artifact와 실제 production release 상태를 분리한다.

배포 전 release record에는 commit hash, version/build number, artifact checksum, SDK/runner, migration set, data generation, feature flags, RTM coverage, QA/security/design 검수 링크, 알려진 결함, rollback 대상, 비용·법적 승인 증거를 포함한다. P0/P1 미해결·미검증 공급처·계정 삭제 미완료·stale 가격 알림 위험·법적 준비 부족은 release blocker다.

## Gate F와 사용자 출시 승인

일반 사용자 정식 출시는 사업자등록과 필수 법적·운영 준비 완료 증거, 공급처/광고·이미지 권한, 개인정보·약관·탈퇴/삭제, 스토어 요건, 독립 QA, 운영자 시나리오·복구·롤백 검증 및 **별도 사용자 출시 승인**이 모두 필요하다. 어느 하나 미확인일 때 HOLD를 유지한다. 스토어 제출·광고 집행·유료 서비스 가입·외부 계정/DB 변경도 각각 승인 범위에 포함되는지 확인한다.

iOS Release Candidate는 승인된 macOS/Xcode·Apple signing 기반에서 만들어야 한다. Linux에서 Flutter code를 작성하거나 Android/Web build가 성공해도 iOS RC 통과가 아니다. iOS simulator와 Android emulator만으로 실제 기기/스토어 심사 검증 완료로 표시하지 않는다. App ID 기본안 `com.kkokkapick.app`의 실제 사용 가능성과 소유권은 미확인이다.

## 모니터링과 alert 계약

| 영역 | 관측 지표 | 대응 기준의 원칙 |
| --- | --- | --- |
| API/Search | 오류율·timeout·p95·검색 empty/성공률·DB pool/느린 질의 | 실제 목표·기준선·사용자 여정 영향으로 수치 확정 |
| Catalog | provider/category별 count·신선도·offer 수·이미지 정상률·price 이상 | 공급처별 합의 threshold 위반은 generation 승격 차단 |
| Sync/Worker | last success·queue lag·lease expiry·retry·dead letter·provider quota | 실패 batch 노출 금지, 정상 generation 유지, 담당자 triage |
| Notifications | 중복·stale 가격·send success·invalid token·동의 상태 | 신선도/동의 실패 발송 거부, 사고 시 발송 kill switch |
| Affiliate/Ads | link 유효성·click와 confirmed conversion 구분·ad no-fill | 잘못된 링크/추적 분기 alert, 구매 이동을 광고로 강제 차단하지 않음 |
| Admin/Security | 권한 실패·대량 변경 거부·감사 연속성·계정 삭제 job | 민감정보 최소화, 높은 권한 작업 승인/재인증, security owner review |
| Cost | usage·quota·forecast/invoice·CI Mac·egress·storage | 승인 예산 대비 70%/90% 경고·100% 초과 전망 통제안 |

threshold 숫자와 notification 수신자·channel·운영시간은 policy/부하·운영 책임자를 확인한 후 확정한다. 기본 dashboard는 지표가 없으면 Unknown을 보여 주며 실제 측정치로 꾸미지 않는다. 로그에는 사용자/아이 생일·이름·사진·token·URL credential을 저장하지 않는다. 감사 로그와 분석 telemetry는 목적·접근·보관을 분리한다. 외부 Slack/email 메시지 전송은 승인 전 실행하지 않는다.

## 백업·복구와 데이터 사고

초기 제안 목표는 **RPO 24h / RTO 4h**다. 이는 검증되지 않은 계획값이며 실제 legal/data 계약·알림 신선도·운영시간·상품 snapshot 규모와 backup 요금을 보고 확정한다. 복구점과 generation rollback은 서로 다른 기능이다. managed 무료 plan이 백업/PITR를 제공한다고 가정하지 않는다.

backup은 DB/필수 object metadata/config·access policy를 포함하며, 암호화·접근 분리·보관·삭제·복원 target을 정의한다. secret 값은 backup 문서나 CI artifact에 넣지 않는다. 특정 plan의 backup 포함/별도 과금과 복구 실행 권한을 확인한다. backup 생성 성공만으로 복구 성공이라고 기록하지 않고 격리 target에서 restore·행/관계/권한·대표 검색·audit·사용자 삭제 상태를 검증한다.

대량 상품 급감/잘못된 category·offer merge/가격 오염 감지 시 아래 순서를 runbook에 구현한다.

1. 영향 provider와 generation 승격·삭제·가격 알림을 정지한다. 직전 정상 generation을 계속 제공하고 freshness label을 갱신한다.
2. job id/원본 snapshot·count/오류·마지막 성공/승격 기록을 보존한다. 민감한 token·data를 incident report에 넣지 않는다.
3. Source/Data 및 운영자가 권한 있는 원본·partial response·pagination·quota·매핑 변경을 점검한다. 누락 응답을 상품 종료로 처리하지 않는다.
4. 격리 fixture/restore target에서 원인을 수정·재실행·QA하고 승인한 generation만 승격한다. 영향 범위와 계정/알림 상태를 재검증한다.
5. 실제 실행 시각·복구점·RPO/RTO 결과·누락/중복·재발 방지를 기록한다. 감사 기록은 되돌림으로 삭제하지 않는다.

## 릴리즈 롤백

API/Admin은 이전 검증 immutable artifact와 환경 config/feature flag revision을 보관한다. DB migration은 expand→검증→contract로 설계하고 이전 앱/API와 호환 기간을 둔다. schema를 무조건 down migration하거나 전체 DB를 덮어쓰는 방식으로 rollback하지 않는다. forward fix/DB restore 필요성을 incident owner와 security가 판단한다.

상품 데이터는 generation pointer를 직전 정상값으로 승격/복구하며 QA 실패 generation을 app/search에 노출하지 않는다. 가격 알림·제휴 링크·광고 feature flag는 별도 kill switch로 중단할 수 있어야 한다. 합성 데이터와 production 데이터 경계를 점검한다.

스토어 앱은 서버처럼 즉시 이전 binary로 모든 기기를 되돌릴 수 없다. 점진 rollout 중단·원격 feature flag·이전 API 호환·긴급 업데이트 경로를 준비하고 플랫폼별 실제 지원을 검증한다. 이미 배포한 사용자에게 수정 binary가 도달하는 지연을 incident 계획에 반영한다.

## 승인/실행 체크리스트

- [ ] ADR 및 version pin 확정, SDK·runner·요금 공식 근거 확인
- [ ] PR 검증과 release 권한·secret 경계 검토
- [ ] staging 환경/비용/외부 데이터 변경 승인
- [ ] Android 및 승인된 Mac iOS 실제 실행 증빙
- [ ] admin 역할별 운영·감사·계정 삭제 독립 QA
- [ ] count-drop quality gate·generation rollback·restart/idempotency 독립 QA
- [ ] 실제 isolated backup restore·RPO/RTO 측정
- [ ] 모니터링·alert 전달·비용 forecast/invoice 검증
- [ ] Gate E P0/P1=0, Security/design/운영 승인
- [ ] 사업자·제휴·이미지·광고·개인정보·스토어 근거
- [ ] 별도 사용자 Gate F/공식 출시 승인

체크박스는 모두 현재 미실행/미승인이다. 본 계획은 실제 CI 결과·배포 URL·빌드 파일·복구 보고서를 대신하지 않는다.
