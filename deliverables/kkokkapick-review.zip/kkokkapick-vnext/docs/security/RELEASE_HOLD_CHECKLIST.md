# 보안·개인정보·운영 출시 HOLD 체크리스트

- 기준일: 2026-10-11 (Asia/Seoul)
- 담당: Security & Privacy Engineer
- 현재 상태: **HOLD — 일반 사용자 대상 정식 출시 승인 없음**
- 문서 성격: Phase 0/1 출시 조건 초안. 법률 의견·앱 심사 통과·침투 테스트 결과가 아니다.
- 원문: [MASTER_PROMPT.md](../source/MASTER_PROMPT.md) §0.1.10, §11–15
- 연결: [보안 설계](SECURITY_PRIVACY_PLAN.md), [데이터 인벤토리](DATA_INVENTORY.md), [공식 출처 접근 증빙](../research/security/OFFICIAL_SOURCE_REVIEW.md)

## 1. 현재 가능한 작업과 출시 보류

공개 자료 조사·로컬 문서·합성 데이터 기술 PoC·검토용 디자인은 진행할 수 있다. 이는 실제 공급처 데이터 사용 권한, 광고비 집행, 유료 플랜 생성, 운영 사용자 데이터 처리, 스토어 제출 또는 공개 출시를 승인한 의미가 아니다. 마스터 프롬프트에 따라 사업자등록 및 필수 법적·운영 준비 완료 전 일반 사용자 출시를 HOLD로 유지한다.

현재 사업자등록·계약·개인정보 처리 책임자·credential·스토어 정책 확인 증빙은 제출되지 않았다. 이는 실제로 존재하지 않는다고 단정하는 표현이 아니라 **프로젝트에서 확인하지 못한 상태**다. 사용자 또는 권한 보유자가 근거를 제공하면 해당 항목을 재검토한다.

## 2. 체크리스트

| ID / Gate | 출시 조건 | 현 상태·미충족 이유 | 담당·필요 증빙 |
| --- | --- | --- | --- |
| HOLD-01 A/F | 사업 주체·사업자등록·대외 책임·공개 연락처 확인 | BLOCKED — 미제공/미확인 | 사용자/운영 담당: 등록·필수 신고 해당 여부·법률/운영 검토. 민감 등록서류를 공개 repo에 저장 안 함 |
| HOLD-02 A/F | 개인정보 처리 책임자·약관/처리방침·권리 요청/문의/신고 채널 | NOT STARTED — 최종 서비스·처리자 미정 | Planner + Security + 법률 검토자: 실제 데이터/목적/기간/국외 이전/연락처에 맞춘 문서·운영 시나리오 |
| HOLD-03 A/B/C | 아동 정보 최소화·성인 보호자 제품 대상·동의 적합성 | DRAFT — 월령 구간/사이즈 선택형·메모리/세션 전용 Working Default. 영속 저장/동기화 Proposed opt-in, 기본 OFF | 사용자: 최소 범위·저장/다자녀/동기화 승인; Planner: PRD; Security: 법률·스토어 적용 검토; Designer: 거부/삭제/세션 종료 상태 |
| HOLD-04 C/F | 다중 공급처 자격·API·저장/이미지·후기·가격 history 권리 | BLOCKED — 실제 승인·계약 미확인 | Source + 사용자: 공식 조건·계약·이미지/로고/폰트 ledger·만료/종료 삭제 절차. 공급처 다변화의 출시 요건을 Planner와 확정 |
| HOLD-05 C/D/E | 로그인 제공자·broker 지원·최소 scope·계정 연결/삭제 | BLOCKED — 공식 문서 403, 제공자 선택·개발자 설정 미정 | Backend/Mobile + Security: 공식 문단·등록 설정·PKCE/state/claim·가입/복구/연동 해제 테스트 |
| HOLD-06 C/D/E | 관리자 RBAC·MFA·개별 계정·감사·고위험 승인 분리 | NOT IMPLEMENTED | Backend/Admin + Security: deny-default 권한표·MFA 실제 동작·역할별 API·권한 회수·audit redaction 결과 |
| HOLD-07 C/D/E | 비밀 관리·키 최소 권한·환경 분리·공급망 통제 | NOT IMPLEMENTED | DevOps + Security: secret scan·client 번들/로그 검사·rotation·CI 최소 권한·lockfile/서명/TLS 유지 증빙 |
| HOLD-08 C/D/E | 카탈로그 급감 차단·원본 격리·멱등·실패/롤백 | NOT IMPLEMENTED | Source/Backend + 독립 QA: 0건/부분 feed·카테고리 감소·역순 배치·재시도·catalog-only rollback, 최신 사용자/동의/찜/알림 상태 미부활 실제 결과 |
| HOLD-09 C/D/E | 제휴 링크 허용 목록·open redirect·SSRF·외부 이동 고지 | NOT IMPLEMENTED | Backend/Mobile + Security/QA: 승인 Provider redirect 체인·악성 URL·이미지 SSRF·실제 기기 구매 이동 |
| HOLD-10 C/D/E | webhook 진위·replay/dedupe·클릭/전환/정산 구분 | NOT IMPLEMENTED — Provider 증빙 범위 미정 | Source/Backend/Finance + QA: 공식 서명 규격·event ID·재전송/역순·정산 대조 증빙; 미검증은 확정 매출 금지 |
| HOLD-11 A/C/D/E/F | 동의·알림 권한·철회·광고·ATT/Android·국외 이전 | BLOCKED — 실제 SDK/데이터 map·공식 정책 미확인 | Planner/Growth/Mobile + Security: 추적 영향 검토·최신 공식 원문·SDK별 data map·동의 전/후/거부 트래픽·제출 정보 |
| HOLD-12 C/D/E/F | 계정 삭제·보존 예외·백업 만료·복구 후 최신 상태 재적용 | NOT IMPLEMENTED — 플랜/기간·법적 근거 미확정 | Backend/DevOps/Privacy + QA: 앱/필요 웹 경로·전체 sink 삭제·계정/토큰 폐기·최신 삭제/철회/찜·알림 해제 재적용·실제 백업 기능. 최신 상태 완전성 불명 또는 재적용 실패 시 복구 HOLD |
| HOLD-13 E/F | 보안 점검·장애/복구·운영 대응·P0/P1 해결 | NOT RUN | Security + 독립 QA + DevOps: 위협 모델 테스트·분석·로그 마스킹·보안 사건 대응·P0/P1 0건·실제 evidence |
| HOLD-14 F | 스토어 개발자 자격·서명·RC·privacy 제출 | BLOCKED — 등록/credential·릴리즈 빌드 없음 | 사용자/Mobile/DevOps: 적합한 개발자 계정·RC·서명·심사 체크리스트·Data safety/Privacy labels 실제 데이터 일치 |
| HOLD-15 F | 유료 비용/광고비·모니터링·롤백·운영 인수 | NOT APPROVED | 사용자/DevOps/Growth: 월 50,000원 마케팅 범위·별도 인프라 예산·상한/알림·모니터링·롤백·운영 담당 승인 |
| HOLD-16 F | 독립 QA 승인·Team Lead 종합 검수·사용자 출시 승인 | NOT APPROVED | 독립 QA: 검증 보고서; Team Lead: RTM·Gate·완료 증빙; 사용자: 해당 RC·환경의 명시적 출시 승인 |

상태 `DRAFT`는 정책 제안이 있다는 뜻이다. `NOT IMPLEMENTED`/`NOT RUN`은 제품 구현/테스트가 미완료라는 뜻이다. `BLOCKED`는 명시적 외부 자격·원문·credential 등 의존성이 현재 미확인이라는 뜻이다. 하나가 해소돼도 나머지 Gate가 자동 승인되지 않는다.

## 3. 공식 정책·접근 차단

Apple review·ATT·account deletion, Google Play Data safety·deletion, Google OIDC, Kakao/Naver login 공식 HTTPS 8개 요청은 2026-10-11 프록시 CONNECT 403으로 실패했다. 실패한 원문을 읽었다고 보고하지 않았다. 필요한 추가 호스트는 `developer.apple.com`, `support.google.com`, `developers.google.com`, `developers.kakao.com`, `developers.naver.com`이다. 접근 설정이 변경되고 원문을 확인한 뒤 해당 정책을 실제 SDK/기능과 대조해야 한다. 정확한 실패 기록은 [fetch_results.json](../research/security/fetch_results.json)에 있다.

한국의 개인정보·아동 관련 보호자 동의·마케팅·광고/제휴 표시·사업자/신고·국외 이전·회계/분쟁 보존 적용 범위는 최신 공식 원문과 적절한 법률·운영 검토가 필요하다. 의무가 적용되는지·기간이 몇 년인지 여기서 단정하지 않는다. 사업자등록 하나만으로 나머지 법적·운영 요건이 충족됐다고 간주하지 않는다.

## 4. 사용자 결정이 필요한 사항 — 검토 가능한 기본안

| 결정 | 기본 제안 | 미결정 영향 |
| --- | --- | --- |
| 어린이/가족 정보 범위 | 선택 월령 구간·사이즈, 메모리/세션 전용 Working Default, 이름/생일/사진 미수집. 세션 종료 시 폐기. 추가 수집·저장은 별도 승인 | PRD·화면·schema·고지·추천·삭제 정책 확정 전 |
| 실제 로그인 조합 | broker·공식 지원·iOS 심사 조건을 확인한 뒤 Apple/Google/Kakao/Naver 후보 중 확정 | 모든 후보를 출시 지원으로 약속하지 않음. 무료 지원 여부·등록 자격 확인 전 |
| 사업/운영 책임자와 출시 자격 | 사업자·개인정보 책임·문의/권리 요청·심사 제출 책임을 지정 | 일반 사용자 출시 HOLD |
| 관리자 역할과 고위험 승인자 | 개별 MFA 계정, 상품 변경 요청자와 대량 승격 승인자 분리 | 소규모 운영에서도 고위험 자체 승인 금지; 검토자 미정 시 해당 기능 HOLD |
| 개인화 기기 영속 저장·계정 동기화·다자녀 | 세션 사용을 기본으로 유지. 기기 영속 저장과 계정 동기화는 별도 Proposed 명시적 opt-in·기본 OFF, 아직 사용자 승인 없음. 저장안 수용 시 backup 제외 | 보존/삭제·기기 공유·수집 확대·다자녀/광고 공유 영향과 필요성을 별도 검토 |
| 광고·추적 방향 | 명확한 문맥 광고/제휴 표시와 최소 이벤트; 맞춤 광고/추적 SDK는 평가 후 승인 | 수익화 요건을 삭제하지 않고 SDK/제휴 실현 가능성과 정책을 별도로 준비 |
| 삭제·보존·backup 운영안 | 온라인 7일, backup 30일은 후보 목표. 실제 플랜·법률에 맞춰 확정 | 달성 여부·예산·고지 문구 확인 전 보장 불가 |

일반 문서화·합성 데이터·위험 분석은 위 결정 전에도 진행한다. 주요 개인정보 확대·반복 과금·광고 집행·공식 출시 등 마스터의 승인 대상은 명시적 승인 전 실행하지 않는다. 이 체크리스트는 승인 질문 자체를 대체하지 않는다.

## 5. credential·권리 확보 방법

필수 external credential은 **선택한 연동이 실제로 필요해지는 시점**에만 등록한다. 현재 필요한 값 목록을 채팅으로 받지 않는다. 안전한 환경 설정에서 auth/backend, OAuth, 승인 Provider, push/이메일, signing/store 계정의 이름·용도·필요 권한을 안내한다. 기존 주입 credential과 actual runtime 상태를 먼저 확인한다. 플랫폼 Git proxy 인증을 앱 credential과 혼동해 GitHub 토큰을 중복 요청하지 않는다.

OAuth 개발자 등록, 제휴 가입·계약, 공급처 이미지·상품 저장권, 광고망 등록, 앱스토어 개발자 등록은 사용자의 사업 주체·등록 자격 및 해당 서비스 승인이 필요할 수 있다. 각 조건은 공식 문서/계약으로 검증한다. 미확인 항목을 자동 가입·유료 결제·라이브 데이터 수집으로 우회하지 않는다.

## 6. 독립 승인·HOLD 해제 규칙

각 차단 항목에는 담당자, 실제 완료일, 증빙 경로, 대상 build/config revision, 검토자, 미해결 이슈와 재검사 결과를 연결한다. 비밀값·사용자 데이터 원문을 증빙으로 넣지 않는다. Security는 통제·위험을 검토하고 Independent QA는 구현한 기능을 수정/자체 승인하지 않으며 실제 테스트를 수행한다. Team Lead는 역할별 결과와 RTM을 직접 대조한다.

일반 사용자 출시 HOLD 해제에는 법적·사업·제휴·스토어 요건 확인, Gate A–F의 필수 증빙, P0/P1 해결, 독립 QA, 운영/보안 검토와 **대상 RC·운영 환경에 대한 사용자 명시적 출시 승인**이 모두 필요하다. 문서 작성, 데모, CI 성공, 사업자등록, 일부 credential 주입 또는 일정 경과만으로 해제하지 않는다. 승인 후에도 변경된 SDK·데이터 범위·비용·공급처·새 RC는 영향에 따라 재검토한다.

## 7. 실제 수행·미완료·다음 단계

실제 수행은 전체 마스터 요구사항 읽기, 최소수집·위협모델·데이터/삭제/RBAC 설계 초안, 공개 공식 문서의 TLS 검증 유지 HTTPS 접근 시도와 실패 증빙 저장이다. 로컬 Markdown/JSON은 Team Lead가 검수할 수 있다.

보안 코드, 실제 공급처·SDK 연동, 인증 등록, 침투/API/E2E/복원 테스트, 법률 승인, 스토어 제출, 배포·광고비 집행은 수행하지 않았다. 다음 단계는 Phase 1 정책과 본 설계 정합성 확인, 공식 원문 접근 복구 후 검증, 사용자 결정 반영, ADR/API/ERD/화면 연결, 구현 이후 독립 QA 실행이다.
