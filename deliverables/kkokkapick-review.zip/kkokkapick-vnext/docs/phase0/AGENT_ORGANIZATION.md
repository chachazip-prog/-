# Agent Organization / 실제 실행 기록

기준일: 2026-10-11 (Asia/Seoul). 이 기록은 실제 에이전트 실행과 역할별 문서 작성 범위다. 검토 독립성은 각 에이전트가 새 역할 컨텍스트로 생성됐는지와 담당 산출물로 확인하며, 제품 기능 구현이나 승인 완료를 뜻하지 않는다.

| 역할 | 실제 실행 주체 | 맡은 경로/검수 | 상태 |
|---|---|---|---|
| Team Lead / Program Manager | /root | 원문/RTM/Charter/계획/상태/통합 보고·최종 확인 | Running |
| Product Planner | /root/product_planner | docs/product/ 4개 초기 정책/기능 문서와 충돌 수정 | Draft Written |
| UX/UI Designer | /root/ux_designer | docs/design/ 및 docs/research/ux/ | Draft Written |
| Source & Data Engineer | /root/source_data | docs/data/ 및 docs/research/provider/, rollback 일치 수정 | Draft Written |
| Mobile Frontend Engineer | /root/mobile_engineer | MOBILE_READINESS_REVIEW, RTM ID/세션 수정 | Draft Written |
| Backend Engineer | /root/backend_engineer | BACKEND_READINESS_REVIEW, API/DB/worker 위험·계약 검토 | Draft Written |
| Independent QA Engineer | /root/independent_qa | docs/qa/, 독립 문서 검수/결함 반환·재검수, 직접 수정 금지 | Initial Document Review Accepted |
| Security & Privacy Engineer | /root/security_privacy | docs/security/ 및 docs/research/security/, 최소정보·복구 수정 | Draft Written |
| DevOps & FinOps Engineer | /root/devops_finops | docs/architecture/·docs/operations/·docs/research/infra/ | Draft Written |
| Growth & Marketing Engineer | /root/growth_marketing | docs/growth/·revenue_model.py, 실제 집행 금지 | Draft Written |
| 추가 Reference Reviewer | /root/workflow_review | 기존 프로젝트 읽기 전용 회고·commit 증거 | Review Written |

## 동시성·독립성

루트 포함 동시 실행 슬롯은 7개이므로 모든 역할을 동시에 실행하지 않았다. 완료된 담당이 슬롯을 반납한 뒤 Growth/Mobile/Backend/QA를 각각 별도 에이전트로 실제 실행했다. 위 역할10개(Lead 포함)와 추가 참고 reviewer는 서로 구분된 실행 주체다. `Draft Written`은 초기 문서 작성이며 제품 구현·기능 QA·사용자 승인이 아니다.

QA는 정책/설계/구현 파일을 직접 작성/수정하거나 자체 승인하지 않는다. 발견 항목은 원 담당에게 반환하고 수정된 증거를 다시 검수한다. Lead가 작성/통합한 문서도 독립 QA 검토 대상으로 제공한다. 보안 담당의 초안은 보안 승인 완료와 구분한다.

## 전달·충돌 처리

원문→REQ ID→정책/UX/데이터/구현/테스트→독립 검수/사용자 보고를 RTM에 기록한다. 각 역할은 배정 디렉터리만 쓰고 공통 상태/RTM은 Lead가 관리한다. 규정/UX/비용 충돌은 사실·제안·가정으로 구분해 DECISIONS에 남기며 사용자 승인 대상이면 구체 산출물과 함께 제출한다.

참고 프로젝트 단독 조사 사실은 다른 에이전트가 직접 수행했다고 표현하지 않는다. 현재 공식 공개 조사 차단과 기존 프로젝트의 확인된 commit 증거는 Lead가 관련 담당에게 메시지로 전달하여 각각의 문서를 갱신하도록 했다.

## 2026-10-12 기술 PoC 후속 실행

초기 역할 표는 2026-10-11 문서 작성/검수 결과다. 사용자 계속 진행 지시에 따라 같은 독립 실행 주체에 다음 범위를 별도 배정했다.

| 역할/agent | 후속 범위 | 현재 상태 |
|---|---|---|
| Source/Data `/root/source_data` | experiments/catalog_integrity/CONTRACT.md·fixtures.py | 계약/합성 fixture42개 작성·자체 무결성 검사, guard QA 아님 |
| Backend `/root/backend_engineer` | catalog_guard.py·demo.py·README.md | 구현·14거부 시연 완료, 소스 동결 |
| Independent QA `/root/independent_qa` | tests/test_catalog_guard.py·새 QA보고/결함 기록 | 57/57 독립 실험 통과, 최초 관측 오류2건 테스트만 수정·기록, feature수정0 |
| Lead `/root` | run_catalog_poc.py·범위 ADR·epoch 위험 검토·상태/RTM/보고 | 실제 시연/로그·소스hash/추적 대조 완료, 제품상태 승격 안 함 |

계약은 구현 전에 협의·저장했다. Lead의 ABA 설계 위험 지적을 Source가 상태 세대 addendum으로 반영하고 Backend가 구현했다. 독립 QA가 ABA/동시성/실제SQL실패·현재상태보존을 검증했다. 실서비스 버그의 원인 해결이나 운영DB/제품QA를 통과했다고 주장하지 않는다.
