# 꼬까픽 vNext — 신규 프로젝트 착수 보고서

보고 단계: Phase 0 및 Phase 1 초기 산출물. 기준일: **2026-10-11 (Asia/Seoul)**. 작성/통합 검수: Team Lead `/root`. 상태: **Initial Review Draft**. 사용자 승인: 대기. 공식 서비스 출시: **HOLD**.

## 1. 신규 목표와 원래 요구사항

사용자 마스터 원문은 [MASTER_PROMPT](../source/MASTER_PROMPT.md)에서 확인할 수 있다. 목표는 육아 상품 통합 탐색·비교·규칙 기반 추천·제휴 구매 이동을 제공하는 완성도 높은 iOS/Android 모바일 서비스, 별도 비개발자용 Admin, 다중 공급처 수집/운영 파이프라인과 독립 QA·스토어/운영 준비다. 단순 데모를 최종 완료로 인정하지 않는다. 직접 재고/판매/결제는 서비스 범위가 아니다.

요구사항 추적은 [RTM](../../REQUIREMENTS_TRACEABILITY.md)에 있다. 원문 비제목/구분선 913항목을 ID와 정책 초안/담당/검증 계획에 연결했다. 이는 문맥·설명도 포함한 source ledger이며 독립 기능 수, 의미 검수 통과, 완료율이 아니다. 미구현 디자인/API/코드/실행 테스트는 비어 있는 상태로 남겼다.

## 2. 기존 프로젝트와 달라지는 점

선정된 빈 `chachazip-prog/-` 체크아웃 `/workspace/-`에 새 프로젝트 문서를 생성했다. 별도 GitHub 원격을 생성하거나 push한 사실은 없다. 기존 `chachazip-prog/kkokkapick`는 사용자가 실패 프로젝트로 지정했고 참고만 허용했다. 원본은 별도 경로에 read-only clone하여 확인했으며 앱 코드·상품 데이터는 이관하지 않았다.

[기존 회고](../phase0/LEGACY_RETROSPECTIVE.md)의 pinned HEAD는 `5d831736bfb9ab8ae220caf0d050db183a5d5f43`다. Git 이력의 catalog는 2026-10-03에 원천 **564→79**, 통합 **516→78**로 줄었다. 당시 이미지 정상률은 79/79였고 수량 coverage guard는 감소 이후 추가됐다. 파일 변화와 guard 시점을 확인한 사실이며 API 원인·사용자 노출·실제 주문 영향은 로그 없이 확정하지 않았다. 신규 정책은 실제 배열/선언 수 일치, baseline 강제, 카테고리/공급처 감소 Gate, 불완전 배치 격리, 정상 release 보존·원자 활성화·롤백을 요구한다.

## 3. 에이전트 조직과 실제 수행

[Agent Organization](../phase0/AGENT_ORGANIZATION.md)에서 실제 agent name·역할·경로·검수 독립성을 확인한다. 멀티 에이전트 실행은 실제 지원되며 동시 슬롯은 루트 포함 최대 7개다. Planner, UX Designer, Source/Data, Security, DevOps/FinOps, 기존 Reference Reviewer를 독립 실행했고 추가 Growth/Mobile/Backend/QA를 슬롯에 따라 별도 가동한다. 아직 실행하지 않은 역할은 실행으로 보고하지 않는다.

추가 Growth/Mobile/Backend/QA도 현재 각각 별도 에이전트로 실제 실행하여 사용자 요청 역할10개와 별도 참고 reviewer의 초기 산출물을 만들었다. 조직표의 Draft Written은 문서 작성 상태다. Team Lead는 원문/범위/RTM/실행 규칙/로드맵/위험/결정/상태와 본 보고서를 통합한다. Independent QA는 정책/제품 코드를 직접 수정하지 않고 문서/증거/상태의 결함을 담당에게 반환한다. 보안 검토 문서가 보안 승인 완료라는 뜻도 아니다.

## 4. 단계별 계획과 산출물 제출

[PROJECT_PLAN](../../PROJECT_PLAN.md)은 WBS, 선행 조건, 담당, 실제 제출/검증, 현재 상태를 제공한다. Phase 0/1 → IA/화면·상태/와이어프레임 → 디자인 시스템·Hi-Fi·편집 가능한 Figma 호환/프로토타입 → 사용자 Gate B → 시스템/데이터 설계 → 구현/통합 데모 → 독립 QA → RC/운영 준비 순서다. 날짜와 완료율은 근거 없이 예측하지 않는다.

이번 제출물은 Markdown/CSV/JSON 및 실제 실행 가능한 로컬 문서 검증·수익 시뮬레이션 도구다. 주요 파일은 [README](../../README.md)에서 연결된다. Figma 파일·앱·웹 프로토타입·데모 URL·스토어 빌드·CI 실행 결과는 이번에 생성하지 않았다. 이후 단계에서는 실제 접근/편집 가능성을 검증한 산출물을 제출한다.

## 5. 초기 기획과 Admin 범위

[PRD](../product/PRD.md), [Business Requirements](../product/BUSINESS_REQUIREMENTS.md), [Functional Specification](../product/FUNCTIONAL_SPECIFICATION.md), [Policy Specification](../product/POLICY_SPECIFICATION.md)은 초기 검토안이다. 비회원 핵심 탐색, 카테고리별 속성/필터, 같은 모델/옵션 가격 비교, 출처/신선도·미확인 정보 표시, 찜/알림 시 필요한 로그인, 최소 아동정보, 광고/제휴 고지와 비강제 구매 이동을 정의한다.

Admin 범위는 대시보드·상품/품질 큐·공급처/동기화·콘텐츠·회원 최소정보/삭제·광고/수익·RBAC/감사·시스템 관리다. 예를 들어 데이터 운영자가 급감 배치를 검토해 보류하고, 권한자가 실제 재검증 근거를 확인해 활성화하며, 읽기 전용 역할은 변경 요청이 차단되는 시나리오로 검증한다. DB 화면 존재만으로 운영 가능이라고 보고하지 않는다.

## 6. 상품 수집 다변화

[Provider Assessment](../data/PROVIDER_ASSESSMENT.md)와 [Data Strategy](../data/DATA_STRATEGY.md)는 ADPICK 단독 의존을 방지하는 capability/권리 기반 adapter, raw/정규화 분리, variant/offer matching, 품질 Gate/신선도/정상 release 보호를 제안한다. 원문 15 엔터티를 보존하고 `CatalogRelease`는 추가 제안으로 표시한다.

ADPICK BIZ·네이버 검색/제휴·쿠팡 파트너스·11번가·네트워크/브랜드 피드 조사표는 가입/승인·사업자·API·저장·이미지·쿼터·링크·수수료·정산·카테고리·원가를 각각 확인하도록 구성했다. **현재 공식 원문 요청은 프록시 CONNECT 403으로 차단되어 해당 제공권/수수료/API는 미검증이다.** 검색 API를 제휴 구매 API로 가정하거나 접근 불가를 해당 업체의 사용 거절로 표현하지 않는다.

## 7. 시장 조사와 UI/UX 개선 방향

[Benchmark Matrix](../design/BENCHMARK_MATRIX.md)는 마미톡/카카오톡/인스타그램/당근 및 추가 커머스 후보별 실제 접근 결과와 확인 대기/가설을 구분한다. 경쟁 앱의 실제 화면을 캡처/분석했다는 주장은 하지 않는다. [Personas](../design/PERSONAS.md)는 인터뷰로 검증되지 않은 가설이다.

[UX Strategy](../design/UX_STRATEGY.md)와 [Design Direction](../design/DESIGN_DIRECTION.md)은 따뜻한 연보라·크림/화이트, 읽기 쉬운 한글, 제품 이미지 우선, 명확한 신선도/인증/제휴 표시, 탐색→필터→상세→구매처 이동과 비회원 복귀 흐름, 접근성·로딩/빈값/오류·권한 상태를 초기 방향으로 제안한다. 디자인은 고유하게 재구성하며 경쟁 디자인 복제/이미지 무단 사용을 하지 않는다. 본격 UI 구현 전에 실제 비교 시안/편집 가능 산출물/여정 검증/사용자 승인이 필요하다.

## 8. 광고·제휴 수익 방향과 마케팅 50,000원

[Monetization Plan](../growth/MONETIZATION_PLAN.md)은 클릭/주문전환·예상/확정 수수료·반품/정산을 구분한다. 공급처가 전환을 제공하지 않으면 클릭을 구매 실적으로 만들지 않는다. 광고는 식별되는 슬롯·빈도/동의·미충족/미노출 상태를 갖고 구매 이동을 막지 않는다. eCPM/수수료/요청 fill은 확인 전 실제 단가로 사용하지 않는다.

[Marketing Plan](../growth/MARKETING_PLAN.md)은 유기적 콘텐츠/SEO/ASO와 승인형 소액 실험을 우선한다. 도구 구독·콘텐츠·광고·예비비를 포함하여 월 50,000원 이내로 제안한다. 실제 지출/외부 게시/광고 집행은 0이며 집행은 별도 승인 대상이다. MAU별 수익·원가·민감도 표는 가정 시뮬레이션이며 매출 예측 확정이나 실제 사용자 KPI가 아니다.

## 9. 기술·환경·비용·보안

[ADR 후보](../architecture/ADR-001-STACK-CANDIDATES.md)는 Flutter, React/Next.js Admin, 경량 API, PostgreSQL/저비용 관리형 Backend의 비교안이다. 기술은 **Proposed**다. 현 Linux 환경에서 Git/Python/Node/Docker는 관측했지만 Flutter/Android/iOS/PostgreSQL 앱 환경을 설치·실행하지 않았다. iOS RC는 macOS/Xcode/서명·스토어 권한이 필요한 별도 환경 조건이다.

[Cost Model](../operations/COST_MODEL.md)은 MAU 및 상품 10,000/100,000/500,000/1,000,000 규모별 부하/원가 입력을 분리한다. 공식 요금 접근은 차단되어 단가/무료 구간은 확정하지 않는다. 전체 인프라 월 상한도 사용자 결정 대상이다. 유료 서비스·프로젝트 생성/배포는 없었다.

[Security Plan](../security/SECURITY_PRIVACY_PLAN.md), [Data Inventory](../security/DATA_INVENTORY.md), [Release Hold](../security/RELEASE_HOLD_CHECKLIST.md)는 선택 월령 구간/메모리 세션 기본·아이 이름/정확한 생일/사진 미수집, 최소권한·MFA/감사·고위험 2인 승인, open redirect/SSRF/서명·replay/secret·탈퇴/백업복구 후 재삭제 등을 검수 대상으로 한다. 기기 영속화·계정 동기화는 OFF인 별도 선택 제안이며 법률/스토어/실제 보안 테스트 완료는 아니다.

## 10. 실제 검증 증거와 결과

| 범위 | 실제 수행/증거 | 결과 한계 |
|---|---|---|
| 신규 저장소/환경 | git status, 원격 읽기, 버전/리소스 관측 | 기본 사용 가능, 제품 SDK/앱 검증 아님 |
| 기존 프로젝트 | pinned commit/파일·카탈로그 이력 parser/guard 읽기 | 파일 수량 감소 확인, API 원인·실사용 영향 미확인 |
| 공급처/경쟁/스토어/요금 공개 문서 | TLS/프록시 유지한 읽기 요청·오류 JSON | CONNECT 차단, 원본 페이지/계약/요금 미확인 |
| 접근성/폰트 공식 저장소 | W3C 소스 5개·폰트 라이선스 2개 HTTP 200 원문 저장 | published 표준 직접 확인/제품 접근성 통과가 아님 |
| source/RTM/링크/HOLD | `python3 tools/validate_project.py` | 최종 실제 실행 결과는 [VALIDATION_RESULT](../qa/VALIDATION_RESULT.json) |
| 가정 수익/예산 산술 | `python3 tools/revenue_model.py` | 최종 실제 산술 검증은 [MODEL_VALIDATION](../growth/MODEL_VALIDATION.json), 시장 검증 아님 |
| 독립 초기 검수 | 별도 QA의 [Initial Review](../qa/INITIAL_REVIEW.md) | 문서/추적·상태 검수, 제품 QA/사용자 승인 아님 |
| 제품 기능/빌드/데모/RC | 실행 안 함 | Not Started, 성공/실패 수로 보고하지 않음 |

실행 결과는 파일 확인 전 통과로 단정하지 않는다. 자기가 만든 문서를 QA 승인하지 않으며 실패 수정은 원 담당에 반환한다.

## 11. QA·릴리즈 Gate와 Lead 검수

[TEST_PLAN](../qa/TEST_PLAN.md)과 [QA_STATUS](../../QA_STATUS.md)를 따른다. Gate A는 요구사항/정책/범위/RTM 정합성, B는 사용자 승인된 UX/UI, C는 아키텍처/공급처/비용/보안, D는 구현·정적/단위/통합·시각/RTM, E는 독립 QA·핵심 여정·실데이터·기기·보안/성능과 P0/P1 0, F는 RC/운영/롤백/법적·스토어/사용자 출시 승인이다.

독립 QA는 초기 문서 제출 수준으로 수용했다. P2 문서 결함3건(원문 ID 형식, 경쟁 조사 축 수, Backend의 오래된 충돌 설명)은 원 담당 수정 후 독립 재검토로 해결됐으며 해당 문서 검수 범위의 미해결 확정 결함은0건이다. 제품 P0/P1 결함0건이나 기능 QA통과 판정은 아니다. 원문/RTM/링크/ID/HOLD 검사913/913행 통과와 가정수익15행/민감도135행 재현12검사는 각각 기록했다.

Lead는 초기 산출물의 원문·담당·상태·실행 근거와 QA 반환 수정을 별도로 확인했고 [LEAD_REVIEW](LEAD_REVIEW.md)에 실제 대조 범위를 남겼다. 현재 Gate A 전체 통과나 Gate B 이후 단계 완료는 선언하지 않는다. 출시 HOLD는 유지한다.

## 12. 미완료·이슈·위험 대응

공식 시장/공급처/스토어/요금 조사는 접근 차단으로 미완료다. 사업자등록·제휴/이미지/데이터 권한·인프라 예산·OAuth 계정·macOS/서명 권한도 미확인이다. 경쟁 화면·Figma·실제 프로토타입·앱/API/Admin/파이프라인·실데이터·제품 QA·스토어 후보는 이후 Gate에 남아 있다. [RISK_REGISTER](../../RISK_REGISTER.md)에서 책임/예방/해제 근거를 확인한다.

## 13. 사용자 승인/조치가 필요한 항목

**지금 필요한 외부 조치는 공식 조사 도메인 적용이다.** 환경 설정 draft에 필요한 19개 공개 공식 도메인을 저장했으며 `status=saved`, `requires_publish=true` 응답을 확인했다. 환경 설정에서 검토·저장한 뒤 환경을 발행해야 한다. 저장만으로 runtime 허용이 적용됐다는 뜻은 아니며 적용 후 동일 요청을 재검증한다. 무제한 인터넷·자격증명·유료 사용 권한은 요청하지 않았다.

저장 응답과 19개 도메인은 [NETWORK_DRAFT_SAVE](../research/NETWORK_DRAFT_SAVE.json)에 보존했다. 실제 실행해 확인한 문서/수익 검사와 상태 파일 재개 순서는 `start_skill`에도 저장했고 [START_DRAFT_SAVE](../research/START_DRAFT_SAVE.json)와 [지침 원문](../operations/START_SKILL.md)에 연결했다. 외부 패키지 설치가 필요 없어 `install_script`는 변경하지 않았다. 저장은 현재 instance 실행이나 환경 발행을 대신하지 않는다.

나머지 결정 카드는 [DECISIONS](../../DECISIONS.md)에 있다: 선택 빈 원격을 계속 쓸지, 인프라 월 상한/사업·제휴 준비 상태, 로그인·개인정보 범위, 실제 시안 검수 후 핵심 UX 방향. [요구사항 충돌/미결정 분석](../governance/REQUIREMENTS_REVIEW.md)도 함께 확인한다. 기존 실패 프로젝트는 참고만 사용한다는 지시는 이미 반영되어 재확인하지 않는다. 현재 Phase 3 산출물이 없으므로 Gate B 승인을 미리 요청하지 않는다.

## 14. 다음 실행과 확인 방법

본 보고서→README의 각 문서→RTM 원문 행→실제 근거 JSON/QA 결과 순서로 검수할 수 있다. Markdown은 로컬 파일로 열람하고 CSV는 표 도구로 확인할 수 있다. 공개 데모/원격 PR/CI 링크를 만들어내지 않았다.

[NEXT_ACTIONS](../../NEXT_ACTIONS.md)는 조사 접근 재검증→Phase 1 사실 보강→세부 원문/정책/수용 기준 QA→Gate A→UX/디자인 검수/사용자 Gate B→설계/구현을 지정한다. 재개를 위한 문서/명령은 저장하지만 현재 실행 종료 뒤 백그라운드 작업을 계속한다는 뜻은 아니다.
