# 꼬까픽 vNext — 카탈로그 안전성 기술 검증 보고

보고 기준일: **2026-10-12 (Asia/Seoul)**. 단계: Phase 0/1 후속 **격리 기술 위험 PoC**. 통합/검수: Team Lead `/root`. 공식 출시: **HOLD**.

## 1. 요청과 수행 범위

사용자는 2026-10-12 “계속해서 진행하고, 특이사항 확인되면 보고해줘.”라고 지시했다(REQ-ADD-002). 마스터 §6.6의 수량 급감 보호와 §11의 Gate B 이전 기술 위험 PoC 허용 범위에서, 문서가 실제 실패를 차단하는지 검증했다. [착수 보고](KICKOFF_REPORT.md)와 2026-10-11의 [초기 독립 문서 검수](../qa/INITIAL_REVIEW.md)는 과거 결과로 보존했다.

앱 화면·Admin·실서비스 API 구현/배포, 실제 상품·사용자·아동정보·제휴 API·광고 집행은 이번 범위가 아니다. Python 표준 라이브러리/임시 SQLite와 명시적인 합성 입력만 사용했다. Python3.12.14 / SQLite3.53.1에서 실행했으며 패키지 설치·외부 자원·비용 발생은 없었다.

## 2. 실제 역할·산출물·확인 방법

| 역할/실행 주체 | 실제 산출물 | 책임/독립성 |
|---|---|---|
| Source/Data `/root/source_data` | [실험 계약](../../experiments/catalog_integrity/CONTRACT.md), [fixture42개](../../experiments/catalog_integrity/fixtures.py) | 구현 전에 API/오류/범위를 협의·저장, 실제/추정 권리나 운영값으로 표현하지 않음 |
| Backend `/root/backend_engineer` | [guard](../../experiments/catalog_integrity/catalog_guard.py), [demo](../../experiments/catalog_integrity/demo.py), [README](../../experiments/catalog_integrity/README.md) | 계약 후 구현·자체 시연, 자신의 구현 QA 승인하지 않음 |
| Independent QA `/root/independent_qa` | [별도 테스트](../../experiments/catalog_integrity/tests/test_catalog_guard.py), [검수](../qa/CATALOG_POC_REVIEW.md), [결함/관측 오류 기록](../qa/POC_DEFECT_REGISTER.md) | feature/계약/fixture 수정하지 않고 독립 실패 시나리오 검증 |
| Lead `/root` | [scope ADR](../architecture/ADR-POC-001.md), [runner](../../tools/run_catalog_poc.py), [부분 RTM](../governance/POC_REQUIREMENT_TRACE.csv), 상태/본 보고 | ABA 설계 위험 지적·실제 시연·실행 로그/소스 hash 대조·통합 보고 |

파일 링크와 CSV/JSON은 로컬 저장소에서 직접 확인할 수 있다. 앱/공개 데모 URL·CI·PR·스토어 빌드가 생성됐다고 보고하지 않는다. 원격 push/환경 publication도 실행하지 않았다.

## 3. 구현한 실험과 특이사항

**상품 총량만 검사해서는 부족하다.** 전체 수량이 증가해도 기존 provider·category·provider×category 집합의 상품이 사라지면 후보를 거부한다. Source의 교차 fixture는 provider/category 총계가 유지돼도 특정 쌍5→3을 만들어 이 경계를 검증했다. 선언 수량이 정상이어도 실제 배열/SQL 행/내용 digest가 다르면 활성 카탈로그로 승격하지 않는다.

**롤백 ID만 비교하면 오래된 후보가 다시 유효해질 수 있다.** Lead는 R1에서 만든 후보→R2 활성화→R1 롤백 뒤 같은 token/parent ID만 검사하는 ABA 설계 위험을 발견했다. 계약과 구현에 영속 상태 세대를 추가했고, 활성화/롤백마다 증가한 세대가 stage 때와 다르면 거부한다. 이 위험은 실제 실패 코드 실행 전에 보강한 설계 항목이며 과거 실서비스 버그의 원인으로 단정하지 않는다. 독립 테스트는 해당 순서와 같은 ID rollback 뒤 오래된 후보 거부를 확인했다.

full완료·선언/실제 count·명시 model/variant identity·기존 baseline·strict 타입/64bit 범위를 검증한다. delta/부분 응답은 이 좁은 PoC에서 안전하게 거부하며 지원 완료로 표시하지 않는다. 별도 SQLite 연결의 두 thread가 동시에 같은 parent를 승격하면 정확히 하나만 commit한다. 실제 SQL trigger로 저장 실패를 주입해 release/offer/active pointer/epoch가 부분 반영되지 않음을 확인했다.

롤백은 카탈로그 참조만 복구한다. 현재 provider권리 철회·alert OFF·favorite삭제·계정삭제 tombstone·동의철회는 유지한다. LKG가 stale/future/TTL경계면 과거값은 보존하되 `current_price=None`, 알림후보=False로 처리한다. 이는 실제 개인정보 삭제나 OS push 발송·가격하락 증명의 검증이 아니다.

## 4. 실제 실행·실패·수정·최종 검증

| 실행 | 결과 | 실제 증거 |
|---|---|---|
| 최초 독립 QA, 20:30:49 KST |46 unittest methods, failure0/error2/skip0, exit1 | [최초 JSON](../qa/catalog_poc/INITIAL_EXECUTION_RESULT.json), [traceback](../qa/catalog_poc/INITIAL_TEST_OUTPUT.txt) |
| QA 관측 수정/계약 범위 보강 | 손상 DB를 public 정상읽기 API로 관측하던 오류를 rawSQL pointer보존+failclosed 기대 검사로 교정. 구현 수정0, skip/force-pass 없음 | [별도 관측 오류 기록](../qa/POC_DEFECT_REGISTER.md) |
| 최종 독립 QA, 20:33:09–10 KST | **57/57 실행·통과**, failure/error/skip/expected-failure/unexpected-success/loader-error0, exit0 | [최종 JSON](../qa/catalog_poc/EXECUTION_RESULT.json), [원본 출력](../qa/catalog_poc/TEST_OUTPUT.txt) |
| Lead 실제 시연, 20:31:45 KST |20행 bootstrap→24행증가→이전release rollback.14개거부. provider철회 뒤10행만표시·TTL경계 현재가격/알림후보0·현재상태/재열기 보존 | [실제 demo JSON](../qa/catalog_poc/DEMO_OUTPUT.json) |
| Lead 증거 무결성 대조 | 최종소스6개+runner+로그8개 hash일치 확인. 원문/RTM·코드참조는 별도 validator로 검사 | [원문/문서 검사](../qa/VALIDATION_RESULT.json) |

두 최초 error는 stage/bootstrap 거부 이후 테스트 관측 자체가 `BASELINE_INVALID`를 받은 경우였다. 기능의 올바른 failclosed를 구현 결함으로 분류하거나 실패를 숨기지 않았다. QA는 테스트만 수정하고 최초 기록/최종 결과를 따로 보존했다. 최종57은 unittest method수이며 parameter subcase/fixture42개를 별도 기능 수나 진행률로 부풀리지 않는다.

## 5. QA와 Lead 판정

독립 QA는 동결된 계약·구현·테스트 hash의 **합성 SQLite 실험 범위 수용**으로 판정했다. 이 범위의 확인된 미해결 구현 결함은 없으며 제품 P0/P1 결함0건을 판정한 것이 아니다. Lead는 계약/실제 SQL transaction·epoch/현재 overlay 구현, demo실행, source/loghash·테스트 참조를 별도로 확인했다. 작성자가 자기 구현을 QA 승인하지 않았다.

관련 원문11행의 RTM에는 `technical_poc_evidence/scope`만 추가했다. 제품 구현·시험·qa_state·final_review는 승격하지 않았고 [부분 추적7개](../governance/POC_REQUIREMENT_TRACE.csv)에 실험에서 검증한 부분/미충족 원문 범위를 함께 기록했다.

## 6. 미완료·위험·네트워크 특이사항

수량비율0.8/0.7과 TTL3600은 **미승인 합성 시나리오값**이다. 실공급처 API/권리/완결성, 운영PostgreSQL·검색세대·분산 lease/네트워크분할·운영부하·RBAC/실삭제/백업/알림발송·실제canonical매칭/이미지·Provider오류율/운영자알림·주요기기/UI는 미검증이다. 위험R02/R15의 방어는 PoC에서 확인했으나 운영 위험을 해제하지 않는다.

2026-10-12 환경 관측은 running/current=true이나 runtime `allowed_hosts=[]`, network state=unknown이었다. 필요한19개 조사도메인은 draft revision3에 저장되어 있고 startup도 저장돼 있지만 runtime 적용/환경 발행은 되지 않은 상태다. [재개 관측](../research/NETWORK_RESUME_OBSERVATION_2026-10-12.json)에 근거를 기록했다. 정책의 의미있는 변화가 없어 같은 차단요청을 반복하거나 proxy/TLS를 우회하지 않았다. 공급처·경쟁·가격·스토어 조건은 계속 미검증이다.

## 7. 승인 경계와 다음 실행

Gate A는 공식 근거/원자 정책·수용 기준 검수 보강 후 판정한다. Gate B 실제 디자인/프로토타입·사용자 승인 전 주요 화면 본격 구현을 하지 않는다. Gate C~F, 제품 독립 QA, 사업/법적·스토어·출시 승인은 미충족이며 **HOLD 유지**다.

현재 외부 필요조치는 환경 설정의 저장된 조사도메인/재개 draft를 검토·저장한 뒤 환경을 발행하는 것이다. 적용 확인 후 동일한 공식 요청을 재검증하고 Phase 1의 권리/요금/시장 근거를 보강한다. 실제 SDK/서비스 실행은 ADR·기술PoC 필요에 따라 따로 준비하고 검증한다. 사용자 자격증명 값은 채팅에 요청하지 않는다.

검증된 PoC 명령을 포함한 `start_skill`을 [재개 지침](../operations/START_SKILL.md)대로 다시 저장했고 [2026-10-12 저장 응답](../research/START_DRAFT_SAVE_2026-10-12.json)을 보존했다. install_script·network·repository membership·secrets는 이 저장에서 변경하지 않았다. 마지막 환경 재관측도 current=true / runtime허용목록빈값이므로 draft저장과 runtime적용/발행을 구분한다.

재개 명령은 저장소 루트에서 `python3 tools/run_catalog_poc.py`와 `python3 tools/validate_project.py`다. [PROJECT_STATE](../../PROJECT_STATE.md), [NEXT_ACTIONS](../../NEXT_ACTIONS.md), [QA_STATUS](../../QA_STATUS.md)에 범위/미완료를 지속 기록했다. 실제 작업이 끝난 뒤 백그라운드에서 계속한다는 의미는 아니다.
