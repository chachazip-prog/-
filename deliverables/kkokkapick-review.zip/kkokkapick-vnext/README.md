# 꼬까픽 vNext

육아 상품 통합 탐색·비교·추천의 신규 프로젝트. **Phase 0/1 초기 검토본과 격리 SQLite 안전성 PoC(독립57tests 통과)를 제출했다. 앱 구현·제품 QA·공식 출시 완료가 아니다. 출시 HOLD.**

## 검수할 자료

| 자료 | 경로 |
|---|---|
| 착수 보고서 | [KICKOFF_REPORT](docs/reports/KICKOFF_REPORT.md) · [Lead Review](docs/reports/LEAD_REVIEW.md) |
| 2026-10-12 실제 진행/특이사항 | [진행 보고](docs/reports/CONTINUATION_REPORT_2026-10-12.md) · [PoC 검수](docs/qa/CATALOG_POC_REVIEW.md) · [실행 결과](docs/qa/catalog_poc/EXECUTION_RESULT.json) |
| 마스터 원문 | [MASTER_PROMPT](docs/source/MASTER_PROMPT.md) |
| 목표/기존 분리 | [Charter](docs/phase0/PROJECT_CHARTER.md) · [회고](docs/phase0/LEGACY_RETROSPECTIVE.md) |
| 실제 에이전트 | [Agent Organization](docs/phase0/AGENT_ORGANIZATION.md) |
| 요구사항 추적 | [RTM 안내](REQUIREMENTS_TRACEABILITY.md) · [RTM.csv](docs/governance/RTM.csv) · [요구사항 분석](docs/governance/REQUIREMENTS_REVIEW.md) |
| 제품/정책/기능 | [PRD](docs/product/PRD.md) · [Business](docs/product/BUSINESS_REQUIREMENTS.md) · [Functional](docs/product/FUNCTIONAL_SPECIFICATION.md) · [Policy](docs/product/POLICY_SPECIFICATION.md) |
| 시장·UX·방향 | [Market Research](docs/product/MARKET_RESEARCH.md) · [Benchmark](docs/design/BENCHMARK_MATRIX.md) · [Personas](docs/design/PERSONAS.md) · [UX Strategy](docs/design/UX_STRATEGY.md) · [Design Direction](docs/design/DESIGN_DIRECTION.md) |
| 공급처·데이터 | [Provider Assessment](docs/data/PROVIDER_ASSESSMENT.md) · [Data Strategy](docs/data/DATA_STRATEGY.md) |
| 기술·운영·비용 | [ADR](docs/architecture/ADR-001-STACK-CANDIDATES.md) · [Mobile Review](docs/architecture/MOBILE_READINESS_REVIEW.md) · [Backend Review](docs/architecture/BACKEND_READINESS_REVIEW.md) · [Environment](docs/operations/ENVIRONMENT_PLAN.md) · [Cost Model](docs/operations/COST_MODEL.md) · [CI/Release](docs/operations/CI_RELEASE_PLAN.md) |
| 보안·개인정보·출시 | [Security](docs/security/SECURITY_PRIVACY_PLAN.md) · [Data Inventory](docs/security/DATA_INVENTORY.md) · [Hold Checklist](docs/security/RELEASE_HOLD_CHECKLIST.md) |
| 수익·마케팅 | [Monetization](docs/growth/MONETIZATION_PLAN.md) · [Marketing](docs/growth/MARKETING_PLAN.md) |
| 독립 초기 검수 | [Initial Review](docs/qa/INITIAL_REVIEW.md) · [Test Plan](docs/qa/TEST_PLAN.md) · [현재 자동 결과](docs/qa/VALIDATION_RESULT.json) |
| 실행/승인/위험 | [Project Plan](PROJECT_PLAN.md) · [Decisions](DECISIONS.md) · [Risks](RISK_REGISTER.md) |
| 재개 상태 | [Project State](PROJECT_STATE.md) · [Next Actions](NEXT_ACTIONS.md) · [QA Status](QA_STATUS.md) |

## 실행한 검증을 재현

```sh
cd /workspace/-
python3 tools/validate_project.py
python3 tools/run_catalog_poc.py
```

Python3 표준 라이브러리만 사용한다. 첫 검사는 원문 줄/RTM·PoC추적/문서 연결·HOLD, 둘째는 격리 SQLite 합성57tests다. 제품 기능 QA가 아니다. 앱 의존성·lockfile·SDK 핀·실행 서비스는 아직 없으며 앱 install/build/start 명령을 검증 완료로 제공하지 않는다. [실제 임시DB 시연](experiments/catalog_integrity/README.md)도 별도로 재현할 수 있다.

신규 원격은 사용자가 선정한 `chachazip-prog/-`. 기존 `chachazip-prog/kkokkapick`는 별도 읽기 전용 참고 분석이며 앱 코드·데이터를 이관하지 않는다. 로컬 문서 생성과 원격 push/환경 publication/제품 출시를 구분한다.
