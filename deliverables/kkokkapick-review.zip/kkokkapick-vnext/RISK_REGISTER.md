# Risk Register

기준일: 2026-10-11. 발생 확률은 자료 부족으로 수치화하지 않는다. 심각도는 출시/안전 기준의 평가이며 실사고를 단정하지 않는다.

| ID | 심각도/상태 | 위험 | 책임 | 예방/검증/해제 근거 |
|---|---|---|---|---|
| R-01 | P0/Open | 기획·화면·정책·구현 요구사항 누락 | Lead·QA | 원문 ledger/RTM, 단계별 독립 검수 |
| R-02 | P0/Open | 동기화 급감/잘못된 모델·옵션 병합 | Data·Backend | 배치 비교/급감 Gate/last-good/승인/롤백 실험 |
| R-03 | P0/Blocked | 공급처 API·저장·이미지·제휴 권한 미확인 | Data·Security | 공식 문서+계약 근거 전 adapter/실데이터 노출 차단 |
| R-04 | P0/Open | 아동정보/광고/계정 삭제 법적·스토어 미충족 | Security | 최소수집/RBAC/삭제·backup/법적 검토·스토어 증거 |
| R-05 | P0/Open | 템플릿 UI·가독성·탐색·접근성 품질 부족 | Designer·QA | 실제 비교 시안/주요 흐름/화면 캡처/사용자 승인 |
| R-06 | P0/Blocked | 공식 공개 조사 도메인 CONNECT 프록시 차단 | Lead | 필요한 도메인 draft 저장, runtime 적용 후 실제 retry |
| R-07 | P0/Blocked | 사업자·제휴·법적 준비 상태 미확인 | Lead·사용자 | 출시 HOLD, 법적/계약/승인 문서 |
| R-08 | P1/Open | 무료 구간·이미지/요청/DB 규모 가정 오류 | FinOps | 공식 요금 확인, 부하 모델, 비용 상한/경보 |
| R-09 | P0/Blocked | Linux에서 iOS 서명/RC 검증 불가 | DevOps·Mobile | macOS/Xcode/서명/스토어 권한 확인 |
| R-10 | P1/Open | 클릭을 구매전환/확정수익으로 오인 | Growth·Backend | 전환 제공권한/주문 취소/추정·확정 분리 |
| R-11 | P0/Open | 개발자가 자신을 QA 승인 | Lead·QA | 독립 reviewer, 실패 반환/재검증 기록 |
| R-12 | P1/Open | 이전 실패 원인 추정이 새 설계 사실로 전파 | Reference Reviewer | commit·파일·로그 구분, 인과 주장 보류 |
| R-13 | P1/Open | 신규 원격 미생성/로컬 산출물만 존재 | Lead | 현재 경로/원격/푸시/커밋 상태 명시, 사용자가 원격 선택 |
| R-14 | P0/Open | 광고 강제 시청·추적 과다·잘못된 인증 | Planner·Security·QA | 광고 분리/빈도·동의/미확인 인증 표시/여정 검증 |
| R-15 | PoC에서 방어검증 / 운영Open | rollback로 active release ID가 이전 값으로 돌아가면 prestaged candidate가 다시 CAS 통과하는 ABA 가능성 | Backend·Data·QA | 2026-10-12 state_epoch 구현·옛후보 거부 독립57tests 중 검증. 운영Postgres·분산/관리자 승인·실서비스 QA는 미검증 |

해제는 실제 근거 경로와 reviewer를 기록한 후 가능하다. 문서 초안 작성만으로 위험을 해제하지 않는다.
