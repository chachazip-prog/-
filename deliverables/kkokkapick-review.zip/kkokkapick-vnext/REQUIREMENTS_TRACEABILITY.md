# Requirements Traceability Matrix

기준일: 2026-10-11. 상태: Initial Mapping / 제품 구현·테스트·승인 미실행.

- [정본 RTM.csv](docs/governance/RTM.csv): 원문 위치·텍스트·구역별 해석·담당·정책/설계/구현/테스트/검수 증거.
- [주요 세부 교차 연결](docs/governance/REQUIREMENT_CROSSWALK.md) · [추가 사용자 지시](docs/governance/ADDITIONAL_REQUIREMENTS.csv)
- [기술 PoC 부분 증거](docs/governance/POC_REQUIREMENT_TRACE.csv): 합성 SQLite의 검증 범위와 미충족 제품 범위를 분리.
- [추적 방법과 한계](docs/governance/RTM_METHOD.md): 원문 항목 수와 기능 요구사항 수 구분.
- [마스터 원문](docs/source/MASTER_PROMPT.md): 사용자가 제공한 텍스트 그대로 보존.
- [독립 초기 검수](docs/qa/INITIAL_REVIEW.md): 자동 source 검사와 별개의 의미 검토.

현재 정책 문서 연결은 검토 초안으로의 배정이다. 미생성 디자인/구현/기능 테스트는 공란/Not Run 상태다. 실제 완료/승인 근거가 생길 때 각 행을 업데이트한다.

2026-10-12 카탈로그 실험의 독립57개 테스트 통과는 관련 원문11행의 `technical_poc_evidence/scope`에 **부분 기술 증거**로 추가했다. 제품의 구현/시험/QA·사용자 승인 필드는 승격하지 않았다. 이미지 정상률(REQ-L0632), Provider오류율(REQ-L0633), 운영자 알림(REQ-L0637)은 이번 실험이 검증하지 않는다.

| 원문 구역 | 주 담당 | 초기 정책/설계 산출물 | 검증 계획 |
|---|---|---|---|
| 0·2·11~16 | Lead·QA | Charter/조직/계획/승인 규칙 | GOV/REQ/GATE 문서 검수 |
| 1·5 | Planner·Mobile·Backend | PRD/기능/정책 | HOME/SEARCH/DETAIL/PROFILE/AUTH/FAVORITE |
| 3·4 | Designer·Planner | Benchmark/UX/방향/페르소나 | UX/FLOW/A11Y/VISUAL (미실행) |
| 6 | Data·Backend | 공급처 평가/데이터 전략 | PROVIDER/DATA/ROLLBACK (미실행) |
| 7·10 | Growth·Backend·FinOps | 수익/마케팅 모델 | REVENUE/AD/BUDGET (모델은 기능 QA 아님) |
| 8 | Planner·Backend·Frontend | Admin 시나리오/정책/RBAC | ADMIN/AUDIT (미실행) |
| 9 | DevOps·Architecture·Security | 후보 ADR/환경/비용/CI | BUILD/SECURITY/COST/RECOVERY (미실행) |

사용자 추가 지시 `REQ-ADD-001`: 기존 저장소 `chachazip-prog/kkokkapick`는 실패 프로젝트 참고로만 사용한다. 담당 Reference Reviewer/Lead, 반영 DEC-001/회고. 기존 코드 이관 없음.
